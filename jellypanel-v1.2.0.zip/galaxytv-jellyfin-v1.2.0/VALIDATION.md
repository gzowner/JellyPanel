# GalaxyTV v1.2.0 Validation

The release was validated before packaging with:

- Bash syntax checks for every included shell script.
- Python compilation for the Control API, worker, Operations Agent, Library Agent, M3U gateway, and media gateway.
- YAML parsing for the main Compose stack, Intel GPU overlay, and remote Library Node.
- Browser JavaScript syntax and HTML ID/reference consistency checks.
- Incremental Library Agent functional tests covering first build, unchanged re-scan, URL-token encoding, source rename, output relocation, missing grace, cleanup, existing-file adoption, output collision protection, and empty-mount safety.
- Library Agent SQLite backup/restore helper testing.
- ZIP CRC, Unix executable-mode, extraction, and internal SHA-256 verification during final packaging.

A real Docker multi-server Jellyfin deployment was unavailable in the build environment. Complete the steps in `TEST-SERVER-LIBRARIES.md` on the local test server before enabling a large scheduled library.
