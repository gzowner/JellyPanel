#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_DIR="${LIBRARY_NODE_BASE_DIR:-/opt/galaxytv-library-node}"
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }
command -v docker >/dev/null 2>&1 || { apt-get update; apt-get install -y ca-certificates curl; curl -fsSL https://get.docker.com | sh; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose plugin is required."; exit 1; }
mkdir -p "$NODE_DIR/state" "$NODE_DIR/strm-library"
cp "$ROOT_DIR/library-node/compose.yml" "$NODE_DIR/compose.yml"
cp -a "$ROOT_DIR/library-agent" "$NODE_DIR/library-agent"
if [[ ! -f "$NODE_DIR/.env" ]]; then
  cp "$ROOT_DIR/library-node/.env.example" "$NODE_DIR/.env"
  agent_token="$(openssl rand -hex 32)"
  media_token="$(openssl rand -hex 32)"
  sed -i "s/^LIBRARY_AGENT_TOKEN=.*/LIBRARY_AGENT_TOKEN=$agent_token/" "$NODE_DIR/.env"
  sed -i "s/^LIBRARY_MEDIA_TOKEN=.*/LIBRARY_MEDIA_TOKEN=$media_token/" "$NODE_DIR/.env"
  echo
  echo "Edit $NODE_DIR/.env before starting the node:"
  echo "  MEDIA_PATH"
  echo "  JELLYFIN_URL"
  echo "  JELLYFIN_API_KEY"
  echo "  LIBRARY_PLAYBACK_BASE_URL"
  echo
  echo "Agent token: $agent_token"
  echo "Media token: $media_token"
  echo "Save these two tokens in JellyPanel's Server Libraries page."
  exit 0
fi
(cd "$NODE_DIR" && docker compose --env-file .env up -d --build)
echo "GalaxyTV Library Node started."
