# GalaxyTV Library Node

Install this component on every additional Jellyfin server whose local media and STRM output must be managed by the central JellyPanel.

```bash
cd galaxytv-jellyfin-v1.2.0
sudo bash library-node/install-node.sh
sudo nano /opt/galaxytv-library-node/.env
sudo bash library-node/install-node.sh
```

Allow the central JellyPanel server to reach TCP port `8292`. Restrict that port with a firewall to the JellyPanel server and the local Jellyfin host. The media endpoint uses a separate token embedded in generated STRM URLs.


## Jellyfin STRM mount

Mount the host directory configured as `STRM_PATH` into the local Jellyfin container at `/strm-library`, preferably read-only. The generated STRM files themselves are local; their playback URLs point back to this node on port `8292`.

Example Docker Compose volume for Jellyfin:

```yaml
volumes:
  - /opt/galaxytv-library-node/strm-library:/strm-library:ro
```

Use a private LAN or WireGuard address for the node. When it must cross an untrusted network, put port 8292 behind an HTTPS reverse proxy and firewall it to the central JellyPanel and the Jellyfin host.
