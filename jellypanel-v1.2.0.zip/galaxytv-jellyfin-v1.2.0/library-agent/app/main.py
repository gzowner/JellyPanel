from __future__ import annotations

import asyncio
import hashlib
import json
import mimetypes
import os
import re
import sqlite3
import uuid
import xml.etree.ElementTree as ET
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import quote

import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

VERSION = "1.2.0"
AGENT_TOKEN = os.environ.get("LIBRARY_AGENT_TOKEN", "")
DEFAULT_MEDIA_TOKEN = os.environ.get("LIBRARY_MEDIA_TOKEN", "")
STATE_DIR = Path(os.environ.get("LIBRARY_AGENT_STATE", "/state")).resolve()
DEFAULT_SOURCE = os.environ.get("LIBRARY_SOURCE_PATH", "/media/Media")
DEFAULT_OUTPUT = os.environ.get("LIBRARY_OUTPUT_PATH", "/strm-library/local-jellyfin")
DEFAULT_PLAYBACK = os.environ.get("LIBRARY_PLAYBACK_BASE_URL", "http://library-agent:8192")
DEFAULT_JELLYFIN = os.environ.get("JELLYFIN_URL", "http://jellyfin:8096")
DEFAULT_JELLYFIN_KEY = os.environ.get("JELLYFIN_API_KEY", "")
VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".m4v", ".avi", ".mov", ".wmv", ".ts", ".m2ts",
    ".mpg", ".mpeg", ".webm", ".flv", ".vob", ".iso",
}
EPISODE_RE = re.compile(r"(?i)(?:\bS(?P<s>\d{1,2})E(?P<e>\d{1,3})\b|\b(?P<s2>\d{1,2})x(?P<e2>\d{1,3})\b)")
SEASON_DIR_RE = re.compile(r"(?i)^season[ ._-]*(\d{1,2})$")
YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
TMDB_RE = re.compile(r"(?i)(?:tmdb(?:id)?)[\s._:=\-]*(\d+)")
IMDB_RE = re.compile(r"(?i)\b(tt\d{5,12})\b")
TAG_RE = re.compile(r"[\[\{\(](?:tmdb(?:id)?|imdb)[^\]\}\)]*[\]\}\)]", re.I)
TECH_RE = re.compile(r"(?i)\b(?:2160p|1080p|720p|480p|4k|uhd|hdr10\+?|dolby[ ._-]?vision|dv|bluray|blu[ ._-]?ray|web[ ._-]?dl|webrip|hdtv|remux|x26[45]|h26[45]|hevc|av1|aac|dts(?:-hd)?|truehd|atmos|proper|repack|extended|unrated)\b.*$")
TV_MARKERS = {"tv", "tv show", "tv shows", "shows", "series", "television"}

STATE_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = STATE_DIR / "library-agent.sqlite3"
job_tasks: dict[str, asyncio.Task[Any]] = {}
job_cancel: dict[str, asyncio.Event] = {}
job_lock = asyncio.Lock()


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def db() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA foreign_keys=ON")
    return connection


def init_db() -> None:
    with db() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS items (
                stable_id TEXT PRIMARY KEY,
                source_root TEXT NOT NULL,
                source_path TEXT NOT NULL,
                relative_path TEXT NOT NULL,
                media_kind TEXT NOT NULL,
                identity_key TEXT NOT NULL,
                title TEXT NOT NULL,
                series_title TEXT NOT NULL DEFAULT '',
                production_year INTEGER,
                season_number INTEGER,
                episode_number INTEGER,
                tmdb_id TEXT NOT NULL DEFAULT '',
                imdb_id TEXT NOT NULL DEFAULT '',
                source_size INTEGER NOT NULL DEFAULT 0,
                source_mtime_ns INTEGER NOT NULL DEFAULT 0,
                source_hash TEXT NOT NULL,
                strm_path TEXT NOT NULL DEFAULT '',
                nfo_path TEXT NOT NULL DEFAULT '',
                playback_url TEXT NOT NULL DEFAULT '',
                active INTEGER NOT NULL DEFAULT 1,
                managed INTEGER NOT NULL DEFAULT 1,
                missing_since TEXT,
                last_seen_at TEXT NOT NULL,
                last_built_at TEXT,
                updated_at TEXT NOT NULL,
                UNIQUE(source_root, relative_path)
            );
            CREATE INDEX IF NOT EXISTS idx_items_active ON items(active, media_kind);
            CREATE INDEX IF NOT EXISTS idx_items_identity ON items(identity_key, active);

            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                job_type TEXT NOT NULL,
                status TEXT NOT NULL,
                progress_percent INTEGER NOT NULL DEFAULT 0,
                current_path TEXT,
                counters TEXT NOT NULL DEFAULT '{}',
                result TEXT NOT NULL DEFAULT '{}',
                error TEXT,
                created_at TEXT NOT NULL,
                started_at TEXT,
                finished_at TEXT
            );

            CREATE TABLE IF NOT EXISTS conflicts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id TEXT NOT NULL,
                source_path TEXT NOT NULL DEFAULT '',
                output_path TEXT NOT NULL DEFAULT '',
                conflict_type TEXT NOT NULL,
                message TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_conflicts_job ON conflicts(job_id, id);
            """
        )


class JobRequest(BaseModel):
    job_type: str = Field(default="sync", pattern="^(sync|adopt|verify|cleanup|full)$")
    server_id: str = ""
    source_path: str = DEFAULT_SOURCE
    output_path: str = DEFAULT_OUTPUT
    movies_folder: str = "Movies"
    tv_folder: str = "TV Shows"
    playback_base_url: str = DEFAULT_PLAYBACK
    media_token: str = DEFAULT_MEDIA_TOKEN
    jellyfin_url: str = DEFAULT_JELLYFIN
    jellyfin_api_key: str = DEFAULT_JELLYFIN_KEY
    verify_tls: bool = True
    missing_grace_days: int = Field(default=7, ge=1, le=365)
    remove_missing: bool = True
    adopt_existing: bool = True
    skip_direct_duplicates: bool = True
    refresh_jellyfin: bool = True


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    with db() as connection:
        connection.execute(
            "UPDATE jobs SET status='failed', error='Agent restarted during job.', finished_at=? WHERE status IN ('queued','running')",
            (utcnow(),),
        )
    yield
    for task in list(job_tasks.values()):
        task.cancel()


app = FastAPI(title="GalaxyTV Per-Server Library Agent", version=VERSION, lifespan=lifespan, docs_url=None, redoc_url=None)


def require_agent_token(value: str | None) -> None:
    if not AGENT_TOKEN or value != AGENT_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid library agent token.")


def safe_root(value: str, label: str) -> Path:
    path = Path(value).resolve()
    if not path.is_absolute():
        raise RuntimeError(f"{label} must be an absolute path.")
    return path


def clean_component(value: str, fallback: str = "Unknown") -> str:
    value = value.replace("/", "-").replace("\\", "-").replace(":", " - ")
    value = re.sub(r"[\x00-\x1f<>\"|?*]", "", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value[:180] or fallback


def strip_title(value: str) -> tuple[str, int | None]:
    value = PurePosixPath(value).stem
    cleaned = TAG_RE.sub(" ", value)
    cleaned = TECH_RE.sub("", cleaned)
    years = YEAR_RE.findall(cleaned)
    year = int(years[-1]) if years else None
    if year:
        cleaned = re.sub(rf"[\(\[\{{]?\s*{year}\s*[\)\]\}}]?", " ", cleaned)
    cleaned = EPISODE_RE.sub(" ", cleaned)
    cleaned = re.sub(r"[._]+", " ", cleaned)
    cleaned = re.sub(r"\s+-\s+.*$", "", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" -._")
    return cleaned or PurePosixPath(value).stem, year


def is_tv(parts: tuple[str, ...]) -> bool:
    for part in parts:
        normalized = re.sub(r"[._-]+", " ", part.lower()).strip()
        if normalized in TV_MARKERS or normalized.startswith("tv shows"):
            return True
    return False


def parse_media(relative: str) -> dict[str, Any]:
    pure = PurePosixPath(relative)
    parts = pure.parts
    filename = pure.name
    episode_match = EPISODE_RE.search(filename)
    season = episode = None
    season_index = None
    for index, part in enumerate(parts[:-1]):
        match = SEASON_DIR_RE.match(part)
        if match:
            season = int(match.group(1))
            season_index = index
    if episode_match:
        season = int(episode_match.group("s") or episode_match.group("s2"))
        episode = int(episode_match.group("e") or episode_match.group("e2"))
    elif season is not None:
        match = re.match(r"(?i)^(?:episode[ ._-]*)?(\d{1,3})(?:\D|$)", PurePosixPath(filename).stem)
        if match:
            episode = int(match.group(1))

    full = "/".join(parts)
    tmdb_match = TMDB_RE.search(full)
    imdb_match = IMDB_RE.search(full)
    tmdb_id = tmdb_match.group(1) if tmdb_match else ""
    imdb_id = imdb_match.group(1) if imdb_match else ""

    if episode is not None or (season is not None and is_tv(parts)):
        filename_series, filename_year = strip_title(filename)
        series_raw = filename
        if season_index is not None and season_index > 0:
            series_raw = parts[season_index - 1]
        elif season_index is None:
            parent = parts[-2] if len(parts) >= 2 else ""
            parent_normalized = re.sub(r"[._-]+", " ", parent.lower()).strip()
            if parent and parent_normalized not in TV_MARKERS and not SEASON_DIR_RE.match(parent):
                series_raw = parent
            for index, part in enumerate(parts[:-1]):
                normalized = re.sub(r"[._-]+", " ", part.lower()).strip()
                if normalized in TV_MARKERS and index + 1 < len(parts) - 1:
                    series_raw = parts[index + 1]
                    break
        series_title, series_year = strip_title(series_raw)
        if series_raw == filename:
            series_title, series_year = filename_series, filename_year
        episode_title = ""
        if episode_match:
            tail = PurePosixPath(filename).stem[episode_match.end():].strip(" ._-")
            if tail:
                episode_title, _ = strip_title(tail)
        if not episode_title:
            episode_title = f"Episode {episode or 0}"
        identity = f"episode:{series_title.lower()}:s{season or 0:02d}e{episode or 0:03d}"
        return {
            "kind": "episode", "title": episode_title, "series_title": series_title,
            "year": series_year, "season": season or 0, "episode": episode or 0,
            "tmdb_id": tmdb_id, "imdb_id": imdb_id, "identity": identity,
        }

    parent = pure.parent.name
    file_title, file_year = strip_title(filename)
    parent_title, parent_year = strip_title(parent) if parent else ("", None)
    normalized_parent = re.sub(r"[^a-z0-9]+", "", parent_title.lower())
    normalized_file = re.sub(r"[^a-z0-9]+", "", file_title.lower())
    parent_has_identifier = bool(parent and (YEAR_RE.search(parent) or TMDB_RE.search(parent) or IMDB_RE.search(parent)))
    parent_matches_file = bool(
        normalized_parent
        and normalized_file
        and (
            normalized_parent == normalized_file
            or normalized_file.startswith(normalized_parent)
            or normalized_parent.startswith(normalized_file)
        )
    )
    if parent and (parent_has_identifier or parent_matches_file):
        title, year = parent_title, parent_year or file_year
    else:
        title, year = file_title, file_year
    identity = f"movie:tmdb:{tmdb_id}" if tmdb_id else (f"movie:imdb:{imdb_id}" if imdb_id else f"movie:{title.lower()}:{year or 0}")
    return {
        "kind": "movie", "title": title, "series_title": "", "year": year,
        "season": None, "episode": None, "tmdb_id": tmdb_id,
        "imdb_id": imdb_id, "identity": identity,
    }


def item_output_paths(output_root: Path, cfg: JobRequest, parsed: dict[str, Any], source: Path) -> tuple[Path, Path]:
    if parsed["kind"] == "movie":
        title = clean_component(parsed["title"])
        suffix = f" ({parsed['year']})" if parsed.get("year") else ""
        id_suffix = f" [tmdbid-{parsed['tmdb_id']}]" if parsed.get("tmdb_id") else ""
        folder_name = f"{title}{suffix}{id_suffix}"
        strm = output_root / cfg.movies_folder / folder_name / f"{folder_name}.strm"
    else:
        series = clean_component(parsed["series_title"])
        suffix = f" ({parsed['year']})" if parsed.get("year") else ""
        id_suffix = f" [tmdbid-{parsed['tmdb_id']}]" if parsed.get("tmdb_id") else ""
        show = output_root / cfg.tv_folder / f"{series}{suffix}{id_suffix}"
        season = int(parsed.get("season") or 0)
        episode = int(parsed.get("episode") or 0)
        season_folder = "Specials" if season == 0 else f"Season {season:02d}"
        file_name = f"{series} - S{season:02d}E{episode:02d} - {clean_component(parsed['title'])}"
        strm = show / season_folder / f"{file_name}.strm"
    return strm, strm.with_suffix(".nfo")


def nfo_bytes(parsed: dict[str, Any], server_id: str, source_hash: str, relative: str) -> bytes:
    root = ET.Element("movie" if parsed["kind"] == "movie" else "episodedetails")
    ET.SubElement(root, "title").text = str(parsed["title"])
    if parsed.get("year"):
        ET.SubElement(root, "year").text = str(parsed["year"])
    if parsed["kind"] == "episode":
        ET.SubElement(root, "showtitle").text = str(parsed["series_title"])
        ET.SubElement(root, "season").text = str(parsed["season"])
        ET.SubElement(root, "episode").text = str(parsed["episode"])
    if parsed.get("tmdb_id"):
        ET.SubElement(root, "uniqueid", {"type": "tmdb", "default": "true"}).text = str(parsed["tmdb_id"])
    if parsed.get("imdb_id"):
        ET.SubElement(root, "uniqueid", {"type": "imdb"}).text = str(parsed["imdb_id"])
    ET.SubElement(root, "galaxytvManaged").text = "true"
    ET.SubElement(root, "galaxytvServerId").text = server_id or "local"
    ET.SubElement(root, "galaxytvSourceHash").text = source_hash
    ET.SubElement(root, "galaxytvSourcePath").text = relative
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def atomic_write(path: Path, payload: bytes | str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    if isinstance(payload, bytes):
        temp.write_bytes(payload)
    else:
        temp.write_text(payload, encoding="utf-8")
    temp.replace(path)


def managed_nfo_info(path: Path) -> dict[str, str]:
    try:
        root = ET.fromstring(path.read_bytes())
    except (OSError, ET.ParseError):
        return {}
    managed = (root.findtext("galaxytvManaged") or "").strip().lower() == "true"
    if not managed:
        return {}
    return {
        "source_hash": (root.findtext("galaxytvSourceHash") or "").strip(),
        "source_path": (root.findtext("galaxytvSourcePath") or "").strip(),
        "server_id": (root.findtext("galaxytvServerId") or "").strip(),
    }


def is_managed_nfo(path: Path) -> bool:
    return bool(managed_nfo_info(path))


def record_conflict(job_id: str, conflict_type: str, message: str, source: str = "", output: str = "", details: dict[str, Any] | None = None) -> None:
    with db() as connection:
        connection.execute(
            "INSERT INTO conflicts(job_id,source_path,output_path,conflict_type,message,details,created_at) VALUES(?,?,?,?,?,?,?)",
            (job_id, source, output, conflict_type, message, json.dumps(details or {}), utcnow()),
        )


def update_job(job_id: str, *, status: str | None = None, progress: int | None = None, current: str | None = None, counters: dict[str, int] | None = None, result: dict[str, Any] | None = None, error: str | None = None, finished: bool = False) -> None:
    fields: list[str] = []
    values: list[Any] = []
    if status is not None:
        fields.append("status=?"); values.append(status)
    if progress is not None:
        fields.append("progress_percent=?"); values.append(max(0, min(100, progress)))
    if current is not None:
        fields.append("current_path=?"); values.append(current)
    if counters is not None:
        fields.append("counters=?"); values.append(json.dumps(counters))
    if result is not None:
        fields.append("result=?"); values.append(json.dumps(result))
    if error is not None:
        fields.append("error=?"); values.append(error[-4000:])
    if status == "running":
        fields.append("started_at=COALESCE(started_at,?)"); values.append(utcnow())
    if finished:
        fields.append("finished_at=?"); values.append(utcnow())
    values.append(job_id)
    with db() as connection:
        connection.execute(f"UPDATE jobs SET {', '.join(fields)} WHERE id=?", values)


async def jellyfin_inventory(cfg: JobRequest) -> tuple[set[str], set[str], list[str]]:
    paths: set[str] = set()
    identities: set[str] = set()
    warnings: list[str] = []
    if not cfg.jellyfin_api_key.strip():
        return paths, identities, ["Jellyfin API key is not configured; direct-library duplicate checks were skipped."]
    headers = {"X-Emby-Token": cfg.jellyfin_api_key.strip()}
    start = 0
    try:
        async with httpx.AsyncClient(verify=cfg.verify_tls, timeout=45) as client:
            while True:
                response = await client.get(
                    f"{cfg.jellyfin_url.rstrip('/')}/Items",
                    headers=headers,
                    params={
                        "Recursive": "true", "IncludeItemTypes": "Movie,Episode",
                        "Fields": "Path,ProviderIds,ProductionYear,SeriesName,ParentIndexNumber,IndexNumber",
                        "StartIndex": start, "Limit": 500,
                    },
                )
                response.raise_for_status()
                payload = response.json()
                rows = payload.get("Items") or []
                for item in rows:
                    path = str(item.get("Path") or "").strip()
                    if path:
                        paths.add(path)
                    if path.lower().endswith(".strm"):
                        continue
                    provider = item.get("ProviderIds") or {}
                    tmdb = str(provider.get("Tmdb") or "")
                    imdb = str(provider.get("Imdb") or "")
                    item_type = str(item.get("Type") or "")
                    if item_type == "Movie":
                        title = str(item.get("Name") or "").lower()
                        year = int(item.get("ProductionYear") or 0)
                        identities.add(f"movie:tmdb:{tmdb}" if tmdb else (f"movie:imdb:{imdb}" if imdb else f"movie:{title}:{year}"))
                    elif item_type == "Episode":
                        series = str(item.get("SeriesName") or "").lower()
                        season = int(item.get("ParentIndexNumber") or 0)
                        episode = int(item.get("IndexNumber") or 0)
                        identities.add(f"episode:{series}:s{season:02d}e{episode:03d}")
                start += len(rows)
                if not rows or start >= int(payload.get("TotalRecordCount") or start):
                    break
    except Exception as exc:
        warnings.append(f"Jellyfin inventory could not be read: {exc}")
    return paths, identities, warnings


async def refresh_jellyfin(cfg: JobRequest) -> str:
    if not cfg.refresh_jellyfin or not cfg.jellyfin_api_key.strip():
        return "not_requested"
    try:
        async with httpx.AsyncClient(verify=cfg.verify_tls, timeout=30) as client:
            response = await client.post(
                f"{cfg.jellyfin_url.rstrip('/')}/Library/Refresh",
                headers={"X-Emby-Token": cfg.jellyfin_api_key.strip()},
            )
            if response.status_code not in {200, 204}:
                return f"failed_http_{response.status_code}"
        return "requested"
    except Exception as exc:
        return f"failed:{str(exc)[:200]}"


async def run_job(job_id: str, cfg: JobRequest) -> None:
    counters = {
        "total": 0, "processed": 0, "added": 0, "updated": 0, "unchanged": 0,
        "adopted": 0, "skipped_duplicates": 0, "missing": 0, "removed": 0,
        "conflicts": 0, "failed": 0,
    }
    cancel = job_cancel[job_id]
    try:
        async with job_lock:
            update_job(job_id, status="running", progress=0, current="Preparing library inventory")
            source_root = safe_root(cfg.source_path, "Source path")
            output_root = safe_root(cfg.output_path, "Output path")
            if not source_root.is_dir():
                raise RuntimeError(f"Source path is not available: {source_root}")
            output_root.mkdir(parents=True, exist_ok=True)

            jellyfin_paths, jellyfin_identities, warnings = await jellyfin_inventory(cfg)
            for warning in warnings:
                record_conflict(job_id, "agent_warning", warning)
                counters["conflicts"] += 1

            files: list[Path] = []
            for root, dirs, names in os.walk(source_root):
                dirs[:] = [name for name in dirs if not name.startswith(".")]
                for name in names:
                    path = Path(root) / name
                    if path.suffix.lower() in VIDEO_EXTENSIONS:
                        files.append(path)
            files.sort(key=lambda item: str(item).lower())
            with db() as connection:
                prior_active = int(connection.execute(
                    "SELECT COUNT(*) FROM items WHERE source_root=? AND active=1",
                    (str(source_root),),
                ).fetchone()[0] or 0)
            if not files and prior_active:
                raise RuntimeError(
                    f"The source returned zero media files while {prior_active} managed items are active. "
                    "Cleanup was cancelled to protect against an unavailable or empty mount."
                )
            with db() as connection:
                old_roots = [
                    str(row[0])
                    for row in connection.execute(
                        "SELECT DISTINCT source_root FROM items WHERE active=1 AND source_root<>?",
                        (str(source_root),),
                    ).fetchall()
                ]
                if old_roots:
                    connection.execute(
                        "UPDATE items SET active=0,updated_at=? WHERE active=1 AND source_root<>?",
                        (utcnow(), str(source_root)),
                    )
            if old_roots:
                record_conflict(
                    job_id,
                    "agent_warning",
                    "The configured source root changed. Previous inventory rows were retired without deleting their STRM files; matching files can be adopted under the new root.",
                    str(source_root),
                    details={"retired_source_roots": old_roots},
                )
                counters["conflicts"] += 1
            counters["total"] = len(files)
            update_job(job_id, counters=counters, current=f"Found {len(files)} media files")

            now = utcnow()
            seen: set[str] = set()
            for index, source in enumerate(files, start=1):
                if cancel.is_set():
                    update_job(job_id, status="cancelled", progress=int((index - 1) * 100 / max(1, len(files))), counters=counters, finished=True)
                    return
                relative = source.relative_to(source_root).as_posix()
                seen.add(relative)
                update_job(job_id, progress=int((index - 1) * 100 / max(1, len(files))), current=relative, counters=counters)
                try:
                    stat = source.stat()
                    parsed = parse_media(relative)
                    stable_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"galaxytv:{cfg.server_id}:{source_root}:{relative}"))
                    source_hash = hashlib.sha256(f"{relative}\0{stat.st_size}\0{stat.st_mtime_ns}".encode()).hexdigest()
                    strm_path, nfo_path = item_output_paths(output_root, cfg, parsed, source)
                    playback_url = f"{cfg.playback_base_url.rstrip('/')}/media/{stable_id}/stream{source.suffix.lower()}"
                    if cfg.media_token:
                        playback_url += f"?token={quote(cfg.media_token, safe='')}"

                    direct_duplicate = False
                    if cfg.skip_direct_duplicates:
                        normalized_source = str(source)
                        direct_duplicate = normalized_source in jellyfin_paths or parsed["identity"] in jellyfin_identities
                    if direct_duplicate:
                        record_conflict(job_id, "direct_library_duplicate", "Existing direct-media Jellyfin item matched this source; STRM creation was skipped.", str(source), str(strm_path), {"identity": parsed["identity"]})
                        counters["skipped_duplicates"] += 1
                        counters["conflicts"] += 1
                        counters["processed"] += 1
                        continue

                    existing_row = None
                    output_collision = None
                    with db() as connection:
                        existing_row = connection.execute(
                            "SELECT * FROM items WHERE source_root=? AND relative_path=?",
                            (str(source_root), relative),
                        ).fetchone()
                        output_collision = connection.execute(
                            "SELECT * FROM items WHERE strm_path=? AND active=1 AND NOT (source_root=? AND relative_path=?)",
                            (str(strm_path), str(source_root), relative),
                        ).fetchone()

                    moved_from = None
                    if output_collision is not None:
                        previous_source = Path(str(output_collision["source_path"] or ""))
                        same_identity = str(output_collision["identity_key"] or "") == str(parsed["identity"])
                        previous_missing = not previous_source.is_file()
                        if same_identity and previous_missing and int(output_collision["managed"] or 0):
                            moved_from = output_collision
                            with db() as connection:
                                connection.execute(
                                    "UPDATE items SET active=0,missing_since=COALESCE(missing_since,?),updated_at=? WHERE stable_id=?",
                                    (utcnow(), utcnow(), output_collision["stable_id"]),
                                )
                        else:
                            record_conflict(
                                job_id,
                                "identity_collision",
                                "Two source items resolve to the same STRM output path. The later item was skipped.",
                                str(source),
                                str(strm_path),
                                {"existing_source": str(output_collision["source_path"] or "")},
                            )
                            counters["conflicts"] += 1
                            counters["processed"] += 1
                            continue

                    marker = managed_nfo_info(nfo_path)
                    newly_adopted = False
                    if existing_row is not None and not int(existing_row["managed"] or 0) and strm_path.exists():
                        managed = 0
                    elif strm_path.exists() and not marker:
                        existing_content = strm_path.read_text(encoding="utf-8", errors="ignore").strip()
                        exact_existing_target = existing_content in {
                            str(source),
                            source.as_uri() if source.is_absolute() else "",
                            playback_url,
                        }
                        if cfg.adopt_existing and (exact_existing_target or cfg.job_type == "adopt"):
                            newly_adopted = existing_row is None
                            managed = 0
                        else:
                            record_conflict(job_id, "user_managed_strm", "An unmarked STRM already occupies the expected output path and was not overwritten.", str(source), str(strm_path), {"existing_target": existing_content[:1000]})
                            counters["conflicts"] += 1
                            counters["processed"] += 1
                            continue
                    else:
                        managed = 1

                    marker_matches = bool(
                        marker
                        and strm_path.is_file()
                        and marker.get("source_hash") == source_hash
                        and (not marker.get("source_path") or marker.get("source_path") == relative)
                    )
                    unchanged = (
                        existing_row is not None
                        and str(existing_row["source_hash"]) == source_hash
                        and strm_path.is_file()
                        and (nfo_path.is_file() or not managed)
                    ) or (existing_row is None and marker_matches)

                    if newly_adopted or (existing_row is None and marker_matches):
                        counters["adopted"] += 1

                    if cfg.job_type == "cleanup":
                        if existing_row is not None:
                            with db() as connection:
                                connection.execute(
                                    "UPDATE items SET active=1,missing_since=NULL,last_seen_at=?,updated_at=? WHERE stable_id=?",
                                    (now, now, existing_row["stable_id"]),
                                )
                        counters["unchanged"] += 1
                        counters["processed"] += 1
                        continue

                    if cfg.job_type == "verify":
                        if unchanged:
                            counters["unchanged"] += 1
                        else:
                            record_conflict(
                                job_id,
                                "agent_warning",
                                "The managed inventory or generated STRM/NFO files do not match the current source. Run Sync to repair this item.",
                                str(source),
                                str(strm_path),
                                {"inventory_exists": existing_row is not None, "strm_exists": strm_path.is_file(), "nfo_exists": nfo_path.is_file()},
                            )
                            counters["conflicts"] += 1
                        counters["processed"] += 1
                        continue

                    if cfg.job_type == "adopt" and existing_row is None and not strm_path.exists():
                        counters["unchanged"] += 1
                        counters["processed"] += 1
                        continue

                    if unchanged and cfg.job_type != "full":
                        if not (existing_row is None and marker_matches):
                            counters["unchanged"] += 1
                    else:
                        if managed:
                            atomic_write(strm_path, playback_url + "\n")
                            atomic_write(nfo_path, nfo_bytes(parsed, cfg.server_id, source_hash, relative))
                            if existing_row is not None and int(existing_row["managed"] or 0):
                                old_strm_text = str(existing_row["strm_path"] or "")
                                old_nfo_text = str(existing_row["nfo_path"] or "")
                                if old_strm_text and Path(old_strm_text) != strm_path:
                                    Path(old_strm_text).unlink(missing_ok=True)
                                if old_nfo_text and Path(old_nfo_text) != nfo_path:
                                    Path(old_nfo_text).unlink(missing_ok=True)
                        if newly_adopted or (existing_row is None and marker_matches):
                            pass
                        elif moved_from is not None:
                            counters["updated"] += 1
                        elif existing_row is None:
                            counters["added"] += 1
                        else:
                            counters["updated"] += 1

                    with db() as connection:
                        connection.execute(
                            """
                            INSERT INTO items(stable_id,source_root,source_path,relative_path,media_kind,identity_key,title,series_title,production_year,season_number,episode_number,tmdb_id,imdb_id,source_size,source_mtime_ns,source_hash,strm_path,nfo_path,playback_url,active,managed,missing_since,last_seen_at,last_built_at,updated_at)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,NULL,?,?,?)
                            ON CONFLICT(source_root,relative_path) DO UPDATE SET
                                stable_id=excluded.stable_id,source_path=excluded.source_path,media_kind=excluded.media_kind,
                                identity_key=excluded.identity_key,title=excluded.title,series_title=excluded.series_title,
                                production_year=excluded.production_year,season_number=excluded.season_number,episode_number=excluded.episode_number,
                                tmdb_id=excluded.tmdb_id,imdb_id=excluded.imdb_id,source_size=excluded.source_size,
                                source_mtime_ns=excluded.source_mtime_ns,source_hash=excluded.source_hash,strm_path=excluded.strm_path,
                                nfo_path=excluded.nfo_path,playback_url=excluded.playback_url,active=1,managed=excluded.managed,
                                missing_since=NULL,last_seen_at=excluded.last_seen_at,last_built_at=excluded.last_built_at,updated_at=excluded.updated_at
                            """,
                            (
                                stable_id, str(source_root), str(source), relative, parsed["kind"], parsed["identity"], parsed["title"],
                                parsed["series_title"], parsed.get("year"), parsed.get("season"), parsed.get("episode"),
                                parsed.get("tmdb_id") or "", parsed.get("imdb_id") or "", stat.st_size, stat.st_mtime_ns,
                                source_hash, str(strm_path), str(nfo_path), playback_url, managed, now, now, now,
                            ),
                        )
                    counters["processed"] += 1
                except Exception as exc:
                    counters["failed"] += 1
                    counters["processed"] += 1
                    record_conflict(job_id, "agent_warning", f"Failed to process source item: {exc}", str(source))
                    counters["conflicts"] += 1

                if index % 20 == 0 or index == len(files):
                    update_job(job_id, progress=int(index * 100 / max(1, len(files))), counters=counters, current=relative)

            grace_cutoff = datetime.now(timezone.utc) - timedelta(days=cfg.missing_grace_days)
            with db() as connection:
                previous = connection.execute("SELECT * FROM items WHERE source_root=? AND active=1", (str(source_root),)).fetchall()
            for row in previous:
                if row["relative_path"] in seen:
                    continue
                counters["missing"] += 1
                missing_since = row["missing_since"]
                if not missing_since:
                    with db() as connection:
                        connection.execute("UPDATE items SET missing_since=?,updated_at=? WHERE stable_id=?", (utcnow(), utcnow(), row["stable_id"]))
                    continue
                try:
                    missing_dt = datetime.fromisoformat(str(missing_since))
                except ValueError:
                    missing_dt = datetime.now(timezone.utc)
                if cfg.remove_missing and missing_dt <= grace_cutoff and int(row["managed"] or 0):
                    for filename in (row["strm_path"], row["nfo_path"]):
                        if filename:
                            Path(filename).unlink(missing_ok=True)
                    with db() as connection:
                        connection.execute("UPDATE items SET active=0,updated_at=? WHERE stable_id=?", (utcnow(), row["stable_id"]))
                    counters["removed"] += 1

            for root, dirs, files_in_dir in os.walk(output_root, topdown=False):
                path = Path(root)
                if path == output_root:
                    continue
                try:
                    if not any(path.iterdir()):
                        path.rmdir()
                except OSError:
                    pass

            refresh = "not_needed"
            if counters["added"] or counters["updated"] or counters["removed"]:
                refresh = await refresh_jellyfin(cfg)
            conflicts = []
            with db() as connection:
                rows = connection.execute("SELECT source_path,output_path,conflict_type,message,details,created_at FROM conflicts WHERE job_id=? ORDER BY id LIMIT 500", (job_id,)).fetchall()
                conflicts = [{**dict(row), "details": json.loads(row["details"] or "{}")} for row in rows]
            result = {
                "server_id": cfg.server_id,
                "source_path": str(source_root),
                "output_path": str(output_root),
                "jellyfin_refresh": refresh,
                "counters": counters,
                "conflicts": conflicts,
                "missing_grace_days": cfg.missing_grace_days,
            }
            final_status = "warning" if counters["failed"] or counters["conflicts"] else "completed"
            update_job(job_id, status=final_status, progress=100, current="Complete", counters=counters, result=result, finished=True)
    except Exception as exc:
        update_job(job_id, status="failed", error=str(exc), result={"counters": counters}, counters=counters, finished=True)
    finally:
        job_tasks.pop(job_id, None)
        job_cancel.pop(job_id, None)


@app.get("/health")
async def health() -> dict[str, Any]:
    return {"service": "GalaxyTV Per-Server Library Agent", "version": VERSION, "status": "ok"}


@app.get("/status")
async def status(x_library_token: str | None = Header(default=None)) -> dict[str, Any]:
    require_agent_token(x_library_token)
    with db() as connection:
        latest = connection.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT 1").fetchone()
        counts = connection.execute("SELECT COUNT(*) total, SUM(CASE WHEN active=1 THEN 1 ELSE 0 END) active, SUM(CASE WHEN active=1 AND media_kind='movie' THEN 1 ELSE 0 END) movies, SUM(CASE WHEN active=1 AND media_kind='episode' THEN 1 ELSE 0 END) episodes, SUM(CASE WHEN missing_since IS NOT NULL AND active=1 THEN 1 ELSE 0 END) missing FROM items").fetchone()
    return {
        "version": VERSION,
        "latest_job": serialize_job(latest) if latest else None,
        "counts": {key: int(counts[key] or 0) for key in counts.keys()},
        "running": bool(job_tasks),
    }


def serialize_job(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    payload = dict(row)
    payload["counters"] = json.loads(payload.get("counters") or "{}")
    payload["result"] = json.loads(payload.get("result") or "{}")
    return payload


@app.post("/jobs")
async def create_job(payload: JobRequest, x_library_token: str | None = Header(default=None)) -> dict[str, Any]:
    require_agent_token(x_library_token)
    if job_tasks:
        raise HTTPException(status_code=409, detail="A library synchronization job is already running on this agent.")
    job_id = str(uuid.uuid4())
    with db() as connection:
        connection.execute(
            "INSERT INTO jobs(id,job_type,status,created_at) VALUES(?,?,?,?)",
            (job_id, payload.job_type, "queued", utcnow()),
        )
        connection.execute("DELETE FROM conflicts WHERE job_id NOT IN (SELECT id FROM jobs ORDER BY created_at DESC LIMIT 25)")
    job_cancel[job_id] = asyncio.Event()
    task = asyncio.create_task(run_job(job_id, payload))
    job_tasks[job_id] = task
    return {"job_id": job_id, "status": "queued"}


@app.get("/jobs/{job_id}")
async def get_job(job_id: str, x_library_token: str | None = Header(default=None)) -> dict[str, Any]:
    require_agent_token(x_library_token)
    with db() as connection:
        row = connection.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Library job was not found.")
    return serialize_job(row) or {}


@app.post("/jobs/{job_id}/cancel")
async def cancel_job(job_id: str, x_library_token: str | None = Header(default=None)) -> dict[str, Any]:
    require_agent_token(x_library_token)
    event = job_cancel.get(job_id)
    if event:
        event.set()
        return {"job_id": job_id, "status": "cancelling"}
    with db() as connection:
        row = connection.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Library job was not found.")
    return {"job_id": job_id, "status": row["status"]}


@app.api_route("/media/{stable_id}/stream{suffix:path}", methods=["GET", "HEAD"])
async def stream_media(stable_id: uuid.UUID, suffix: str, request: Request, token: str = ""):
    if DEFAULT_MEDIA_TOKEN and token != DEFAULT_MEDIA_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid media token.")
    with db() as connection:
        row = connection.execute("SELECT source_path FROM items WHERE stable_id=? AND active=1", (str(stable_id),)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Media mapping was not found.")
    target = Path(row["source_path"]).resolve()
    if not target.is_file():
        raise HTTPException(status_code=404, detail="Media source is unavailable.")
    media_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    return FileResponse(target, media_type=media_type, filename=target.name, content_disposition_type="inline")
