from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(case_sensitive=False)

    app_name: str = "GalaxyTV Control API"
    app_env: str = "production"
    app_secret: str
    database_url: str
    redis_url: str
    jellyfin_url: str = "http://jellyfin:8096"
    jellyfin_public_url: str = "http://127.0.0.1:8097"
    jellyfin_api_key: str = ""

    panel_admin_username: str = "admin"
    panel_admin_password_hash: str = ""
    session_ttl_hours: int = 12
    cookie_secure: bool = False
    write_actions_enabled: bool = True
    user_sync_interval_seconds: int = 300

    media_scan_mode: str = "auto"
    media_host_path: str = "/mnt/unionfs"
    media_scan_host_root: str = "/mnt/unionfs/Media"
    media_scan_root: str = "/media"
    media_scan_checkers: int = 4
    rclone_remote: str = "union:"
    rclone_config: str = "/config/rclone/rclone.conf"
    mirror_output_root: str = "/strm-library"
    ops_agent_url: str = "http://ops-agent:8191"
    ops_agent_token: str = ""
    library_agent_token: str = ""
    library_media_token: str = ""
    timezone_name: str = "America/Chicago"


settings = Settings()
