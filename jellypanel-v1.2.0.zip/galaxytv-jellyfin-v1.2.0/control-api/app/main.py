from __future__ import annotations

import asyncio
import json
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

import asyncpg
import httpx
import redis.asyncio as redis
from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

from .access import assert_user_in_scope, is_admin, require_admin_role, scoped_reseller_ids
from .jellyfin import request_json
from .migrations import apply_migrations
from .epg_mapper import router as epg_mapper_router
from .m3u import router as m3u_router
from .media import router as media_router
from .mirror import router as mirror_router
from .operations import router as operations_router
from .packages import router as packages_router
from .resellers import router as resellers_router
from .session_operations import router as session_operations_router
from .security import (
    SESSION_COOKIE,
    PanelSession,
    create_session_token,
    ensure_writes_enabled,
    require_session,
    validate_csrf,
    verify_password,
)
from .settings import settings
from .multiserver import ensure_default_server, propagate_policy, propagate_password, delete_assigned_remote_users
from .servers import router as servers_router
from .user_import import router as user_import_router
from .server_libraries import router as server_libraries_router, ensure_server_library_settings, resume_job_monitors
from .worker import process_expirations


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.http = httpx.AsyncClient(timeout=httpx.Timeout(20.0))
    app.state.redis = redis.from_url(settings.redis_url, decode_responses=True)
    app.state.db = None
    app.state.background_tasks = set()

    try:
        app.state.db = await asyncpg.create_pool(
            settings.database_url,
            min_size=1,
            max_size=8,
            command_timeout=20,
        )
        await apply_migrations(app.state.db)
        await ensure_default_server(app.state.db)
        await ensure_server_library_settings(app.state.db)
        for library_task in await resume_job_monitors(app.state.db, app.state.http):
            app.state.background_tasks.add(library_task)
            library_task.add_done_callback(app.state.background_tasks.discard)
        async with app.state.db.acquire() as connection:
            await connection.execute(
                """
                INSERT INTO update_history (version, channel, status, install_type, notes)
                VALUES ('1.2.0', 'stable', 'installed', 'application_start',
                        'Per-server incremental STRM library synchronization with daily schedules, adoption, duplicate checks, and missing-file grace protection.')
                ON CONFLICT (version) DO UPDATE
                SET status = EXCLUDED.status,
                    notes = EXCLUDED.notes
                """
            )
        async with app.state.db.acquire() as connection:
            await connection.execute(
                "UPDATE media_scan_jobs SET status='failed', finished_at=NOW(), error='API restarted during scan.' WHERE status IN ('queued','running')"
            )
        await app.state.redis.delete("galaxytv:media-scan:lock")
        await app.state.redis.delete("galaxytv:mirror:lock")
        await app.state.redis.delete("galaxytv:epg-mapper:lock")
        async with app.state.db.acquire() as connection:
            await connection.execute("UPDATE library_mirror_jobs SET status='failed', finished_at=NOW(), error='API restarted during mirror build.' WHERE status IN ('queued','running')")
            await connection.execute("UPDATE epg_mapper_runs SET status='failed', finished_at=NOW(), error='API restarted during EPG mapping scan.' WHERE status IN ('queued','running')")
            await connection.execute("UPDATE jellyfin_user_import_runs SET status='failed', finished_at=NOW(), error='API restarted during user import.' WHERE status='running'")
    except Exception:
        app.state.db = None

    yield

    await app.state.http.aclose()
    await app.state.redis.aclose()
    if app.state.db is not None:
        await app.state.db.close()


app = FastAPI(
    title=settings.app_name,
    version="1.2.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.app_env != "production" else None,
    redoc_url=None,
)


app.include_router(m3u_router)
app.include_router(epg_mapper_router)
app.include_router(media_router)
app.include_router(mirror_router)
app.include_router(operations_router)
app.include_router(packages_router)
app.include_router(resellers_router)
app.include_router(session_operations_router)
app.include_router(servers_router)
app.include_router(user_import_router)
app.include_router(server_libraries_router)


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=128)
    password: str = Field(min_length=1, max_length=512)


class CreateUserRequest(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    password: str = Field(default="", max_length=256)
    expires_at: datetime | None = None
    notes: str = Field(default="", max_length=2000)
    hidden: bool = True
    live_tv: bool = False
    downloads: bool = False
    remote_access: bool = True
    video_transcoding: bool = True
    audio_transcoding: bool = True
    remuxing: bool = True
    max_sessions: int = Field(default=1, ge=0, le=100)

    @field_validator("name")
    @classmethod
    def normalize_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Username cannot be blank")
        return value

    @field_validator("expires_at")
    @classmethod
    def normalize_expiration(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)


class UpdateUserRequest(BaseModel):
    expires_at: datetime | None = None
    clear_expiration: bool = False
    notes: str | None = Field(default=None, max_length=2000)
    hidden: bool | None = None
    disabled: bool | None = None
    live_tv: bool | None = None
    downloads: bool | None = None
    remote_access: bool | None = None
    video_transcoding: bool | None = None
    audio_transcoding: bool | None = None
    remuxing: bool | None = None
    max_sessions: int | None = Field(default=None, ge=0, le=100)

    @field_validator("expires_at")
    @classmethod
    def normalize_expiration(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)


class PasswordRequest(BaseModel):
    password: str = Field(min_length=1, max_length=256)


async def check_database() -> tuple[bool, str]:
    if app.state.db is None:
        return False, "pool unavailable"
    try:
        async with app.state.db.acquire() as connection:
            value = await connection.fetchval("SELECT 1")
        return value == 1, "connected"
    except Exception as exc:
        return False, str(exc)


async def check_redis() -> tuple[bool, str]:
    try:
        value = await app.state.redis.ping()
        return bool(value), "connected"
    except Exception as exc:
        return False, str(exc)


async def write_session(
    session: PanelSession = Depends(require_session),
    csrf_token: str | None = Header(default=None, alias="X-CSRF-Token"),
) -> PanelSession:
    ensure_writes_enabled()
    validate_csrf(session, csrf_token)
    return session


async def audit(
    action: str,
    *,
    actor: str = "system",
    target_type: str | None = None,
    target_id: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    if app.state.db is None:
        return
    async with app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, $2, $3, $4, $5::jsonb)
            """,
            actor,
            action,
            target_type,
            target_id,
            json.dumps(details or {}),
        )


async def get_jellyfin_user(user_id: str) -> dict[str, Any]:
    try:
        uuid.UUID(user_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid Jellyfin user ID.") from exc
    user = await request_json(
        app.state.http,
        "GET",
        f"Users/{user_id}",
        require_key=True,
        expected_statuses=(200,),
    )
    return user


def assert_non_admin(user: dict[str, Any]) -> None:
    policy = user.get("Policy") or {}
    if policy.get("IsAdministrator", False):
        raise HTTPException(
            status_code=403,
            detail="Administrator accounts are protected from panel write actions.",
        )


def apply_create_policy(policy: dict[str, Any], request: CreateUserRequest) -> dict[str, Any]:
    policy.update(
        {
            "IsAdministrator": False,
            "IsHidden": request.hidden,
            "IsDisabled": False,
            "EnableMediaPlayback": True,
            "EnableLiveTvAccess": request.live_tv,
            "EnableLiveTvManagement": False,
            "EnableContentDownloading": request.downloads,
            "EnableRemoteAccess": request.remote_access,
            "EnableVideoPlaybackTranscoding": request.video_transcoding,
            "EnableAudioPlaybackTranscoding": request.audio_transcoding,
            "EnablePlaybackRemuxing": request.remuxing,
            "MaxActiveSessions": request.max_sessions,
            "EnableContentDeletion": False,
            "EnableCollectionManagement": False,
            "EnableSubtitleManagement": False,
            "EnablePublicSharing": False,
            "EnableAllChannels": True,
            "EnableAllFolders": True,
        }
    )
    return policy


def apply_update_policy(policy: dict[str, Any], request: UpdateUserRequest) -> dict[str, Any]:
    mapping = {
        "hidden": "IsHidden",
        "disabled": "IsDisabled",
        "live_tv": "EnableLiveTvAccess",
        "downloads": "EnableContentDownloading",
        "remote_access": "EnableRemoteAccess",
        "video_transcoding": "EnableVideoPlaybackTranscoding",
        "audio_transcoding": "EnableAudioPlaybackTranscoding",
        "remuxing": "EnablePlaybackRemuxing",
        "max_sessions": "MaxActiveSessions",
    }
    values = request.model_dump(exclude_unset=True)
    for source, destination in mapping.items():
        if source in values and values[source] is not None:
            policy[destination] = values[source]
    policy["IsAdministrator"] = False
    policy["EnableLiveTvManagement"] = False
    policy["EnableContentDeletion"] = False
    return policy


def normalize_jellyfin_user_id(value: Any) -> str:
    """Return one canonical key for Jellyfin compact GUIDs and PostgreSQL UUIDs."""
    if value is None:
        return ""
    try:
        return uuid.UUID(str(value)).hex
    except (ValueError, TypeError, AttributeError):
        return str(value).replace("-", "").strip().lower()


def safe_user(user: dict[str, Any], managed: dict[str, Any] | None = None) -> dict[str, Any]:
    policy = user.get("Policy") or {}
    managed = managed or {}
    return {
        "id": user.get("Id"),
        "name": user.get("Name"),
        "has_password": user.get("HasPassword"),
        "last_login_date": user.get("LastLoginDate"),
        "last_activity_date": user.get("LastActivityDate"),
        "is_administrator": policy.get("IsAdministrator", False),
        "is_hidden": policy.get("IsHidden", False),
        "is_disabled": policy.get("IsDisabled", False),
        "live_tv": policy.get("EnableLiveTvAccess", False),
        "downloads": policy.get("EnableContentDownloading", False),
        "remote_access": policy.get("EnableRemoteAccess", False),
        "video_transcoding": policy.get("EnableVideoPlaybackTranscoding", False),
        "audio_transcoding": policy.get("EnableAudioPlaybackTranscoding", False),
        "remuxing": policy.get("EnablePlaybackRemuxing", False),
        "max_sessions": policy.get("MaxActiveSessions", 0),
        "managed": bool(managed),
        "expires_at": managed.get("expires_at"),
        "notes": managed.get("notes") or "",
        "disabled_by_expiration": managed.get("disabled_by_expiration", False),
        "package_id": str(managed.get("package_id")) if managed.get("package_id") else None,
        "package_name": managed.get("package_name"),
        "reseller_id": str(managed.get("reseller_id")) if managed.get("reseller_id") else None,
        "reseller_username": managed.get("reseller_username"),
        "server_count": int(managed.get("server_count") or 0),
        "server_sync_failures": int(managed.get("server_sync_failures") or 0),
    }


@app.get("/health")
async def health() -> JSONResponse:
    db_result, redis_result = await asyncio.gather(check_database(), check_redis())
    db_ok, db_message = db_result
    redis_ok, redis_message = redis_result
    overall = db_ok and redis_ok
    return JSONResponse(
        status_code=200 if overall else 503,
        content={
            "service": settings.app_name,
            "version": "1.2.0",
            "timezone": settings.timezone_name,
            "status": "ok" if overall else "degraded",
            "database": {"ok": db_ok, "message": db_message},
            "redis": {"ok": redis_ok, "message": redis_message},
        },
    )


@app.post("/auth/login")
async def login(request_data: LoginRequest, request: Request, response: Response) -> dict[str, Any]:
    remote_ip = request.headers.get("x-real-ip") or (request.client.host if request.client else "unknown")
    key = f"panel-login:{remote_ip}"
    attempts = int(await app.state.redis.get(key) or 0)
    if attempts >= 10:
        raise HTTPException(status_code=429, detail="Too many login attempts. Try again in five minutes.")

    login_username = request_data.username.strip()
    role = "admin"
    account_id: str | None = None
    valid = (
        login_username == settings.panel_admin_username
        and verify_password(request_data.password, settings.panel_admin_password_hash)
    )
    if not valid and app.state.db is not None:
        async with app.state.db.acquire() as connection:
            account = await connection.fetchrow(
                "SELECT id::text, username, password_hash, role, enabled FROM panel_accounts WHERE LOWER(username)=LOWER($1)",
                login_username,
            )
        if account and account["enabled"] and verify_password(request_data.password, account["password_hash"]):
            valid = True
            login_username = account["username"]
            role = account["role"]
            account_id = account["id"]

    if not valid:
        attempts = await app.state.redis.incr(key)
        if attempts == 1:
            await app.state.redis.expire(key, 300)
        await asyncio.sleep(0.35)
        raise HTTPException(status_code=401, detail="Invalid panel username or password.")

    await app.state.redis.delete(key)
    token, session = create_session_token(login_username, role=role, account_id=account_id)
    response.set_cookie(
        key=SESSION_COOKIE,
        value=token,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="strict",
        max_age=max(1, settings.session_ttl_hours) * 3600,
        path="/",
    )
    await audit("panel.login", actor=session.username, details={"remote_ip": remote_ip})
    return {"authenticated": True, "username": session.username, "role": session.role, "account_id": session.account_id, "csrf_token": session.csrf}


@app.post("/auth/logout")
async def logout(
    response: Response,
    session: PanelSession = Depends(require_session),
) -> dict[str, bool]:
    response.delete_cookie(SESSION_COOKIE, path="/")
    await audit("panel.logout", actor=session.username)
    return {"logged_out": True}


@app.get("/auth/me")
async def auth_me(session: PanelSession = Depends(require_session)) -> dict[str, Any]:
    return {
        "authenticated": True,
        "username": session.username,
        "role": session.role,
        "account_id": session.account_id,
        "expires_at": datetime.fromtimestamp(session.expires_at, tz=timezone.utc),
        "csrf_token": session.csrf,
        "write_actions_enabled": settings.write_actions_enabled,
    }


@app.get("/config")
async def config(_: PanelSession = Depends(require_session)) -> dict[str, Any]:
    return {
        "environment": settings.app_env,
        "jellyfin_internal_url": settings.jellyfin_url,
        "jellyfin_public_url": settings.jellyfin_public_url,
        "jellyfin_api_key_configured": bool(settings.jellyfin_api_key),
        "write_actions_enabled": settings.write_actions_enabled,
        "version": "1.2.0",
        "timezone": settings.timezone_name,
    }


@app.post("/maintenance/expirations/run")
async def run_expiration_check(
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    require_admin_role(session)
    if app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    stats = await process_expirations(app.state.db, app.state.http)
    await audit(
        "maintenance.expiration_check",
        actor=session.username,
        details=stats,
    )
    return {"ok": True, **stats}


@app.get("/jellyfin/status")
async def jellyfin_status(_: PanelSession = Depends(require_session)) -> dict[str, Any]:
    public_info = await request_json(
        app.state.http,
        "GET",
        "System/Info/Public",
        expected_statuses=(200,),
    )
    return {
        "reachable": True,
        "api_key_configured": bool(settings.jellyfin_api_key),
        "public_url": settings.jellyfin_public_url,
        "server": public_info,
    }


@app.get("/jellyfin/users")
async def jellyfin_users(session: PanelSession = Depends(require_session)) -> dict[str, Any]:
    users = await request_json(
        app.state.http,
        "GET",
        "Users",
        require_key=True,
        expected_statuses=(200,),
    )
    managed_map: dict[str, dict[str, Any]] = {}
    allowed_user_keys: set[str] | None = None
    if app.state.db is not None:
        async with app.state.db.acquire() as connection:
            scope = await scoped_reseller_ids(connection, session)
            params: list[Any] = []
            where = "WHERE m.managed = TRUE"
            if scope is not None:
                params.append(scope)
                where += " AND m.reseller_id = ANY($1::uuid[])"
            rows = await connection.fetch(
                f"""
                SELECT m.jellyfin_user_id::text, m.expires_at, m.notes,
                       m.disabled_by_expiration, m.package_id::text,
                       m.reseller_id::text, p.name AS package_name,
                       a.username AS reseller_username,
                       (SELECT COUNT(*) FROM server_user_assignments sua
                        WHERE sua.jellyfin_user_id=m.jellyfin_user_id AND sua.sync_enabled=TRUE) AS server_count,
                       (SELECT COUNT(*) FROM server_user_assignments sua
                        WHERE sua.jellyfin_user_id=m.jellyfin_user_id AND sua.last_sync_status='failed') AS server_sync_failures
                FROM managed_jellyfin_users m
                LEFT JOIN account_packages p ON p.id = m.package_id
                LEFT JOIN panel_accounts a ON a.id = m.reseller_id
                {where}
                """,
                *params,
            )
        managed_map = {
            normalize_jellyfin_user_id(row["jellyfin_user_id"]): dict(row)
            for row in rows
        }
        if not is_admin(session):
            allowed_user_keys = set(managed_map)

    result = []
    for user in users:
        key = normalize_jellyfin_user_id(user.get("Id"))
        if allowed_user_keys is not None and key not in allowed_user_keys:
            continue
        result.append(safe_user(user, managed_map.get(key)))
    return {"count": len(result), "users": result}


@app.post("/jellyfin/users", status_code=status.HTTP_201_CREATED)
async def create_user(
    request_data: CreateUserRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    if app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    require_admin_role(session)

    created = await request_json(
        app.state.http,
        "POST",
        "Users/New",
        require_key=True,
        json_data={"Name": request_data.name, "Password": request_data.password or None},
        expected_statuses=(200,),
    )
    user_id = created.get("Id")
    if not user_id:
        raise HTTPException(status_code=502, detail="Jellyfin created a user without returning an ID.")

    try:
        policy = apply_create_policy(dict(created.get("Policy") or {}), request_data)
        expired_now = bool(
            request_data.expires_at
            and request_data.expires_at <= datetime.now(timezone.utc)
        )
        if expired_now:
            policy["IsDisabled"] = True

        await request_json(
            app.state.http,
            "POST",
            f"Users/{user_id}/Policy",
            require_key=True,
            json_data=policy,
            expected_statuses=(204,),
        )
        async with app.state.db.acquire() as connection:
            await connection.execute(
                """
                INSERT INTO managed_jellyfin_users
                    (jellyfin_user_id, expires_at, max_sessions, managed, notes, created_by, disabled_by_expiration)
                VALUES ($1, $2, $3, TRUE, $4, $5, $6)
                ON CONFLICT (jellyfin_user_id) DO UPDATE SET
                    expires_at = EXCLUDED.expires_at,
                    max_sessions = EXCLUDED.max_sessions,
                    managed = TRUE,
                    notes = EXCLUDED.notes,
                    disabled_by_expiration = EXCLUDED.disabled_by_expiration,
                    updated_at = NOW()
                """,
                uuid.UUID(user_id),
                request_data.expires_at,
                request_data.max_sessions,
                request_data.notes,
                session.username,
                expired_now,
            )
        await ensure_default_server(app.state.db)
        await ensure_server_library_settings(app.state.db)
        for library_task in await resume_job_monitors(app.state.db, app.state.http):
            app.state.background_tasks.add(library_task)
            library_task.add_done_callback(app.state.background_tasks.discard)
        await audit(
            "jellyfin.user.create",
            actor=session.username,
            target_type="jellyfin_user",
            target_id=user_id,
            details={
                "name": request_data.name,
                "expires_at": request_data.expires_at.isoformat() if request_data.expires_at else None,
                "live_tv": request_data.live_tv,
                "downloads": request_data.downloads,
                "max_sessions": request_data.max_sessions,
            },
        )
    except Exception:
        try:
            await request_json(
                app.state.http,
                "DELETE",
                f"Users/{user_id}",
                require_key=True,
                expected_statuses=(204,),
            )
        except Exception:
            pass
        raise

    current = await get_jellyfin_user(user_id)
    return safe_user(
        current,
        {
            "expires_at": request_data.expires_at,
            "notes": request_data.notes,
            "disabled_by_expiration": expired_now,
        },
    )


@app.put("/jellyfin/users/{user_id}")
async def update_user(
    user_id: str,
    request_data: UpdateUserRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    if app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    if not is_admin(session):
        raise HTTPException(status_code=403, detail="Resellers must renew users by assigning an available package.")

    user = await get_jellyfin_user(user_id)
    assert_non_admin(user)
    policy = apply_update_policy(dict(user.get("Policy") or {}), request_data)

    async with app.state.db.acquire() as connection:
        existing = await connection.fetchrow(
            """
            SELECT expires_at, notes, disabled_by_expiration
            FROM managed_jellyfin_users
            WHERE jellyfin_user_id = $1
            """,
            uuid.UUID(user_id),
        )

    expires_at = None if request_data.clear_expiration else request_data.expires_at
    if not request_data.clear_expiration and "expires_at" not in request_data.model_fields_set:
        expires_at = existing["expires_at"] if existing else None
    notes = request_data.notes if request_data.notes is not None else (existing["notes"] if existing else "")
    disabled_by_expiration = bool(existing and existing["disabled_by_expiration"])

    requested_disabled = (
        request_data.disabled
        if "disabled" in request_data.model_fields_set
        else None
    )
    now = datetime.now(timezone.utc)
    if expires_at is not None and expires_at <= now:
        # Enforce a past/current expiration immediately on Save instead of
        # waiting for the five-minute worker cycle. Do not claim ownership of
        # a disable that the panel administrator explicitly marked manual.
        explicitly_manual_disabled = (
            requested_disabled is True
            and policy.get("IsDisabled", False)
            and not disabled_by_expiration
        )
        if not explicitly_manual_disabled:
            policy["IsDisabled"] = True
            disabled_by_expiration = True
    elif disabled_by_expiration:
        if requested_disabled is True:
            # The administrator is replacing an expiration disable with a manual disable.
            disabled_by_expiration = False
        else:
            policy["IsDisabled"] = False
            disabled_by_expiration = False

    await request_json(
        app.state.http,
        "POST",
        f"Users/{user_id}/Policy",
        require_key=True,
        json_data=policy,
        expected_statuses=(204,),
    )

    async with app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO managed_jellyfin_users
                (jellyfin_user_id, expires_at, max_sessions, managed, notes, created_by, disabled_by_expiration)
            VALUES ($1, $2, $3, TRUE, $4, $5, $6)
            ON CONFLICT (jellyfin_user_id) DO UPDATE SET
                expires_at = EXCLUDED.expires_at,
                max_sessions = EXCLUDED.max_sessions,
                managed = TRUE,
                notes = EXCLUDED.notes,
                disabled_by_expiration = EXCLUDED.disabled_by_expiration,
                updated_at = NOW()
            """,
            uuid.UUID(user_id),
            expires_at,
            int(policy.get("MaxActiveSessions", 0)),
            notes,
            session.username,
            disabled_by_expiration,
        )

    remote_sync = await propagate_policy(
        app.state.db, app.state.http, uuid.UUID(user_id), policy
    )
    await audit(
        "jellyfin.user.update",
        actor=session.username,
        target_type="jellyfin_user",
        target_id=user_id,
        details={
            "name": user.get("Name"),
            "changes": request_data.model_dump(exclude_unset=True, mode="json"),
            "remote_sync": remote_sync,
        },
    )
    current = await get_jellyfin_user(user_id)
    return safe_user(
        current,
        {
            "expires_at": expires_at,
            "notes": notes,
            "disabled_by_expiration": disabled_by_expiration,
        },
    )


@app.post("/jellyfin/users/{user_id}/password")
async def set_user_password(
    user_id: str,
    request_data: PasswordRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, bool]:
    user = await get_jellyfin_user(user_id)
    assert_non_admin(user)
    if app.state.db is not None:
        async with app.state.db.acquire() as connection:
            await assert_user_in_scope(connection, session, uuid.UUID(user_id))
    await request_json(
        app.state.http,
        "POST",
        f"Users/{user_id}/Password",
        require_key=True,
        json_data={"CurrentPw": "", "NewPw": request_data.password, "ResetPassword": False},
        expected_statuses=(204,),
    )
    remote_sync = await propagate_password(
        app.state.db, app.state.http, uuid.UUID(user_id), request_data.password
    ) if app.state.db is not None else {"synced": 0, "failed": 0}
    await audit(
        "jellyfin.user.password_set",
        actor=session.username,
        target_type="jellyfin_user",
        target_id=user_id,
        details={"name": user.get("Name"), "remote_sync": remote_sync},
    )
    return {"updated": True, "remote_sync": remote_sync}


@app.delete("/jellyfin/users/{user_id}")
async def delete_user(
    user_id: str,
    session: PanelSession = Depends(write_session),
) -> dict[str, bool]:
    user = await get_jellyfin_user(user_id)
    assert_non_admin(user)
    if app.state.db is not None:
        async with app.state.db.acquire() as connection:
            await assert_user_in_scope(connection, session, uuid.UUID(user_id))
    remote_delete = await delete_assigned_remote_users(
        app.state.db, app.state.http, uuid.UUID(user_id)
    ) if app.state.db is not None else {"deleted": 0, "failed": 0}
    await request_json(
        app.state.http,
        "DELETE",
        f"Users/{user_id}",
        require_key=True,
        expected_statuses=(204,),
    )
    if app.state.db is not None:
        async with app.state.db.acquire() as connection:
            await connection.execute(
                "DELETE FROM managed_jellyfin_users WHERE jellyfin_user_id = $1",
                uuid.UUID(user_id),
            )
    await audit(
        "jellyfin.user.delete",
        actor=session.username,
        target_type="jellyfin_user",
        target_id=user_id,
        details={"name": user.get("Name"), "remote_delete": remote_delete},
    )
    return {"deleted": True, "remote_delete": remote_delete}


@app.get("/jellyfin/sessions")
async def jellyfin_sessions(session: PanelSession = Depends(require_session)) -> dict[str, Any]:
    sessions = await request_json(
        app.state.http,
        "GET",
        "Sessions",
        require_key=True,
        expected_statuses=(200,),
    )
    allowed_names: set[str] | None = None
    if not is_admin(session):
        allowed_names = set()
        if app.state.db is not None:
            async with app.state.db.acquire() as connection:
                scope = await scoped_reseller_ids(connection, session)
                rows = await connection.fetch(
                    """
                    SELECT m.jellyfin_user_id::text
                    FROM managed_jellyfin_users m
                    WHERE m.reseller_id = ANY($1::uuid[])
                    """,
                    scope or [],
                )
            allowed_ids = {normalize_jellyfin_user_id(row["jellyfin_user_id"]) for row in rows}
            all_users = await request_json(
                app.state.http,
                "GET",
                "Users",
                require_key=True,
                expected_statuses=(200,),
            )
            allowed_names = {
                str(user.get("Name") or "")
                for user in all_users
                if normalize_jellyfin_user_id(user.get("Id")) in allowed_ids
            }

    safe_sessions = []
    for current in sessions:
        if allowed_names is not None and str(current.get("UserName") or "") not in allowed_names:
            continue
        now_playing = current.get("NowPlayingItem") or {}
        safe_sessions.append(
            {
                "id": current.get("Id"),
                "user_name": current.get("UserName"),
                "client": current.get("Client"),
                "device_name": current.get("DeviceName"),
                "application_version": current.get("ApplicationVersion"),
                "remote_endpoint": current.get("RemoteEndPoint"),
                "last_activity_date": current.get("LastActivityDate"),
                "now_playing": now_playing.get("Name"),
                "media_type": now_playing.get("MediaType"),
            }
        )
    return {"count": len(safe_sessions), "sessions": safe_sessions}


@app.get("/audit")
async def audit_events(
    limit: int = 100,
    session: PanelSession = Depends(require_session),
) -> dict[str, Any]:
    require_admin_role(session)
    if app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    limit = max(1, min(limit, 500))
    async with app.state.db.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT id::text, actor_type, actor_id, action, target_type, target_id, details, created_at
            FROM audit_log
            ORDER BY created_at DESC
            LIMIT $1
            """,
            limit,
        )
    events = []
    for row in rows:
        event = dict(row)
        if isinstance(event.get("details"), str):
            try:
                event["details"] = json.loads(event["details"])
            except json.JSONDecodeError:
                pass
        events.append(event)
    return {"count": len(events), "events": events}
