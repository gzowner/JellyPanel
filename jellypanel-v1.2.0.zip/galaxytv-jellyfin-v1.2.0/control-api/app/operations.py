from __future__ import annotations

import json
from datetime import time
from typing import Any

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator

from .access import require_admin_role
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf
from .settings import settings
from .multiserver import all_server_sessions

router = APIRouter(prefix="/operations", tags=["operations"])


class OperationsSettingsRequest(BaseModel):
    nightly_enabled: bool = True
    nightly_time: str = Field(default="03:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    retention_daily: int = Field(default=7, ge=1, le=90)
    retention_weekly: int = Field(default=4, ge=0, le=52)
    include_mirror: bool = False
    low_disk_gb: int = Field(default=20, ge=1, le=10000)

    @field_validator("nightly_time")
    @classmethod
    def validate_time(cls, value: str) -> str:
        hour, minute = value.split(":", 1)
        time(int(hour), int(minute))
        return value


class BackupRequest(BaseModel):
    include_mirror: bool | None = None


class RestoreRequest(BaseModel):
    confirmation: str


async def require_admin(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


async def write_admin(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


async def ops_request(
    request: Request,
    method: str,
    path: str,
    *,
    json_data: dict[str, Any] | None = None,
    expected: tuple[int, ...] = (200,),
    timeout: float = 30.0,
) -> Any:
    if not settings.ops_agent_token:
        raise HTTPException(status_code=503, detail="Operations agent token is not configured.")
    try:
        response = await request.app.state.http.request(
            method,
            f"{settings.ops_agent_url.rstrip('/')}/{path.lstrip('/')}",
            headers={"X-Ops-Token": settings.ops_agent_token},
            json=json_data,
            timeout=timeout,
        )
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail=f"Operations agent unavailable: {exc}") from exc
    if response.status_code not in expected:
        try:
            detail = response.json().get("detail")
        except Exception:
            detail = response.text[:500]
        raise HTTPException(status_code=response.status_code, detail=detail or "Operations agent request failed.")
    if response.status_code == 204 or not response.content:
        return {}
    return response.json()


async def get_settings_row(request: Request) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        row = await connection.fetchrow(
            """
            SELECT nightly_enabled,
                   to_char(nightly_time, 'HH24:MI') AS nightly_time,
                   retention_daily,
                   retention_weekly,
                   include_mirror,
                   low_disk_gb,
                   updated_at,
                   updated_by
            FROM operations_settings
            WHERE id = 1
            """
        )
    if not row:
        raise HTTPException(status_code=500, detail="Operations settings are missing.")
    return dict(row)


@router.get("/settings")
async def get_operations_settings(request: Request, _: PanelSession = Depends(require_admin)) -> dict[str, Any]:
    return await get_settings_row(request)


@router.put("/settings")
async def update_operations_settings(
    payload: OperationsSettingsRequest,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        async with connection.transaction():
            await connection.execute(
                """
                UPDATE operations_settings
                SET nightly_enabled = $1,
                    nightly_time = $2::time,
                    retention_daily = $3,
                    retention_weekly = $4,
                    include_mirror = $5,
                    low_disk_gb = $6,
                    updated_at = NOW(),
                    updated_by = $7
                WHERE id = 1
                """,
                payload.nightly_enabled,
                payload.nightly_time,
                payload.retention_daily,
                payload.retention_weekly,
                payload.include_mirror,
                payload.low_disk_gb,
                session.username,
            )
            await connection.execute(
                """
                INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
                VALUES ('panel', $1, 'operations.settings.updated', 'operations', 'settings', $2::jsonb)
                """,
                session.username,
                json.dumps(payload.model_dump()),
            )
    return await get_settings_row(request)


@router.get("/status")
async def operations_status(request: Request, _: PanelSession = Depends(require_admin)) -> dict[str, Any]:
    agent = await ops_request(request, "GET", "status", expected=(200,), timeout=15)
    async with request.app.state.db.acquire() as connection:
        latest_scan = await connection.fetchrow(
            """
            SELECT id, status, files_seen, media_files, added_count, changed_count, missing_count,
                   error, started_at, finished_at, created_at
            FROM media_scan_jobs
            ORDER BY created_at DESC
            LIMIT 1
            """
        )
        latest_mirror = await connection.fetchrow(
            """
            SELECT id, status, total_items, processed_items, movies_written, episodes_written,
                   failed_items, error, started_at, finished_at, created_at
            FROM library_mirror_jobs
            ORDER BY created_at DESC
            LIMIT 1
            """
        )
        m3u = await connection.fetchrow(
            """
            SELECT COUNT(*) FILTER (WHERE enabled) AS enabled_sources,
                   COUNT(*) FILTER (WHERE enabled AND last_error IS NOT NULL) AS failed_sources,
                   COUNT(*) FILTER (WHERE enabled AND epg_enabled AND last_epg_error IS NOT NULL) AS failed_epg,
                   MAX(last_refreshed_at) AS last_m3u_refresh,
                   MAX(last_epg_checked_at) AS last_epg_check
            FROM m3u_sources
            """
        )
        mirror_counts = await connection.fetchrow(
            """
            SELECT COUNT(*) FILTER (WHERE active) AS active,
                   COUNT(*) FILTER (WHERE active AND metadata_status = 'unmatched') AS unmatched,
                   COUNT(*) FILTER (WHERE active AND metadata_status = 'error') AS errors
            FROM library_mirror_items
            """
        )
    try:
        sessions, server_failures = await all_server_sessions(
            request.app.state.db, request.app.state.http
        )
        active_sessions = len(sessions)
    except Exception as exc:
        active_sessions = None
        server_failures = [{"server_name": "all", "error": str(exc)[:500]}]
    agent["application"] = {
        "latest_scan": dict(latest_scan) if latest_scan else None,
        "latest_mirror": dict(latest_mirror) if latest_mirror else None,
        "m3u": dict(m3u) if m3u else {},
        "mirror": dict(mirror_counts) if mirror_counts else {},
        "active_sessions": active_sessions,
        "server_failures": server_failures,
    }
    return agent


@router.get("/backups")
async def backups(request: Request, _: PanelSession = Depends(require_admin)) -> dict[str, Any]:
    return await ops_request(request, "GET", "backups", expected=(200,), timeout=15)


@router.post("/backups", status_code=status.HTTP_202_ACCEPTED)
async def create_backup(
    payload: BackupRequest,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    cfg = await get_settings_row(request)
    body = {
        "backup_type": "manual",
        "requested_by": session.username,
        "include_mirror": cfg["include_mirror"] if payload.include_mirror is None else payload.include_mirror,
        "retention_daily": cfg["retention_daily"],
        "retention_weekly": cfg["retention_weekly"],
    }
    result = await ops_request(request, "POST", "backups", json_data=body, expected=(202,), timeout=15)
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, 'operations.backup.started', 'backup_job', $2, $3::jsonb)
            """,
            session.username,
            result.get("job_id"),
            json.dumps(body),
        )
    return result


@router.get("/jobs/{job_id}")
async def operation_job(job_id: str, request: Request, _: PanelSession = Depends(require_admin)) -> dict[str, Any]:
    return await ops_request(request, "GET", f"jobs/{job_id}", expected=(200,), timeout=15)


@router.delete("/backups/{backup_id}")
async def delete_backup(
    backup_id: str,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    result = await ops_request(request, "DELETE", f"backups/{backup_id}", expected=(200,), timeout=30)
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, 'operations.backup.deleted', 'backup', $2, '{}'::jsonb)
            """,
            session.username,
            backup_id,
        )
    return result


@router.post("/backups/{backup_id}/restore", status_code=status.HTTP_202_ACCEPTED)
async def restore_backup(
    backup_id: str,
    payload: RestoreRequest,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    result = await ops_request(
        request,
        "POST",
        f"backups/{backup_id}/restore",
        json_data={"requested_by": session.username, "confirmation": payload.confirmation},
        expected=(202,),
        timeout=15,
    )
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, 'operations.restore.started', 'backup', $2, $3::jsonb)
            """,
            session.username,
            backup_id,
            json.dumps({"job_id": result.get("job_id")}),
        )
    return result


@router.post("/services/{service}/restart", status_code=status.HTTP_202_ACCEPTED)
async def restart_service(
    service: str,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    result = await ops_request(request, "POST", f"services/{service}/restart", json_data={}, expected=(202,), timeout=15)
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, 'operations.service.restart', 'service', $2, '{}'::jsonb)
            """,
            session.username,
            service,
        )
    return result


@router.post("/diagnostics")
async def create_diagnostics(
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    result = await ops_request(
        request,
        "POST",
        "diagnostics",
        json_data={"requested_by": session.username},
        expected=(200,),
        timeout=120,
    )
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, 'operations.diagnostics.created', 'diagnostics', NULL, $2::jsonb)
            """,
            session.username,
            json.dumps({"path": result.get("path"), "size_bytes": result.get("size_bytes")}),
        )
    return result


@router.get("/updates")
async def update_history(request: Request, _: PanelSession = Depends(require_admin)) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        schema_version = await connection.fetchval(
            "SELECT COALESCE(MAX(version), 0) FROM schema_version"
        )
        rows = await connection.fetch(
            """
            SELECT id, version, channel, status, install_type, notes, installed_at
            FROM update_history
            ORDER BY installed_at DESC, id DESC
            LIMIT 100
            """
        )
    return {
        "current_version": "1.2.0",
        "schema_version": int(schema_version or 0),
        "channel": "stable",
        "updates": [dict(row) for row in rows],
    }
