# GalaxyTV Jellyfin v1.2.0 — Per-Server Library Sync

GalaxyTV v1.2.0 is a cumulative upgrade from v1.1.1. It keeps the complete multi-server control panel and adds an independent, incremental STRM library workflow for every registered Jellyfin server.

## What v1.2.0 adds

- A **Server Libraries** page for all registered Jellyfin servers.
- One media source path and one STRM destination per server.
- A lightweight GalaxyTV Library Agent for the local server.
- A deployable Library Node for additional Jellyfin servers.
- Daily per-server synchronization at a configurable time.
- Incremental comparison by relative source path, size, modification time, and content fingerprint.
- Existing generated STRM/NFO files remain untouched when the source is unchanged.
- Matching pre-existing STRM files can be adopted into the managed inventory.
- Unmarked, user-managed STRM files are never overwritten automatically.
- Existing direct-media Jellyfin items are checked before STRM creation to reduce duplicates.
- Missing sources are marked first and removed only after the configured grace period.
- An unavailable or empty mount cannot immediately delete the generated library.
- Per-server conflict reporting for direct-library duplicates, user-managed files, and agent warnings.
- Automatic Jellyfin library refresh only when changes were written or removed.
- Manual Sync, Verify, Adopt, Full, Cleanup, Stop, and Agent Test operations through the API.
- Database schema 16.

The original **Library Mirror** remains available. It is useful for the existing central TMDB-enriched mirror. The new **Server Libraries** feature is the recommended path for independent libraries distributed across several Jellyfin hosts.

## Upgrade from v1.1.1

Upload the ZIP and checksum to `/root`, then run:

```bash
cd /root
sha256sum -c galaxytv-jellyfin-v1.2.0.zip.sha256
unzip -o galaxytv-jellyfin-v1.2.0.zip
cd galaxytv-jellyfin-v1.2.0
sudo bash install.sh --mode upgrade
```

The installer:

1. Creates the normal local and managed pre-upgrade backups.
2. Preserves Jellyfin, PostgreSQL, Redis, backups, STRM output, existing users, servers, packages, M3U, XMLTV, and EPG mappings.
3. Adds the local Library Agent and its persistent SQLite inventory.
4. Applies migration 16.
5. Rebuilds and validates all services.
6. Automatically restores the previous application files if health validation fails.

Afterward, force-refresh the browser with `Ctrl+F5`.

## Local server setup

The upgrade automatically creates a library record for **Local Jellyfin** using:

```text
Agent URL:        http://library-agent:8192
Source path:      /media/Media
STRM output:      /strm-library/local-jellyfin
Playback URL:     http://library-agent:8192
Daily time:       02:00
Missing grace:    7 days
```

The source and output values are paths inside the Library Agent container. The local source is derived from the host media mount and configured media scan root.

Open:

```text
GalaxyTV → Server Libraries → Local Jellyfin → Configure
```

Click **Test**, then run the first **Sync**.

Add the resulting Jellyfin libraries once:

```text
Movies:   /strm-library/local-jellyfin/Movies
TV Shows: /strm-library/local-jellyfin/TV Shows
```

Do not delete or disable the original direct library until the STRM library has been checked for metadata and playback.

## Existing library protection

The first sync checks:

- The Library Agent inventory database.
- Existing `.strm` files.
- Neighboring NFO markers.
- Existing Jellyfin movie and episode identities.
- Source path, title/year, TMDB/IMDb tags, and season/episode identity.

Generated NFO files contain:

```xml
<galaxytvManaged>true</galaxytvManaged>
<galaxytvServerId>SERVER_UUID</galaxytvServerId>
<galaxytvSourceHash>HASH</galaxytvSourceHash>
<galaxytvSourcePath>RELATIVE_SOURCE_PATH</galaxytvSourcePath>
```

An unmarked STRM/NFO pair is considered user-managed. GalaxyTV reports a conflict instead of overwriting it.

## Daily incremental synchronization

The default daily process performs:

```text
Unchanged: leave STRM and NFO files untouched
Added:     create new STRM and NFO files
Changed:   update only the affected entry
Restored:  clear its missing state
Missing:   mark it and start the grace period
Expired:   remove only GalaxyTV-managed files after the grace period
Conflict:  record it without stopping the remaining scan
```

A Jellyfin library refresh is requested only when files were added, updated, or removed.

## Additional Jellyfin servers

Install the Library Node on every additional Jellyfin host:

```bash
cd galaxytv-jellyfin-v1.2.0
sudo bash library-node/install-node.sh
sudo nano /opt/galaxytv-library-node/.env
sudo bash library-node/install-node.sh
```

The first run creates two random credentials and exits so you can edit the configuration. Configure:

```text
MEDIA_PATH                 Host media mount
STRM_PATH                  Host STRM output directory
JELLYFIN_URL               URL reachable from the agent container
JELLYFIN_API_KEY           API key from that Jellyfin server
LIBRARY_PLAYBACK_BASE_URL  URL that Jellyfin can use to reach port 8292
```

The default node port is `8292`. Restrict it by firewall so only the central GalaxyTV server and the local Jellyfin host can reach it. Use a private LAN or WireGuard address, or place the agent behind HTTPS; do not expose the plain HTTP node directly to the public internet.

The remote Jellyfin container must also mount the same host `STRM_PATH` at `/strm-library` (read-only is sufficient). After the first successful sync, add that server's generated folders in Jellyfin, for example:

```text
Movies:   /strm-library/remote-server/Movies
TV Shows: /strm-library/remote-server/TV Shows
```

In GalaxyTV, open **Server Libraries**, configure that server, and enter:

- Library Agent URL, such as `http://10.0.0.25:8292`.
- Playback base URL, usually the same URL.
- Agent token generated by the node installer.
- Media token generated by the node installer.
- Agent source and output paths.

Then click **Test** and run a manual Sync.

## Management commands

```bash
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
sudo /opt/galaxytv-jellyfin/scripts/manage.sh servers
sudo /opt/galaxytv-jellyfin/scripts/manage.sh libraries
sudo /opt/galaxytv-jellyfin/scripts/manage.sh logs
```

Library diagnostics:

```bash
sudo /opt/galaxytv-jellyfin/scripts/check-server-libraries.sh
```

## Missing-file safety

Default behavior:

```text
First missing scan: mark missing
Days 1–6:          retain generated STRM/NFO
Day 7 or later:    remove GalaxyTV-managed STRM/NFO
Source returns:    reactivate automatically
```

Set a longer grace period for unstable cloud or network mounts. GalaxyTV does not remove an unmarked user-managed STRM file.

## Persistent data

The Library Agent inventory is stored at:

```text
/opt/galaxytv-jellyfin/library-agent-state/library-agent.sqlite3
```

This directory survives upgrades, repairs, rollback, and data-preserving uninstall. Managed GalaxyTV backups also include a consistent SQLite snapshot of this inventory so missing-file dates and adoption state can be restored.

## Current limitations

- Remote servers require the supplied Library Node; the central panel cannot scan another machine's filesystem directly.
- Existing Jellyfin passwords are unrelated to library synchronization.
- Direct-library duplicate matching is conservative. Review reported conflicts before disabling an old library.
- The agent generates basic local NFO identity and management markers. The existing central Library Mirror remains available for TMDB-enriched NFO and artwork generation.
- The build environment could not run a real multi-host Docker/Jellyfin deployment. Validate with one local server and one test item before enabling daily sync for a large library.

See [TEST-SERVER-LIBRARIES.md](TEST-SERVER-LIBRARIES.md) for the recommended validation sequence.
