#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="1.1.1"
EXPECTED_SCHEMA_VERSION="15"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_DIR="${GALAXYTV_TARGET_DIR:-/opt/galaxytv-jellyfin}"
ENV_FILE=""
CREDENTIAL_FILE=""
MODE=""
NON_INTERACTIVE=false
ASSUME_YES=false
ALLOW_UNSUPPORTED=false
SKIP_BACKUP=false
BACKUP_ID=""
LAST_SNAPSHOT=""
EXPLICIT_JF_PORT=false
EXPLICIT_PANEL_PORT=false
EXPLICIT_API_PORT=false
EXPLICIT_M3U_PORT=false

CFG_MEDIA_PATH="${GALAXYTV_MEDIA_PATH:-}"
CFG_SCAN_ROOT="${GALAXYTV_SCAN_ROOT:-}"
CFG_RCLONE_REMOTE="${GALAXYTV_RCLONE_REMOTE:-}"
CFG_RCLONE_CONFIG_DIR="${GALAXYTV_RCLONE_CONFIG_DIR:-}"
CFG_TIMEZONE="${GALAXYTV_TIMEZONE:-}"
CFG_JF_PORT="${GALAXYTV_JELLYFIN_PORT:-}"
CFG_PANEL_PORT="${GALAXYTV_PANEL_PORT:-}"
CFG_API_PORT="${GALAXYTV_API_PORT:-}"
CFG_M3U_PORT="${GALAXYTV_M3U_PORT:-}"
CFG_PANEL_USER="${GALAXYTV_PANEL_USER:-}"
CFG_PANEL_PASSWORD="${GALAXYTV_PANEL_PASSWORD:-}"
CFG_INTEL_GPU="${GALAXYTV_ENABLE_INTEL_GPU:-}"

RESET='\033[0m'
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
BOLD='\033[1m'

log() { printf "%b[GalaxyTV]%b %s\n" "$CYAN" "$RESET" "$*"; }
ok() { printf "%b[OK]%b %s\n" "$GREEN" "$RESET" "$*"; }
warn() { printf "%b[WARNING]%b %s\n" "$YELLOW" "$RESET" "$*"; }
die() { printf "%b[ERROR]%b %s\n" "$RED" "$RESET" "$*" >&2; exit 1; }

usage() {
  cat <<EOF_USAGE
GalaxyTV Jellyfin v${VERSION} stable installer

Usage:
  sudo bash install.sh [options]

Modes:
  --mode fresh          Fresh installation
  --mode upgrade        Upgrade an existing installation
  --mode repair         Repair/rebuild an existing installation
  --mode restore        Restore a managed backup
  --mode diagnostics    Export a redacted diagnostics ZIP
  --mode uninstall      Remove containers while preserving all data

Fresh-install options:
  --media-path PATH
  --scan-root PATH
  --rclone-remote NAME:
  --rclone-config-dir PATH
  --timezone IANA_NAME
  --jellyfin-port PORT
  --panel-port PORT
  --api-port PORT
  --m3u-port PORT
  --panel-user USER
  --panel-password PASSWORD
  --enable-intel-gpu | --disable-intel-gpu

Other options:
  --target-dir PATH
  --backup-id UUID
  --skip-backup
  --non-interactive
  --yes
  --allow-unsupported
  -h, --help

For non-interactive installs, password input is safer through:
  GALAXYTV_PANEL_PASSWORD='your password' sudo -E bash install.sh --non-interactive
EOF_USAGE
}

while (($#)); do
  case "$1" in
    --mode) MODE="${2:-}"; shift 2 ;;
    --mode=*) MODE="${1#*=}"; shift ;;
    --target-dir) TARGET_DIR="${2:-}"; shift 2 ;;
    --media-path) CFG_MEDIA_PATH="${2:-}"; shift 2 ;;
    --scan-root) CFG_SCAN_ROOT="${2:-}"; shift 2 ;;
    --rclone-remote) CFG_RCLONE_REMOTE="${2:-}"; shift 2 ;;
    --rclone-config-dir) CFG_RCLONE_CONFIG_DIR="${2:-}"; shift 2 ;;
    --timezone) CFG_TIMEZONE="${2:-}"; shift 2 ;;
    --jellyfin-port) CFG_JF_PORT="${2:-}"; EXPLICIT_JF_PORT=true; shift 2 ;;
    --panel-port) CFG_PANEL_PORT="${2:-}"; EXPLICIT_PANEL_PORT=true; shift 2 ;;
    --api-port) CFG_API_PORT="${2:-}"; EXPLICIT_API_PORT=true; shift 2 ;;
    --m3u-port) CFG_M3U_PORT="${2:-}"; EXPLICIT_M3U_PORT=true; shift 2 ;;
    --panel-user) CFG_PANEL_USER="${2:-}"; shift 2 ;;
    --panel-password) CFG_PANEL_PASSWORD="${2:-}"; shift 2 ;;
    --enable-intel-gpu) CFG_INTEL_GPU=true; shift ;;
    --disable-intel-gpu) CFG_INTEL_GPU=false; shift ;;
    --backup-id) BACKUP_ID="${2:-}"; shift 2 ;;
    --skip-backup) SKIP_BACKUP=true; shift ;;
    --non-interactive) NON_INTERACTIVE=true; shift ;;
    --yes|-y) ASSUME_YES=true; shift ;;
    --allow-unsupported) ALLOW_UNSUPPORTED=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

ENV_FILE="$TARGET_DIR/.env"
CREDENTIAL_FILE="$TARGET_DIR/panel-admin-credentials.txt"

[[ $EUID -eq 0 ]] || die "Run as root: sudo bash install.sh"

is_interactive() {
  [[ "$NON_INTERACTIVE" != true && -t 0 && -t 1 ]]
}

confirm() {
  local prompt="$1" default="${2:-no}" reply
  if [[ "$ASSUME_YES" == true ]]; then return 0; fi
  if ! is_interactive; then [[ "$default" == "yes" ]]; return; fi
  if [[ "$default" == "yes" ]]; then
    read -r -p "$prompt [Y/n]: " reply
    reply="${reply:-y}"
  else
    read -r -p "$prompt [y/N]: " reply
    reply="${reply:-n}"
  fi
  [[ "$reply" =~ ^[Yy]$ ]]
}

prompt_value() {
  local __var="$1" label="$2" default="$3" value
  if ! is_interactive; then
    printf -v "$__var" '%s' "${!__var:-$default}"
    return
  fi
  read -r -p "$label [$default]: " value
  printf -v "$__var" '%s' "${value:-$default}"
}

prompt_secret() {
  local __var="$1" label="$2" value
  if [[ -n "${!__var:-}" ]] || ! is_interactive; then return; fi
  read -r -s -p "$label (leave blank to generate): " value
  echo
  printf -v "$__var" '%s' "$value"
}

set_env_value() {
  local key="$1" value="$2" file="${3:-$ENV_FILE}" escaped
  [[ "$value" != *$'\n'* ]] || die "Environment value for $key contains a newline."
  escaped="${value//\\/\\\\}"
  escaped="${escaped//&/\\&}"
  escaped="${escaped//|/\\|}"
  if grep -qE "^${key}=" "$file" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${escaped}|" "$file"
  else
    printf '%s=%s\n' "$key" "$value" >> "$file"
  fi
}

get_env_value() {
  local key="$1" file="${2:-$ENV_FILE}" value
  value="$(grep -E "^${key}=" "$file" 2>/dev/null | tail -n1 | cut -d= -f2- || true)"
  value="${value#\"}"; value="${value%\"}"
  printf '%s' "$value"
}

have_existing_install() {
  [[ -f "$ENV_FILE" && -f "$TARGET_DIR/compose.yml" ]]
}

verify_source_release() {
  if [[ "$(realpath -m "$SOURCE_DIR")" == "$(realpath -m "$TARGET_DIR")" ]]; then return 0; fi
  if [[ -f "$SOURCE_DIR/release-files.sha256" ]]; then
    log "Verifying stable release files"
    (cd "$SOURCE_DIR" && sha256sum -c --quiet release-files.sha256) || die "Release file verification failed. Download or extract the ZIP again."
    ok "Release file checksums passed."
  else
    warn "Release checksum manifest is absent; continuing without package verification."
  fi
}

print_banner() {
  printf '\n%bGalaxyTV Jellyfin v%s Stable%b\n' "$BOLD$CYAN" "$VERSION" "$RESET"
  printf 'Cumulative Jellyfin, M3U/XMLTV, EPG Mapper, STRM Mirror, Operations, and Stream Management stack.\n\n'
}

choose_mode() {
  if [[ -n "$MODE" ]]; then return; fi
  if ! is_interactive; then
    if have_existing_install; then MODE=upgrade; else MODE=fresh; fi
    return
  fi
  echo "Choose an action:"
  echo "  1) Fresh installation"
  echo "  2) Upgrade existing installation"
  echo "  3) Repair installation"
  echo "  4) Restore managed backup"
  echo "  5) Export diagnostics"
  echo "  6) Uninstall containers and preserve data"
  echo "  7) Exit"
  local choice
  read -r -p "Selection: " choice
  case "$choice" in
    1) MODE=fresh ;;
    2) MODE=upgrade ;;
    3) MODE=repair ;;
    4) MODE=restore ;;
    5) MODE=diagnostics ;;
    6) MODE=uninstall ;;
    *) exit 0 ;;
  esac
}

validate_mode() {
  case "$MODE" in fresh|upgrade|repair|restore|diagnostics|uninstall) ;; *) die "Invalid mode: $MODE" ;; esac
  if [[ "$MODE" != fresh ]] && ! have_existing_install; then
    die "No existing GalaxyTV installation was found at $TARGET_DIR"
  fi
  if [[ "$MODE" == fresh ]] && have_existing_install; then
    die "An installation already exists at $TARGET_DIR. Use upgrade or repair mode."
  fi
}

check_os() {
  local id="unknown" os_version="unknown" arch
  if [[ -r /etc/os-release ]]; then
    id="$(. /etc/os-release; printf '%s' "${ID:-unknown}")"
    os_version="$(. /etc/os-release; printf '%s' "${VERSION_ID:-unknown}")"
  fi
  arch="$(uname -m)"
  case "$arch" in x86_64|aarch64|arm64) ;; *) die "Unsupported CPU architecture: $arch" ;; esac
  if [[ "$id" == ubuntu && "$os_version" == "24.04" ]]; then
    ok "Ubuntu $os_version detected."
    return
  fi
  if [[ "$ALLOW_UNSUPPORTED" == true ]]; then
    warn "Untested operating system: $id $os_version. Continuing by request."
  else
    die "GalaxyTV v1.1.1 is validated for Ubuntu 24.04. Use --allow-unsupported to continue on $id $os_version."
  fi
}

install_dependencies() {
  log "Checking system dependencies"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y ca-certificates curl openssl rsync python3 python3-venv gzip tar unzip zip jq iproute2 findutils coreutils util-linux

  if ! command -v docker >/dev/null 2>&1; then
    log "Installing Docker Engine from Ubuntu packages"
    apt-get install -y docker.io
  fi
  if ! docker compose version >/dev/null 2>&1; then
    log "Installing Docker Compose v2 plugin"
    if ! apt-get install -y docker-compose-v2; then
      apt-get install -y docker-compose-plugin || die "Docker Compose v2 could not be installed."
    fi
  fi
  systemctl enable --now docker
  docker info >/dev/null 2>&1 || die "Docker daemon is not available."
  docker compose version >/dev/null 2>&1 || die "Docker Compose v2 is not available."
  ok "Docker and required packages are available."
}

preflight_disk() {
  mkdir -p "$(dirname "$TARGET_DIR")"
  local available_kb
  available_kb="$(df -Pk "$(dirname "$TARGET_DIR")" | awk 'NR==2 {print $4}')"
  if [[ -n "$available_kb" && "$available_kb" -lt 8388608 ]]; then
    die "At least 8 GB free is required on the GalaxyTV application filesystem."
  fi
  local mem_kb
  mem_kb="$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null || echo 0)"
  if [[ "$mem_kb" -lt 1900000 ]]; then
    warn "Less than 2 GB RAM detected. Four GB or more is recommended."
  fi
}

port_in_use() {
  local port="$1"
  ss -H -lnt 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)$port$"
}

validate_port() {
  local value="$1" name="$2"
  [[ "$value" =~ ^[0-9]+$ && "$value" -ge 1 && "$value" -le 65535 ]] || die "$name must be between 1 and 65535."
}

next_free_port() {
  local port="$1"
  while port_in_use "$port"; do
    port=$((port + 1))
    [[ "$port" -le 65535 ]] || die "No free TCP port was found."
  done
  printf '%s' "$port"
}

resolve_fresh_port() {
  local __var="$1" label="$2" default="$3" explicit="$4" value
  value="${!__var:-$default}"
  validate_port "$value" "$label"
  if port_in_use "$value"; then
    if [[ "$explicit" == true ]]; then
      die "$label $value is already in use."
    fi
    local replacement
    replacement="$(next_free_port "$value")"
    warn "$label $value is in use; using $replacement instead."
    value="$replacement"
  fi
  printf -v "$__var" '%s' "$value"
}

normalize_path() {
  realpath -m -- "$1"
}

ensure_scan_under_media() {
  local media scan
  media="$(normalize_path "$CFG_MEDIA_PATH")"
  scan="$(normalize_path "$CFG_SCAN_ROOT")"
  if [[ "$scan" != "$media" && "$scan" != "$media/"* ]]; then
    die "Media scan root must be inside the media mount. Media: $media ; scan root: $scan"
  fi
  CFG_MEDIA_PATH="$media"
  CFG_SCAN_ROOT="$scan"
}

copy_application() {
  mkdir -p "$TARGET_DIR"
  if [[ "$(realpath -m "$SOURCE_DIR")" == "$(realpath -m "$TARGET_DIR")" ]]; then
    warn "Installer is running from the installed directory; application files will be reused."
    return
  fi
  log "Installing cumulative v${VERSION} application files into $TARGET_DIR"
  rsync -a --delete \
    --exclude '.env' \
    --exclude '.galaxytv-version' \
    --exclude 'install-state.json' \
    --exclude 'panel-admin-credentials.txt' \
    --exclude 'UNINSTALLED' \
    --exclude 'jellyfin/' \
    --exclude 'postgres/data/' \
    --exclude 'redis/' \
    --exclude 'backups/' \
    --exclude 'logs/' \
    --exclude 'strm-library/' \
    "$SOURCE_DIR/" "$TARGET_DIR/"
}

create_data_directories() {
  mkdir -p \
    "$TARGET_DIR/jellyfin/config" \
    "$TARGET_DIR/jellyfin/cache" \
    "$TARGET_DIR/postgres/data" \
    "$TARGET_DIR/redis/data" \
    "$TARGET_DIR/backups/managed/.jobs" \
    "$TARGET_DIR/backups/diagnostics" \
    "$TARGET_DIR/backups/upgrades" \
    "$TARGET_DIR/logs" \
    "$TARGET_DIR/strm-library/Movies" \
    "$TARGET_DIR/strm-library/TV Shows"
  chmod 700 "$TARGET_DIR/backups" "$TARGET_DIR/backups/managed" "$TARGET_DIR/backups/diagnostics" 2>/dev/null || true
}

write_credentials() {
  local username="$1" password="$2"
  umask 077
  cat > "$CREDENTIAL_FILE" <<EOF_CREDS
GalaxyTV Control Panel v${VERSION}
Username: $username
Password: $password
Created: $(date -Is)
EOF_CREDS
  chmod 600 "$CREDENTIAL_FILE"
}

configure_fresh_env() {
  local detected_tz server_ip panel_hash scan_was_supplied=false
  [[ -n "$CFG_SCAN_ROOT" ]] && scan_was_supplied=true
  detected_tz="$(cat /etc/timezone 2>/dev/null || echo America/Chicago)"
  CFG_MEDIA_PATH="${CFG_MEDIA_PATH:-/mnt/unionfs}"
  CFG_SCAN_ROOT="${CFG_SCAN_ROOT:-${CFG_MEDIA_PATH%/}/Media}"
  CFG_RCLONE_REMOTE="${CFG_RCLONE_REMOTE:-union:}"
  CFG_RCLONE_CONFIG_DIR="${CFG_RCLONE_CONFIG_DIR:-/root/.config/rclone}"
  CFG_TIMEZONE="${CFG_TIMEZONE:-$detected_tz}"
  CFG_PANEL_USER="${CFG_PANEL_USER:-admin}"

  prompt_value CFG_MEDIA_PATH "Host media mount" "$CFG_MEDIA_PATH"
  [[ "$scan_was_supplied" == true ]] || CFG_SCAN_ROOT="${CFG_MEDIA_PATH%/}/Media"
  prompt_value CFG_SCAN_ROOT "Media inventory root" "$CFG_SCAN_ROOT"
  prompt_value CFG_RCLONE_REMOTE "Rclone remote" "$CFG_RCLONE_REMOTE"
  prompt_value CFG_RCLONE_CONFIG_DIR "Rclone config directory" "$CFG_RCLONE_CONFIG_DIR"
  prompt_value CFG_TIMEZONE "Server timezone" "$CFG_TIMEZONE"
  prompt_value CFG_PANEL_USER "Panel administrator username" "$CFG_PANEL_USER"
  prompt_secret CFG_PANEL_PASSWORD "Panel administrator password"
  prompt_value CFG_JF_PORT "Jellyfin host port" "${CFG_JF_PORT:-8097}"
  prompt_value CFG_PANEL_PORT "GalaxyTV panel host port" "${CFG_PANEL_PORT:-8181}"
  prompt_value CFG_API_PORT "Local Control API port" "${CFG_API_PORT:-8182}"
  prompt_value CFG_M3U_PORT "Local M3U gateway port" "${CFG_M3U_PORT:-8183}"

  resolve_fresh_port CFG_JF_PORT "Jellyfin port" "8097" "$EXPLICIT_JF_PORT"
  resolve_fresh_port CFG_PANEL_PORT "Panel port" "8181" "$EXPLICIT_PANEL_PORT"
  resolve_fresh_port CFG_API_PORT "Control API port" "8182" "$EXPLICIT_API_PORT"
  resolve_fresh_port CFG_M3U_PORT "M3U gateway port" "8183" "$EXPLICIT_M3U_PORT"

  local ports="$CFG_JF_PORT $CFG_PANEL_PORT $CFG_API_PORT $CFG_M3U_PORT"
  [[ "$(tr ' ' '\n' <<< "$ports" | sort -u | wc -l)" -eq 4 ]] || die "All GalaxyTV ports must be different."
  ensure_scan_under_media

  if [[ -z "$CFG_INTEL_GPU" ]]; then
    if [[ -e /dev/dri ]] && is_interactive && confirm "Enable /dev/dri access for Jellyfin hardware acceleration?" yes; then
      CFG_INTEL_GPU=true
    else
      CFG_INTEL_GPU=false
    fi
  fi
  [[ "$CFG_INTEL_GPU" =~ ^(true|false)$ ]] || die "Intel GPU option must be true or false."
  if [[ "$CFG_INTEL_GPU" == true && ! -e /dev/dri ]]; then
    warn "GPU access was requested but /dev/dri does not exist; disabling it."
    CFG_INTEL_GPU=false
  fi

  mkdir -p "$CFG_MEDIA_PATH" "$CFG_RCLONE_CONFIG_DIR"
  chmod 700 "$CFG_RCLONE_CONFIG_DIR" 2>/dev/null || true
  if ! findmnt -T "$CFG_MEDIA_PATH" >/dev/null 2>&1; then
    warn "$CFG_MEDIA_PATH exists but is not currently reported as a separate mount. GalaxyTV will still install."
  fi

  cp "$TARGET_DIR/.env.example" "$ENV_FILE"
  set_env_value BASE_DIR "$TARGET_DIR"
  set_env_value GALAXYTV_VERSION "$VERSION"
  set_env_value INSTALL_CHANNEL "stable"
  set_env_value TZ "$CFG_TIMEZONE"
  set_env_value MEDIA_PATH "$CFG_MEDIA_PATH"
  set_env_value MEDIA_SCAN_HOST_ROOT "$CFG_SCAN_ROOT"
  set_env_value RCLONE_REMOTE "$CFG_RCLONE_REMOTE"
  set_env_value RCLONE_CONFIG_DIR "$CFG_RCLONE_CONFIG_DIR"
  set_env_value JELLYFIN_HTTP_PORT "$CFG_JF_PORT"
  set_env_value PANEL_HTTP_PORT "$CFG_PANEL_PORT"
  set_env_value CONTROL_API_PORT "$CFG_API_PORT"
  set_env_value M3U_GATEWAY_PORT "$CFG_M3U_PORT"
  set_env_value ENABLE_INTEL_GPU "$CFG_INTEL_GPU"
  set_env_value POSTGRES_PASSWORD "$(openssl rand -hex 24)"
  set_env_value APP_SECRET "$(openssl rand -hex 32)"
  set_env_value GATEWAY_SECRET "$(openssl rand -hex 32)"
  set_env_value OPS_AGENT_TOKEN "$(openssl rand -hex 32)"
  set_env_value PANEL_ADMIN_USERNAME "$CFG_PANEL_USER"

  if [[ -z "$CFG_PANEL_PASSWORD" ]]; then
    CFG_PANEL_PASSWORD="$(openssl rand -hex 12)"
  fi
  panel_hash="$(python3 "$TARGET_DIR/scripts/hash-password.py" "$CFG_PANEL_PASSWORD")"
  set_env_value PANEL_ADMIN_PASSWORD_HASH "$panel_hash"
  set_env_value COOKIE_SECURE "false"
  set_env_value WRITE_ACTIONS_ENABLED "true"

  server_ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  server_ip="${server_ip:-127.0.0.1}"
  set_env_value JELLYFIN_PUBLISHED_URL "http://${server_ip}:${CFG_JF_PORT}"
  write_credentials "$CFG_PANEL_USER" "$CFG_PANEL_PASSWORD"
  chmod 600 "$ENV_FILE"
}

ensure_env_defaults() {
  [[ -f "$ENV_FILE" ]] || die "Missing $ENV_FILE"
  local generated_password="" key
  declare -A defaults=(
    [BASE_DIR]="$TARGET_DIR"
    [GALAXYTV_VERSION]="$VERSION"
    [INSTALL_CHANNEL]="stable"
    [TZ]="America/Chicago"
    [APP_ENV]="production"
    [JELLYFIN_VERSION]="10.11.11"
    [JELLYFIN_BIND_IP]="0.0.0.0"
    [JELLYFIN_HTTP_PORT]="8097"
    [MEDIA_PATH]="/mnt/unionfs"
    [PANEL_BIND_IP]="0.0.0.0"
    [PANEL_HTTP_PORT]="8181"
    [CONTROL_API_PORT]="8182"
    [M3U_GATEWAY_PORT]="8183"
    [POSTGRES_DB]="galaxytv"
    [POSTGRES_USER]="galaxytv"
    [PANEL_ADMIN_USERNAME]="admin"
    [SESSION_TTL_HOURS]="12"
    [COOKIE_SECURE]="false"
    [WRITE_ACTIONS_ENABLED]="true"
    [USER_SYNC_INTERVAL_SECONDS]="300"
    [MEDIA_SCAN_MODE]="auto"
    [MEDIA_SCAN_CHECKERS]="4"
    [RCLONE_REMOTE]="union:"
    [RCLONE_CONFIG_DIR]="/root/.config/rclone"
    [MEDIA_SCAN_HOST_ROOT]="/mnt/unionfs/Media"
    [ENABLE_INTEL_GPU]="false"
  )
  for key in "${!defaults[@]}"; do
    [[ -n "$(get_env_value "$key")" ]] || set_env_value "$key" "${defaults[$key]}"
  done
  set_env_value BASE_DIR "$TARGET_DIR"
  set_env_value GALAXYTV_VERSION "$VERSION"
  set_env_value INSTALL_CHANNEL "stable"

  for key in POSTGRES_PASSWORD APP_SECRET GATEWAY_SECRET OPS_AGENT_TOKEN; do
    value="$(get_env_value "$key")"
    if [[ -z "$value" || "$value" == "CHANGE_ME" ]]; then set_env_value "$key" "$(openssl rand -hex 32)"; fi
  done

  if [[ -z "$(get_env_value PANEL_ADMIN_PASSWORD_HASH)" ]]; then
    generated_password="$(openssl rand -hex 12)"
    set_env_value PANEL_ADMIN_PASSWORD_HASH "$(python3 "$TARGET_DIR/scripts/hash-password.py" "$generated_password")"
    write_credentials "$(get_env_value PANEL_ADMIN_USERNAME)" "$generated_password"
    warn "A new panel password was generated because the existing hash was empty."
  fi

  local media scan rclone_dir
  media="$(normalize_path "$(get_env_value MEDIA_PATH)")"
  scan="$(normalize_path "$(get_env_value MEDIA_SCAN_HOST_ROOT)")"
  if [[ "$scan" != "$media" && "$scan" != "$media/"* ]]; then
    warn "MEDIA_SCAN_HOST_ROOT was outside MEDIA_PATH; resetting it to $media/Media"
    scan="$media/Media"
  fi
  set_env_value MEDIA_PATH "$media"
  set_env_value MEDIA_SCAN_HOST_ROOT "$scan"
  mkdir -p "$media"
  rclone_dir="$(get_env_value RCLONE_CONFIG_DIR)"
  mkdir -p "$rclone_dir"
  chmod 700 "$rclone_dir" 2>/dev/null || true
  chmod 600 "$ENV_FILE"
}

compose() {
  if [[ -x "$TARGET_DIR/scripts/compose.sh" ]]; then
    GALAXYTV_BASE_DIR="$TARGET_DIR" "$TARGET_DIR/scripts/compose.sh" "$@"
  else
    (cd "$TARGET_DIR" && docker compose -f "$TARGET_DIR/compose.yml" --env-file "$ENV_FILE" "$@")
  fi
}

create_local_snapshot() {
  local reason="$1" stamp snapshot db_user db_name
  stamp="$(date +%Y%m%d-%H%M%S)"
  snapshot="$TARGET_DIR/backups/upgrades/${reason}-v${VERSION}-${stamp}"
  mkdir -p "$snapshot/app"
  chmod 700 "$snapshot"
  log "Creating local rollback snapshot at $snapshot"

  for item in install.sh upgrade.sh repair.sh diagnostics.sh uninstall.sh compose.yml compose.intel-gpu.yml .env VERSION README.md control-api control-web m3u-gateway media-gateway ops-agent postgres scripts; do
    [[ -e "$TARGET_DIR/$item" ]] || continue
    cp -a "$TARGET_DIR/$item" "$snapshot/app/"
  done
  cp -a "$ENV_FILE" "$snapshot/env.snapshot"

  if compose ps postgres >/dev/null 2>&1; then
    db_user="$(get_env_value POSTGRES_USER)"; db_name="$(get_env_value POSTGRES_DB)"
    if ! compose exec -T postgres pg_dump -U "${db_user:-galaxytv}" "${db_name:-galaxytv}" | gzip > "$snapshot/galaxytv-db.sql.gz"; then
      warn "The local PostgreSQL snapshot failed. Managed backup will still be attempted."
      rm -f "$snapshot/galaxytv-db.sql.gz"
    fi
  fi
  cat > "$snapshot/snapshot.info" <<EOF_SNAPSHOT
version_before=$(cat "$TARGET_DIR/.galaxytv-version" 2>/dev/null || echo unknown)
version_target=$VERSION
reason=$reason
created_at=$(date -Is)
source=$SOURCE_DIR
EOF_SNAPSHOT
  LAST_SNAPSHOT="$snapshot"
}

request_managed_backup() {
  [[ "$SKIP_BACKUP" == true ]] && { warn "Managed pre-upgrade backup skipped by request."; return 0; }
  if ! compose ps ops-agent >/dev/null 2>&1; then
    warn "Operations Agent is unavailable; continuing with the local rollback snapshot only."
    return 0
  fi
  log "Requesting a managed pre-upgrade backup"
  if ! compose exec -T ops-agent python - <<'PY'
import json, os, time, urllib.request
body=json.dumps({"backup_type":"pre_upgrade","requested_by":"stable-installer","include_mirror":False,"retention_daily":7,"retention_weekly":4}).encode()
headers={"Content-Type":"application/json","X-Ops-Token":os.environ["OPS_AGENT_TOKEN"]}
req=urllib.request.Request("http://127.0.0.1:8191/backups", data=body, method="POST", headers=headers)
try:
    with urllib.request.urlopen(req, timeout=30) as response:
        job=json.load(response)
except Exception as exc:
    print(f"Managed backup request failed: {exc}")
    raise SystemExit(1)
job_id=job["job_id"]
print(f"Managed backup job: {job_id}")
for _ in range(180):
    req=urllib.request.Request(f"http://127.0.0.1:8191/jobs/{job_id}", headers={"X-Ops-Token":os.environ["OPS_AGENT_TOKEN"]})
    with urllib.request.urlopen(req, timeout=20) as response:
        state=json.load(response)
    status=state.get("status")
    step=state.get("current_step")
    print(f"  {status}: {step}", flush=True)
    if status == "completed":
        raise SystemExit(0)
    if status == "failed":
        print(state.get("error") or "Managed backup failed")
        raise SystemExit(1)
    time.sleep(5)
print("Managed backup timed out.")
raise SystemExit(1)
PY
  then
    warn "Managed backup did not complete. The local rollback snapshot is still available."
  else
    ok "Managed pre-upgrade backup completed."
  fi
}

restore_application_snapshot() {
  local snapshot="$1"
  [[ -d "$snapshot/app" ]] || { warn "Rollback snapshot is incomplete: $snapshot"; return 1; }
  warn "Deployment validation failed. Restoring the previous application files automatically."
  rsync -a --delete \
    --exclude '.env' --exclude 'jellyfin/' --exclude 'postgres/data/' --exclude 'redis/' \
    --exclude 'backups/' --exclude 'logs/' --exclude 'strm-library/' \
    "$snapshot/app/" "$TARGET_DIR/"
  [[ -f "$snapshot/env.snapshot" ]] && cp -a "$snapshot/env.snapshot" "$ENV_FILE"
  chmod 600 "$ENV_FILE" 2>/dev/null || true
  rm -f "$TARGET_DIR/UNINSTALLED"
  if [[ -x "$TARGET_DIR/scripts/compose.sh" ]]; then
    compose config --quiet || true
    compose up -d --build --remove-orphans || true
  else
    (cd "$TARGET_DIR" && docker compose -f compose.yml --env-file .env up -d --build --remove-orphans) || true
  fi
  warn "Previous application files were restored. Additive PostgreSQL migrations were not removed."
}

pull_build_start() {
  cd "$TARGET_DIR"
  log "Validating Docker Compose configuration"
  compose config --quiet
  log "Pulling published container images"
  compose pull --ignore-buildable
  log "Building GalaxyTV services"
  compose build --pull
  log "Starting GalaxyTV"
  compose up -d --remove-orphans
}

wait_http() {
  local url="$1" label="$2" attempts="${3:-90}"
  for _ in $(seq 1 "$attempts"); do
    if curl -fsS --max-time 5 "$url" >/dev/null 2>&1; then ok "$label is responding."; return 0; fi
    sleep 2
  done
  warn "$label did not become ready: $url"
  return 1
}

wait_internal_health() {
  local service="$1" port="$2" label="$3" attempts="${4:-90}"
  for _ in $(seq 1 "$attempts"); do
    if compose exec -T "$service" python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:${port}/health', timeout=5)" >/dev/null 2>&1; then
      ok "$label is responding."
      return 0
    fi
    sleep 2
  done
  warn "$label did not become ready."
  return 1
}

validate_stack() {
  local failed=0 api_port m3u_port panel_port jf_port db_user db_name schema
  api_port="$(get_env_value CONTROL_API_PORT)"; m3u_port="$(get_env_value M3U_GATEWAY_PORT)"
  panel_port="$(get_env_value PANEL_HTTP_PORT)"; jf_port="$(get_env_value JELLYFIN_HTTP_PORT)"

  wait_internal_health ops-agent 8191 "Operations Agent" 90 || failed=1
  wait_http "http://127.0.0.1:${api_port}/health" "Control API" 90 || failed=1
  wait_http "http://127.0.0.1:${m3u_port}/health" "M3U Gateway" 60 || failed=1
  wait_internal_health media-gateway 8190 "Media Gateway" 60 || failed=1
  wait_http "http://127.0.0.1:${jf_port}/System/Info/Public" "Jellyfin" 90 || failed=1
  wait_http "http://127.0.0.1:${panel_port}/" "GalaxyTV panel" 60 || failed=1

  db_user="$(get_env_value POSTGRES_USER)"; db_name="$(get_env_value POSTGRES_DB)"
  schema="$(compose exec -T postgres psql -U "${db_user:-galaxytv}" -d "${db_name:-galaxytv}" -tAc 'SELECT COALESCE(MAX(version),0) FROM schema_version;' 2>/dev/null | tr -d '[:space:]' || true)"
  if [[ "$schema" == "$EXPECTED_SCHEMA_VERSION" ]]; then
    ok "Database migrations are current at schema $schema."
  else
    warn "Expected database schema $EXPECTED_SCHEMA_VERSION but found ${schema:-unavailable}."
    failed=1
  fi

  local service state
  for service in galaxytv-jellyfin galaxytv-postgres galaxytv-redis galaxytv-control-api galaxytv-control-worker galaxytv-m3u-gateway galaxytv-media-gateway galaxytv-ops-agent galaxytv-control-web; do
    state="$(docker inspect -f '{{.State.Status}}' "$service" 2>/dev/null || true)"
    if [[ "$state" != running ]]; then warn "$service is not running."; failed=1; fi
  done

  return "$failed"
}

write_install_state() {
  local mode="$1" server_ip
  server_ip="$(hostname -I 2>/dev/null | awk '{print $1}')"; server_ip="${server_ip:-127.0.0.1}"
  printf '%s\n' "$VERSION" > "$TARGET_DIR/.galaxytv-version"
  python3 - "$TARGET_DIR/install-state.json" "$mode" "$VERSION" "$server_ip" \
    "$(get_env_value PANEL_HTTP_PORT)" "$(get_env_value JELLYFIN_HTTP_PORT)" \
    "$(get_env_value MEDIA_PATH)" "$(get_env_value MEDIA_SCAN_HOST_ROOT)" <<'PY'
import json, sys
from datetime import datetime, timezone
path, mode, version, ip, panel_port, jellyfin_port, media, scan = sys.argv[1:]
payload = {
    "version": version,
    "channel": "stable",
    "last_mode": mode,
    "updated_at": datetime.now(timezone.utc).isoformat(),
    "panel_url": f"http://{ip}:{panel_port}",
    "jellyfin_url": f"http://{ip}:{jellyfin_port}",
    "media_path": media,
    "scan_root": scan,
}
with open(path, "w", encoding="utf-8") as handle:
    json.dump(payload, handle, indent=2)
PY
  rm -f "$TARGET_DIR/UNINSTALLED"
}

show_completion() {
  local server_ip panel_port jf_port
  server_ip="$(hostname -I 2>/dev/null | awk '{print $1}')"; server_ip="${server_ip:-127.0.0.1}"
  panel_port="$(get_env_value PANEL_HTTP_PORT)"; jf_port="$(get_env_value JELLYFIN_HTTP_PORT)"
  cat <<EOF_DONE

GalaxyTV Jellyfin v${VERSION} Stable is ready.

Control panel: http://${server_ip}:${panel_port}
Jellyfin:      http://${server_ip}:${jf_port}

Management:
  sudo $TARGET_DIR/scripts/manage.sh status
  sudo $TARGET_DIR/scripts/manage.sh health
  sudo $TARGET_DIR/scripts/manage.sh logs

Panel credentials:
  sudo cat $CREDENTIAL_FILE

The first Jellyfin visit may show its normal setup wizard. HTTPS remains optional and is not enabled for this local/default installation.
EOF_DONE
}

run_fresh() {
  check_os
  install_dependencies
  preflight_disk
  copy_application
  create_data_directories
  configure_fresh_env
  if ! pull_build_start || ! validate_stack; then
    compose ps || true
    compose logs --tail=250 control-api control-worker ops-agent postgres jellyfin m3u-gateway media-gateway || true
    die "Fresh installation did not pass validation. Data was preserved at $TARGET_DIR for repair and diagnostics."
  fi
  write_install_state fresh
  show_completion
}

run_upgrade_or_repair() {
  local reason="$1" snapshot
  check_os
  install_dependencies
  preflight_disk
  create_data_directories
  create_local_snapshot "$reason"
  snapshot="$LAST_SNAPSHOT"
  request_managed_backup
  copy_application
  create_data_directories
  ensure_env_defaults
  if ! pull_build_start || ! validate_stack; then
    compose logs --tail=250 control-api control-worker ops-agent postgres jellyfin m3u-gateway media-gateway > "$snapshot/failed-deployment.log" 2>&1 || true
    restore_application_snapshot "$snapshot" || true
    die "The $reason failed validation and application files were rolled back. Snapshot: $snapshot"
  fi
  write_install_state "$reason"
  ok "GalaxyTV $reason to v${VERSION} completed."
  echo "Rollback snapshot: $snapshot"
  show_completion
}

ensure_ops_agent() {
  compose up -d postgres jellyfin ops-agent
  for _ in $(seq 1 90); do
    if compose exec -T ops-agent python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8191/health', timeout=5)" >/dev/null 2>&1; then return 0; fi
    sleep 2
  done
  die "Operations Agent could not be started."
}

list_managed_backups() {
  python3 - "$TARGET_DIR/backups/managed" <<'PY'
import json, pathlib, sys
root=pathlib.Path(sys.argv[1])
items=[]
for manifest in root.glob("*/manifest.json"):
    try:
        data=json.loads(manifest.read_text(encoding="utf-8"))
        if data.get("status") == "completed":
            items.append((data.get("created_at", ""), data, manifest.parent.name))
    except Exception:
        pass
items.sort(reverse=True)
for idx, (_, data, directory) in enumerate(items, 1):
    print(f"{idx}\t{data.get('id','')}\t{data.get('created_at','')}\t{data.get('backup_type','')}\t{directory}\t{data.get('warning') or ''}")
PY
}

run_restore() {
  check_os
  install_dependencies
  ensure_ops_agent
  local lines selected count choice job_id
  lines="$(list_managed_backups)"
  [[ -n "$lines" ]] || die "No completed managed backups were found under $TARGET_DIR/backups/managed"
  echo "Available restore points:"
  while IFS=$'\t' read -r idx id created type directory warning_text; do
    printf '  %s) %s  %-11s  %s\n' "$idx" "$created" "$type" "$directory"
    [[ -n "$warning_text" ]] && printf '     Warning: %s\n' "$warning_text"
  done <<< "$lines"

  if [[ -z "$BACKUP_ID" ]]; then
    if ! is_interactive; then die "Use --backup-id UUID for non-interactive restore."; fi
    read -r -p "Restore selection number: " choice
    [[ "$choice" =~ ^[0-9]+$ ]] || die "Invalid selection."
    selected="$(awk -F '\t' -v n="$choice" '$1==n {print $2}' <<< "$lines")"
    BACKUP_ID="$selected"
  fi
  [[ -n "$BACKUP_ID" ]] || die "Backup ID was not found."
  confirm "Restore backup $BACKUP_ID? GalaxyTV services will restart" no || die "Restore cancelled."

  job_id="$(compose exec -T ops-agent python - "$BACKUP_ID" <<'PY'
import json, os, sys, urllib.request
backup_id=sys.argv[1]
body=json.dumps({"requested_by":"stable-installer","confirmation":"RESTORE"}).encode()
req=urllib.request.Request(f"http://127.0.0.1:8191/backups/{backup_id}/restore",data=body,method="POST",headers={"Content-Type":"application/json","X-Ops-Token":os.environ["OPS_AGENT_TOKEN"]})
with urllib.request.urlopen(req, timeout=30) as response:
    print(json.load(response)["job_id"])
PY
)" || die "Restore request failed."
  [[ -n "$job_id" ]] || die "Restore request returned no job ID."
  log "Restore job $job_id started"
  compose exec -T ops-agent python - "$job_id" <<'PY'
import json, os, sys, time, urllib.request
job_id=sys.argv[1]
headers={"X-Ops-Token":os.environ["OPS_AGENT_TOKEN"]}
for _ in range(240):
    req=urllib.request.Request(f"http://127.0.0.1:8191/jobs/{job_id}",headers=headers)
    with urllib.request.urlopen(req,timeout=20) as response:
        state=json.load(response)
    print(f"{state.get('status')}: {state.get('current_step')}",flush=True)
    if state.get("status") == "completed": raise SystemExit(0)
    if state.get("status") == "failed":
        print(state.get("error") or "Restore failed")
        raise SystemExit(1)
    time.sleep(5)
print("Restore timed out.")
raise SystemExit(1)
PY
  compose up -d --remove-orphans
  validate_stack || warn "Restore completed, but one or more health checks still require attention."
  write_install_state restore
  ok "Restore completed."
}

run_diagnostics() {
  install_dependencies
  create_data_directories
  if compose ps ops-agent >/dev/null 2>&1; then
    if "$TARGET_DIR/scripts/export-diagnostics.sh"; then return; fi
  fi
  warn "Operations Agent diagnostics were unavailable; creating a host-side diagnostic archive."
  "$TARGET_DIR/scripts/export-diagnostics.sh" --host-only
}

run_uninstall() {
  install_dependencies
  confirm "Remove GalaxyTV containers while preserving all databases, configuration, backups, and media mappings?" no || die "Uninstall cancelled."
  compose down --remove-orphans
  cat > "$TARGET_DIR/UNINSTALLED" <<EOF_UNINSTALL
GalaxyTV containers removed on $(date -Is).
All bind-mounted data remains in $TARGET_DIR.
Run the v1.1.1 installer in repair mode to restore services.
EOF_UNINSTALL
  ok "GalaxyTV containers were removed. All data remains under $TARGET_DIR."
  echo "Reinstall with: sudo bash install.sh --mode repair"
}

print_banner
choose_mode
validate_mode
verify_source_release
case "$MODE" in
  fresh) run_fresh ;;
  upgrade) run_upgrade_or_repair upgrade ;;
  repair) run_upgrade_or_repair repair ;;
  restore) run_restore ;;
  diagnostics) run_diagnostics ;;
  uninstall) run_uninstall ;;
esac
