#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/galaxytv-jellyfin"
ENV_FILE="$BASE_DIR/.env"
[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "GalaxyTV installation not found at $BASE_DIR" >&2; exit 1; }

get_env() {
  grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2-
}

POSTGRES_USER="$(get_env POSTGRES_USER)"
POSTGRES_DB="$(get_env POSTGRES_DB)"
POSTGRES_USER="${POSTGRES_USER:-galaxytv}"
POSTGRES_DB="${POSTGRES_DB:-galaxytv}"

cd "$BASE_DIR"

echo "=== Managed user expiration records ==="
docker compose --env-file .env exec -T postgres \
  psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -P pager=off -c \
  "SELECT jellyfin_user_id, managed, expires_at, disabled_by_expiration, last_policy_sync_at, updated_at FROM managed_jellyfin_users ORDER BY expires_at NULLS LAST;"

echo
echo "=== Expiration worker container ==="
docker compose --env-file .env ps control-worker

echo
echo "=== Recent expiration worker logs ==="
docker compose --env-file .env logs --tail=100 control-worker

echo
echo "=== Recent expiration audit events ==="
docker compose --env-file .env exec -T postgres \
  psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -P pager=off -c \
  "SELECT created_at, action, target_id, details FROM audit_log WHERE action LIKE '%expir%' ORDER BY created_at DESC LIMIT 25;"
