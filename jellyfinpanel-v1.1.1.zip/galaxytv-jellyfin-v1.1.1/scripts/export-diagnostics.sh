#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${GALAXYTV_BASE_DIR:-/opt/galaxytv-jellyfin}"
ENV_FILE="$BASE_DIR/.env"
COMPOSE="$BASE_DIR/scripts/compose.sh"
HOST_ONLY=false
[[ "${1:-}" == "--host-only" ]] && HOST_ONLY=true
OUT_DIR="$BASE_DIR/backups/diagnostics"
mkdir -p "$OUT_DIR"
chmod 700 "$OUT_DIR" 2>/dev/null || true

if [[ "$HOST_ONLY" != true ]] && "$COMPOSE" ps ops-agent >/dev/null 2>&1; then
  result="$("$COMPOSE" exec -T ops-agent python - <<'PY'
import json, os, urllib.request
body=json.dumps({"requested_by":"stable-installer"}).encode()
req=urllib.request.Request('http://127.0.0.1:8191/diagnostics',data=body,method='POST',headers={'Content-Type':'application/json','X-Ops-Token':os.environ['OPS_AGENT_TOKEN']})
with urllib.request.urlopen(req,timeout=240) as response:
    print(json.dumps(json.load(response)))
PY
)" || true
  if [[ -n "$result" ]]; then
    container_path="$(python3 -c 'import json,sys; print(json.loads(sys.stdin.read()).get("path", ""))' <<< "$result" 2>/dev/null || true)"
    host_path="${container_path/\/galaxytv/$BASE_DIR}"
    if [[ -f "$host_path" ]]; then
      echo "Diagnostics created: $host_path"
      exit 0
    fi
  fi
fi

stamp="$(date +%Y%m%d-%H%M%S)"
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
mkdir -p "$work/logs"

{
  echo "GalaxyTV host diagnostics"
  echo "Created: $(date -Is)"
  echo "Installed version: $(cat "$BASE_DIR/.galaxytv-version" 2>/dev/null || echo unknown)"
  echo "Kernel: $(uname -a)"
  echo "OS:"
  cat /etc/os-release 2>/dev/null || true
  echo
  docker version 2>&1 || true
  docker compose version 2>&1 || true
  echo
  df -h 2>&1 || true
  echo
  free -h 2>&1 || true
} > "$work/system.txt"

if [[ -f "$ENV_FILE" ]]; then
  sed -E 's/^([^#=]*(PASS|PASSWORD|SECRET|TOKEN|KEY)[^=]*)=.*/\1=[REDACTED]/I' "$ENV_FILE" > "$work/env.redacted"
fi
"$COMPOSE" config > "$work/compose.rendered.txt" 2>&1 || true
"$COMPOSE" ps -a > "$work/compose.ps.txt" 2>&1 || true
"$BASE_DIR/scripts/health-check.sh" > "$work/health-check.txt" 2>&1 || true
"$BASE_DIR/scripts/check-servers.sh" > "$work/jellyfin-servers.txt" 2>&1 || true
for c in $(docker ps -a --filter 'label=com.docker.compose.project=galaxytv-jellyfin' --format '{{.Names}}' 2>/dev/null); do
  docker logs --tail=400 --timestamps "$c" > "$work/logs/$c.log" 2>&1 || true
done
python3 - "$work" <<'PY'
import pathlib,re,sys
root=pathlib.Path(sys.argv[1])
patterns=[
    (re.compile(r'(?i)(password|passwd|token|api[_-]?key|secret)=([^&\s]+)'),r'\1=[REDACTED]'),
    (re.compile(r'(?i)(/live|/movie|/series)/[^/\s]+/[^/\s]+/'),r'\1/[USER]/[PASS]/'),
    (re.compile(r'(?i)(username=)[^&\s]+'),r'\1[USER]'),
]
for path in root.rglob('*'):
    if not path.is_file(): continue
    text=path.read_text(encoding='utf-8',errors='replace')
    for pattern,repl in patterns: text=pattern.sub(repl,text)
    path.write_text(text,encoding='utf-8')
PY
output="$OUT_DIR/galaxytv-diagnostics-host-$stamp.zip"
(cd "$work" && zip -qr "$output" .)
chmod 600 "$output"
echo "Diagnostics created: $output"
