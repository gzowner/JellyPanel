#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/galaxytv-jellyfin"
ENV_FILE="$BASE_DIR/.env"

[[ $EUID -eq 0 ]] || { echo "Run with sudo/root." >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "$ENV_FILE was not found." >&2; exit 1; }
[[ $# -eq 1 && -n "$1" ]] || { echo "Usage: $0 YOUR_JELLYFIN_API_KEY" >&2; exit 1; }

KEY="$1"
if grep -q '^JELLYFIN_API_KEY=' "$ENV_FILE"; then
  sed -i "s|^JELLYFIN_API_KEY=.*|JELLYFIN_API_KEY=${KEY}|" "$ENV_FILE"
else
  printf 'JELLYFIN_API_KEY=%s\n' "$KEY" >> "$ENV_FILE"
fi

cd "$BASE_DIR"
docker compose --env-file .env up -d --force-recreate control-api
printf 'Jellyfin API key saved. Refresh the GalaxyTV control panel.\n'
