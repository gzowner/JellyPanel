#!/usr/bin/env bash
set -Eeuo pipefail

BASE_DIR="/opt/galaxytv-jellyfin"
ENV_FILE="$BASE_DIR/.env"
COMPOSE=(docker compose --env-file "$ENV_FILE")

[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "GalaxyTV installation not found at $BASE_DIR" >&2; exit 1; }
cd "$BASE_DIR"

POSTGRES_USER="$(grep -E '^POSTGRES_USER=' "$ENV_FILE" | tail -n1 | cut -d= -f2- || true)"
POSTGRES_DB="$(grep -E '^POSTGRES_DB=' "$ENV_FILE" | tail -n1 | cut -d= -f2- || true)"
POSTGRES_USER="${POSTGRES_USER:-galaxytv}"
POSTGRES_DB="${POSTGRES_DB:-galaxytv}"
M3U_PORT="$(grep -E '^M3U_GATEWAY_PORT=' "$ENV_FILE" | tail -n1 | cut -d= -f2- || true)"
M3U_PORT="${M3U_PORT:-8183}"

echo "=== Containers ==="
"${COMPOSE[@]}" ps control-api m3u-gateway jellyfin postgres

echo
echo "=== M3U gateway health ==="
curl -fsS "http://127.0.0.1:${M3U_PORT}/health" || true
echo

echo
echo "=== M3U and XMLTV sources ==="
"${COMPOSE[@]}" exec -T postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -x -c "
SELECT
  id,
  name,
  enabled,
  channel_count,
  category_count,
  jsonb_array_length(epg_urls) AS manual_epg_urls,
  jsonb_array_length(detected_epg_urls) AS detected_epg_urls,
  epg_enabled,
  last_epg_checked_at,
  last_epg_error,
  last_refreshed_at,
  last_error
FROM m3u_sources
ORDER BY name;"

echo
echo "=== Published channels without tvg-id ==="
"${COMPOSE[@]}" exec -T postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "
SELECT s.name AS source, COUNT(*) AS missing_tvg_id
FROM m3u_channels ch
JOIN m3u_sources s ON s.id = ch.source_id
JOIN m3u_categories c ON c.id = ch.category_id
WHERE s.enabled = TRUE
  AND c.enabled = TRUE
  AND ch.enabled = TRUE
  AND ch.active = TRUE
  AND BTRIM(COALESCE(NULLIF(ch.mapped_tvg_id, ''), ch.tvg_id)) = ''
GROUP BY s.name
ORDER BY s.name;"

echo
echo "=== Jellyfin tuner and XMLTV provider records ==="
"${COMPOSE[@]}" exec -T postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -x -c "
SELECT key, value, updated_at
FROM app_settings
WHERE key IN ('jellyfin_m3u_tuner', 'jellyfin_xmltv_providers')
ORDER BY key;"

echo
echo "Use the panel's Test EPG button to validate each configured XMLTV URL."
echo "After testing, click Sync M3U + EPG and then Refresh guide."
