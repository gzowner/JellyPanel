#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/galaxytv-jellyfin"
ENV_FILE="$BASE_DIR/.env"
[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "Installation not found." >&2; exit 1; }
USERNAME="${1:-admin}"
PASSWORD="${2:-}"
if [[ -z "$PASSWORD" ]]; then
  read -rsp "New panel password: " PASSWORD; echo
  read -rsp "Confirm password: " CONFIRM; echo
  [[ "$PASSWORD" == "$CONFIRM" ]] || { echo "Passwords do not match." >&2; exit 1; }
fi
[[ ${#PASSWORD} -ge 10 ]] || { echo "Use at least 10 characters." >&2; exit 1; }
HASH="$(python3 "$BASE_DIR/scripts/hash-password.py" "$PASSWORD")"
set_value(){ local k="$1" v="$2"; if grep -qE "^${k}=" "$ENV_FILE"; then sed -i "s|^${k}=.*|${k}=${v}|" "$ENV_FILE"; else echo "${k}=${v}" >> "$ENV_FILE"; fi; }
set_value PANEL_ADMIN_USERNAME "$USERNAME"
set_value PANEL_ADMIN_PASSWORD_HASH "$HASH"
set_value APP_SECRET "$(openssl rand -hex 32)"
rm -f "$BASE_DIR/panel-admin-credentials.txt"
cd "$BASE_DIR"
docker compose --env-file .env up -d --force-recreate control-api control-worker control-web
echo "Panel credentials updated. Existing panel sessions were revoked."
