#!/usr/bin/env bash
set -Eeuo pipefail

BASE_DIR="${GALAXYTV_BASE_DIR:-/opt/galaxytv-jellyfin}"
ENV_FILE="$BASE_DIR/.env"

[[ -d "$BASE_DIR" ]] || { echo "GalaxyTV directory not found: $BASE_DIR" >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "GalaxyTV environment file not found: $ENV_FILE" >&2; exit 1; }

get_env_value() {
  local key="$1"
  grep -E "^${key}=" "$ENV_FILE" | tail -n1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true
}

args=(-f "$BASE_DIR/compose.yml" --env-file "$ENV_FILE")
if [[ "$(get_env_value ENABLE_INTEL_GPU)" == "true" && -e /dev/dri ]]; then
  args+=(-f "$BASE_DIR/compose.intel-gpu.yml")
fi

cd "$BASE_DIR"
exec docker compose "${args[@]}" "$@"
