# GalaxyTV v1.1.1 Existing-User Import Test Plan

Use non-administrator test accounts first.

## Upgrade

```bash
cd /root
sha256sum -c galaxytv-jellyfin-v1.1.1.zip.sha256
unzip -o galaxytv-jellyfin-v1.1.1.zip
cd galaxytv-jellyfin-v1.1.1
sudo bash install.sh --mode upgrade
```

Then run:

```bash
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
sudo /opt/galaxytv-jellyfin/scripts/manage.sh imports
```

Expected database schema: `15`.

## Test A: Adopt a local user

1. Create a normal user directly in the local Jellyfin dashboard.
2. Do not create the user in GalaxyTV.
3. Open **Servers → Local Jellyfin → Import users**.
4. Confirm the account is classified as **new**.
5. Select it and keep **Preserve source permissions**.
6. Import it.
7. Confirm the existing Jellyfin password still works.
8. Confirm the account now shows as managed in **Users**.
9. Confirm its default-server assignment exists.

## Test B: Link an existing remote user

1. Create the same non-administrator username on the primary and secondary Jellyfin servers.
2. Manage the primary user in GalaxyTV, or leave it unmanaged to test adoption.
3. Open the secondary server's import dialog.
4. Confirm the account is classified as **username match** or **username match unmanaged**.
5. Import it.
6. Confirm no duplicate primary user was created.
7. Confirm the secondary account appears in the user's **Servers** assignments.

## Test C: Create a missing primary account

1. Create a non-administrator account only on the secondary server.
2. Scan it from the secondary server.
3. Confirm it is classified as **new**.
4. Leave the temporary password blank.
5. Import it with **Create missing users on the primary server** enabled.
6. Copy the generated one-time password shown in the result.
7. Confirm a primary Jellyfin user was created.
8. Confirm the existing secondary password was not changed.
9. Confirm the generated password works only on the new primary account until GalaxyTV sets a synchronized password.

## Test D: Package mode

1. Select an enabled package.
2. Choose **Apply selected package**.
3. Import one test account.
4. Confirm Live TV, downloads, transcode permissions, session limit, and expiration match the package.
5. Confirm the policy appears on both the primary and source server when importing from a secondary server.

## Test E: Protection and conflicts

- Jellyfin administrators must show as protected and cannot be selected.
- Already-linked users must show as already managed.
- A same-name match to a primary administrator must show as a conflict.
- Disabling primary-user creation must reject remote-only users without deleting or changing the source account.

## Diagnostics

```bash
sudo /opt/galaxytv-jellyfin/scripts/manage.sh imports
sudo /opt/galaxytv-jellyfin/scripts/manage.sh servers
sudo docker compose --env-file /opt/galaxytv-jellyfin/.env \
  -f /opt/galaxytv-jellyfin/compose.yml logs --tail=300 control-api
```
