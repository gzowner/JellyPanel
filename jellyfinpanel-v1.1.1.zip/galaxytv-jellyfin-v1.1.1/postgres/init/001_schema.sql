CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO schema_version (version)
VALUES (1)
ON CONFLICT (version) DO NOTHING;

CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_type TEXT NOT NULL DEFAULT 'system',
    actor_id TEXT,
    action TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS audit_log_created_at_idx
    ON audit_log (created_at DESC);

CREATE TABLE IF NOT EXISTS managed_jellyfin_users (
    jellyfin_user_id UUID PRIMARY KEY,
    reseller_id UUID,
    package_id UUID,
    expires_at TIMESTAMPTZ,
    max_sessions INTEGER NOT NULL DEFAULT 0,
    max_devices INTEGER NOT NULL DEFAULT 0,
    managed BOOLEAN NOT NULL DEFAULT TRUE,
    last_policy_sync_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS m3u_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    source_url TEXT NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    refresh_minutes INTEGER NOT NULL DEFAULT 60,
    max_connections INTEGER NOT NULL DEFAULT 0,
    stream_mode TEXT NOT NULL DEFAULT 'redirect'
        CHECK (stream_mode IN ('redirect', 'proxy')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
