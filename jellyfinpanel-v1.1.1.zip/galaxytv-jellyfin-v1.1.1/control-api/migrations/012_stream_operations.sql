CREATE TABLE IF NOT EXISTS stream_operations_settings (
    id SMALLINT PRIMARY KEY CHECK (id = 1),
    monitoring_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    sample_interval_seconds INTEGER NOT NULL DEFAULT 60 CHECK (sample_interval_seconds >= 60 AND sample_interval_seconds <= 3600),
    history_days INTEGER NOT NULL DEFAULT 30 CHECK (history_days >= 1 AND history_days <= 365),
    alert_window_minutes INTEGER NOT NULL DEFAULT 30 CHECK (alert_window_minutes >= 5 AND alert_window_minutes <= 1440),
    distinct_ip_warning INTEGER NOT NULL DEFAULT 3 CHECK (distinct_ip_warning >= 2 AND distinct_ip_warning <= 50),
    reconnect_warning INTEGER NOT NULL DEFAULT 8 CHECK (reconnect_warning >= 2 AND reconnect_warning <= 100),
    auto_stop_over_limit BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by TEXT
);

INSERT INTO stream_operations_settings (id)
VALUES (1)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS stream_session_samples (
    id BIGSERIAL PRIMARY KEY,
    observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    jellyfin_session_id TEXT NOT NULL,
    jellyfin_user_id UUID,
    user_name TEXT,
    reseller_id UUID REFERENCES panel_accounts(id) ON DELETE SET NULL,
    remote_endpoint TEXT,
    remote_ip TEXT,
    client TEXT,
    device_name TEXT,
    device_id TEXT,
    application_version TEXT,
    item_id TEXT,
    item_name TEXT,
    media_type TEXT,
    play_method TEXT,
    is_paused BOOLEAN NOT NULL DEFAULT FALSE,
    bitrate BIGINT,
    video_codec TEXT,
    audio_codec TEXT,
    width INTEGER,
    height INTEGER,
    position_ticks BIGINT,
    runtime_ticks BIGINT,
    supports_media_control BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_stream_samples_observed_at
    ON stream_session_samples (observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_stream_samples_user_time
    ON stream_session_samples (jellyfin_user_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_stream_samples_ip_time
    ON stream_session_samples (remote_ip, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_stream_samples_session_time
    ON stream_session_samples (jellyfin_session_id, observed_at DESC);

CREATE TABLE IF NOT EXISTS stream_operation_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    alert_type TEXT NOT NULL CHECK (alert_type IN ('over_limit', 'multiple_ips', 'reconnect_burst')),
    severity TEXT NOT NULL DEFAULT 'warning' CHECK (severity IN ('info', 'warning', 'critical')),
    dedupe_key TEXT NOT NULL,
    jellyfin_user_id UUID,
    user_name TEXT,
    reseller_id UUID REFERENCES panel_accounts(id) ON DELETE SET NULL,
    session_id TEXT,
    remote_endpoint TEXT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    first_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    occurrence_count INTEGER NOT NULL DEFAULT 1,
    resolved_at TIMESTAMPTZ,
    resolved_by TEXT,
    resolution_notes TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_stream_alert_open_dedupe
    ON stream_operation_alerts (dedupe_key)
    WHERE resolved_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_stream_alerts_open
    ON stream_operation_alerts (resolved_at, last_seen_at DESC);
CREATE INDEX IF NOT EXISTS idx_stream_alerts_reseller
    ON stream_operation_alerts (reseller_id, last_seen_at DESC);
