ALTER TABLE m3u_sources
    ADD COLUMN IF NOT EXISTS epg_urls JSONB NOT NULL DEFAULT '[]'::jsonb,
    ADD COLUMN IF NOT EXISTS detected_epg_urls JSONB NOT NULL DEFAULT '[]'::jsonb,
    ADD COLUMN IF NOT EXISTS epg_user_agent TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS epg_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS last_epg_checked_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS last_epg_error TEXT;

UPDATE m3u_sources
SET epg_urls = '[]'::jsonb
WHERE epg_urls IS NULL OR jsonb_typeof(epg_urls) <> 'array';

UPDATE m3u_sources
SET detected_epg_urls = '[]'::jsonb
WHERE detected_epg_urls IS NULL OR jsonb_typeof(detected_epg_urls) <> 'array';
