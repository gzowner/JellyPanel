CREATE TABLE IF NOT EXISTS jellyfin_servers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    internal_url TEXT NOT NULL,
    public_url TEXT NOT NULL,
    api_key_encrypted TEXT NOT NULL DEFAULT '',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    is_local BOOLEAN NOT NULL DEFAULT FALSE,
    verify_tls BOOLEAN NOT NULL DEFAULT TRUE,
    connect_timeout_seconds INTEGER NOT NULL DEFAULT 20
        CHECK (connect_timeout_seconds BETWEEN 3 AND 120),
    notes TEXT NOT NULL DEFAULT '',
    last_status TEXT NOT NULL DEFAULT 'unknown'
        CHECK (last_status IN ('unknown', 'online', 'offline', 'auth_error', 'disabled')),
    last_status_message TEXT NOT NULL DEFAULT '',
    last_server_name TEXT,
    last_version TEXT,
    last_checked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_jellyfin_servers_default
    ON jellyfin_servers ((is_default))
    WHERE is_default = TRUE;

CREATE UNIQUE INDEX IF NOT EXISTS uq_jellyfin_servers_name_ci
    ON jellyfin_servers (LOWER(name));

CREATE INDEX IF NOT EXISTS idx_jellyfin_servers_enabled
    ON jellyfin_servers (enabled, LOWER(name));

CREATE TABLE IF NOT EXISTS server_user_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    jellyfin_user_id UUID NOT NULL
        REFERENCES managed_jellyfin_users(jellyfin_user_id) ON DELETE CASCADE,
    server_id UUID NOT NULL
        REFERENCES jellyfin_servers(id) ON DELETE CASCADE,
    remote_user_id UUID,
    remote_user_name TEXT NOT NULL DEFAULT '',
    sync_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    last_sync_status TEXT NOT NULL DEFAULT 'pending'
        CHECK (last_sync_status IN ('pending', 'synced', 'warning', 'failed', 'disabled')),
    last_sync_message TEXT NOT NULL DEFAULT '',
    last_sync_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (jellyfin_user_id, server_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_server_remote_user
    ON server_user_assignments (server_id, remote_user_id)
    WHERE remote_user_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_server_user_assignments_user
    ON server_user_assignments (jellyfin_user_id, sync_enabled);
CREATE INDEX IF NOT EXISTS idx_server_user_assignments_server
    ON server_user_assignments (server_id, sync_enabled);

ALTER TABLE stream_session_samples
    ADD COLUMN IF NOT EXISTS server_id UUID
        REFERENCES jellyfin_servers(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS server_name TEXT;

ALTER TABLE stream_operation_alerts
    ADD COLUMN IF NOT EXISTS server_id UUID
        REFERENCES jellyfin_servers(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS server_name TEXT;

CREATE INDEX IF NOT EXISTS idx_stream_samples_server_time
    ON stream_session_samples (server_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_stream_alerts_server
    ON stream_operation_alerts (server_id, last_seen_at DESC);
