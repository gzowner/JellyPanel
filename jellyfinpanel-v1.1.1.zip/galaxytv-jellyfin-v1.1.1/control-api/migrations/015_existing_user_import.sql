CREATE TABLE IF NOT EXISTS jellyfin_user_import_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    server_id UUID NOT NULL
        REFERENCES jellyfin_servers(id) ON DELETE CASCADE,
    server_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'running'
        CHECK (status IN ('running', 'completed', 'completed_with_errors', 'failed')),
    requested_count INTEGER NOT NULL DEFAULT 0 CHECK (requested_count >= 0),
    imported_count INTEGER NOT NULL DEFAULT 0 CHECK (imported_count >= 0),
    linked_count INTEGER NOT NULL DEFAULT 0 CHECK (linked_count >= 0),
    created_primary_count INTEGER NOT NULL DEFAULT 0 CHECK (created_primary_count >= 0),
    skipped_count INTEGER NOT NULL DEFAULT 0 CHECK (skipped_count >= 0),
    failed_count INTEGER NOT NULL DEFAULT 0 CHECK (failed_count >= 0),
    options JSONB NOT NULL DEFAULT '{}'::jsonb,
    results JSONB NOT NULL DEFAULT '[]'::jsonb,
    error TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_jellyfin_user_import_runs_created
    ON jellyfin_user_import_runs (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jellyfin_user_import_runs_server
    ON jellyfin_user_import_runs (server_id, created_at DESC);
