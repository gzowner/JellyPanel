ALTER TABLE m3u_channels
    ADD COLUMN IF NOT EXISTS mapped_tvg_id TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS suggested_tvg_id TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS suggested_epg_name TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS suggested_feed_index INTEGER,
    ADD COLUMN IF NOT EXISTS mapping_status TEXT NOT NULL DEFAULT 'unscanned',
    ADD COLUMN IF NOT EXISTS mapping_method TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS mapping_confidence INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS mapping_ambiguous BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS mapping_updated_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS epg_catalog_channels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id UUID NOT NULL REFERENCES m3u_sources(id) ON DELETE CASCADE,
    feed_index INTEGER NOT NULL,
    xmltv_id TEXT NOT NULL,
    display_name TEXT NOT NULL,
    normalized_name TEXT NOT NULL,
    channel_number TEXT NOT NULL DEFAULT '',
    icon_url TEXT NOT NULL DEFAULT '',
    duplicate_count INTEGER NOT NULL DEFAULT 1,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (source_id, feed_index, xmltv_id)
);

CREATE INDEX IF NOT EXISTS epg_catalog_source_idx
    ON epg_catalog_channels (source_id, active, feed_index, normalized_name);
CREATE INDEX IF NOT EXISTS epg_catalog_xmltv_idx
    ON epg_catalog_channels (source_id, active, xmltv_id);

CREATE TABLE IF NOT EXISTS epg_mapping_overrides (
    channel_id UUID PRIMARY KEY REFERENCES m3u_channels(id) ON DELETE CASCADE,
    source_id UUID NOT NULL REFERENCES m3u_sources(id) ON DELETE CASCADE,
    xmltv_id TEXT NOT NULL,
    feed_index INTEGER NOT NULL,
    epg_name TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL DEFAULT 'admin',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS epg_mapper_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id UUID REFERENCES m3u_sources(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'queued',
    cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
    feeds_scanned INTEGER NOT NULL DEFAULT 0,
    epg_channels INTEGER NOT NULL DEFAULT 0,
    m3u_channels INTEGER NOT NULL DEFAULT 0,
    exact_matches INTEGER NOT NULL DEFAULT 0,
    suggested_matches INTEGER NOT NULL DEFAULT 0,
    ambiguous_matches INTEGER NOT NULL DEFAULT 0,
    unmatched_channels INTEGER NOT NULL DEFAULT 0,
    duplicate_epg_ids INTEGER NOT NULL DEFAULT 0,
    current_item TEXT NOT NULL DEFAULT '',
    error TEXT,
    created_by TEXT NOT NULL DEFAULT 'admin',
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS epg_mapper_runs_created_idx
    ON epg_mapper_runs (created_at DESC);
