ALTER TABLE m3u_sources
    ADD COLUMN IF NOT EXISTS user_agent TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS last_refreshed_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS last_error TEXT,
    ADD COLUMN IF NOT EXISTS channel_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS category_count INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS m3u_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id UUID NOT NULL REFERENCES m3u_sources(id) ON DELETE CASCADE,
    original_name TEXT NOT NULL,
    display_name TEXT NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    sort_order INTEGER NOT NULL DEFAULT 0,
    channel_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (source_id, original_name)
);

CREATE INDEX IF NOT EXISTS m3u_categories_source_idx
    ON m3u_categories (source_id, sort_order, display_name);

CREATE TABLE IF NOT EXISTS m3u_channels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id UUID NOT NULL REFERENCES m3u_sources(id) ON DELETE CASCADE,
    category_id UUID NOT NULL REFERENCES m3u_categories(id) ON DELETE CASCADE,
    stable_key TEXT NOT NULL,
    name TEXT NOT NULL,
    stream_url TEXT NOT NULL,
    tvg_id TEXT NOT NULL DEFAULT '',
    tvg_name TEXT NOT NULL DEFAULT '',
    tvg_logo TEXT NOT NULL DEFAULT '',
    channel_number TEXT NOT NULL DEFAULT '',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (source_id, stable_key)
);

CREATE INDEX IF NOT EXISTS m3u_channels_publish_idx
    ON m3u_channels (active, enabled, category_id);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
