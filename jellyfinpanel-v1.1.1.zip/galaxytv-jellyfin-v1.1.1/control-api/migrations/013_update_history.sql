CREATE TABLE IF NOT EXISTS update_history (
    id BIGSERIAL PRIMARY KEY,
    version TEXT NOT NULL UNIQUE,
    channel TEXT NOT NULL DEFAULT 'stable',
    status TEXT NOT NULL DEFAULT 'installed',
    install_type TEXT NOT NULL DEFAULT 'application_start',
    notes TEXT NOT NULL DEFAULT '',
    installed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS update_history_installed_at_idx
    ON update_history (installed_at DESC);
