CREATE TABLE IF NOT EXISTS operations_settings (
    id SMALLINT PRIMARY KEY CHECK (id = 1),
    nightly_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    nightly_time TIME NOT NULL DEFAULT '03:30',
    retention_daily INTEGER NOT NULL DEFAULT 7 CHECK (retention_daily >= 1 AND retention_daily <= 90),
    retention_weekly INTEGER NOT NULL DEFAULT 4 CHECK (retention_weekly >= 0 AND retention_weekly <= 52),
    include_mirror BOOLEAN NOT NULL DEFAULT FALSE,
    low_disk_gb INTEGER NOT NULL DEFAULT 20 CHECK (low_disk_gb >= 1 AND low_disk_gb <= 10000),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by TEXT
);

INSERT INTO operations_settings (id)
VALUES (1)
ON CONFLICT (id) DO NOTHING;
