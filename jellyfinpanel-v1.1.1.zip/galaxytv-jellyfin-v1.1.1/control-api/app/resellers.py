from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator

from .access import (
    MASTER_ROLE,
    RESELLER_ROLE,
    assert_account_in_scope,
    assert_package_allowed,
    descendant_account_ids,
    is_admin,
    require_admin_role,
    scoped_reseller_ids,
)
from .jellyfin import request_json
from .security import (
    PanelSession,
    ensure_writes_enabled,
    hash_password,
    require_session,
    validate_csrf,
)

router = APIRouter(prefix="/resellers", tags=["Resellers"])


class ResellerCreate(BaseModel):
    username: str = Field(min_length=1, max_length=128)
    display_name: str = Field(default="", max_length=160)
    password: str = Field(min_length=8, max_length=256)
    role: str = RESELLER_ROLE
    parent_id: uuid.UUID | None = None
    initial_credits: int = Field(default=0, ge=0, le=10_000_000)
    package_ids: list[uuid.UUID] = Field(default_factory=list)

    @field_validator("username")
    @classmethod
    def clean_username(cls, value: str) -> str:
        value = value.strip()
        if not value or any(ch.isspace() for ch in value):
            raise ValueError("Username cannot be blank or contain spaces")
        return value

    @field_validator("role")
    @classmethod
    def valid_role(cls, value: str) -> str:
        if value not in {MASTER_ROLE, RESELLER_ROLE}:
            raise ValueError("Role must be master_reseller or reseller")
        return value


class ResellerUpdate(BaseModel):
    display_name: str | None = Field(default=None, max_length=160)
    password: str | None = Field(default=None, min_length=8, max_length=256)
    enabled: bool | None = None
    package_ids: list[uuid.UUID] | None = None


class CreditAdjustment(BaseModel):
    amount: int = Field(ge=-10_000_000, le=10_000_000)
    notes: str = Field(default="", max_length=1000)

    @field_validator("amount")
    @classmethod
    def nonzero(cls, value: int) -> int:
        if value == 0:
            raise ValueError("Credit adjustment cannot be zero")
        return value


class SubscriptionCreate(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    password: str = Field(default="", max_length=256)
    package_id: uuid.UUID
    notes: str = Field(default="", max_length=2000)

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Username cannot be blank")
        return value


async def write_session(
    session: PanelSession = Depends(require_session),
    csrf_token: str | None = Header(default=None, alias="X-CSRF-Token"),
) -> PanelSession:
    ensure_writes_enabled()
    validate_csrf(session, csrf_token)
    return session


async def audit_tx(
    connection: Any,
    *,
    actor: str,
    action: str,
    target_type: str,
    target_id: str,
    details: dict[str, Any],
) -> None:
    await connection.execute(
        """
        INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
        VALUES ('panel', $1, $2, $3, $4, $5::jsonb)
        """,
        actor,
        action,
        target_type,
        target_id,
        json.dumps(details),
    )


def account_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    for key in ("id", "parent_id"):
        if item.get(key):
            item[key] = str(item[key])
    item["credit_balance"] = int(item.get("credit_balance") or 0)
    item["user_count"] = int(item.get("user_count") or 0)
    item["package_ids"] = [str(value) for value in (item.get("package_ids") or [])]
    item.pop("password_hash", None)
    return item


async def verify_parent(connection: Any, session: PanelSession, role: str, parent_id: uuid.UUID | None) -> uuid.UUID | None:
    if is_admin(session):
        if parent_id is None:
            return None
        parent = await connection.fetchrow("SELECT id, role, enabled FROM panel_accounts WHERE id=$1", parent_id)
        if parent is None or not parent["enabled"]:
            raise HTTPException(status_code=400, detail="Parent reseller does not exist or is disabled.")
        if role == MASTER_ROLE:
            raise HTTPException(status_code=400, detail="Master resellers cannot have a parent.")
        if parent["role"] != MASTER_ROLE:
            raise HTTPException(status_code=400, detail="A reseller parent must be a master reseller.")
        return parent_id

    if session.role != MASTER_ROLE or not session.account_id:
        raise HTTPException(status_code=403, detail="Only administrators and master resellers can create reseller accounts.")
    if role != RESELLER_ROLE:
        raise HTTPException(status_code=403, detail="Master resellers may create reseller accounts only.")
    return uuid.UUID(session.account_id)


async def ensure_package_assignment_allowed(
    connection: Any,
    session: PanelSession,
    package_ids: list[uuid.UUID],
) -> None:
    if not package_ids:
        return
    existing_rows = await connection.fetch(
        "SELECT id FROM account_packages WHERE id = ANY($1::uuid[])",
        package_ids,
    )
    existing = {row["id"] for row in existing_rows}
    if existing != set(package_ids):
        raise HTTPException(status_code=400, detail="One or more selected packages do not exist.")
    if is_admin(session):
        return
    allowed_rows = await connection.fetch(
        "SELECT package_id FROM reseller_package_access WHERE reseller_id=$1",
        uuid.UUID(session.account_id),
    )
    allowed = {row["package_id"] for row in allowed_rows}
    if any(package_id not in allowed for package_id in package_ids):
        raise HTTPException(status_code=403, detail="You may assign only packages available to your own account.")


@router.get("")
async def list_resellers(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    if session.role == RESELLER_ROLE:
        raise HTTPException(status_code=403, detail="Reseller management is not available to this role.")
    async with request.app.state.db.acquire() as connection:
        scope = await scoped_reseller_ids(connection, session)
        params: list[Any] = []
        where = ""
        if scope is not None:
            # A master reseller sees itself and descendants, but not unrelated accounts.
            params.append(scope)
            where = "WHERE a.id = ANY($1::uuid[])"
        rows = await connection.fetch(
            f"""
            SELECT a.id, a.username, a.display_name, a.role, a.parent_id, a.enabled,
                   a.credit_balance, a.created_at, a.updated_at,
                   parent.username AS parent_username,
                   (SELECT COUNT(*) FROM managed_jellyfin_users m WHERE m.reseller_id=a.id) AS user_count,
                   COALESCE((SELECT array_agg(rpa.package_id ORDER BY rpa.package_id)
                             FROM reseller_package_access rpa WHERE rpa.reseller_id=a.id), ARRAY[]::uuid[]) AS package_ids
            FROM panel_accounts a
            LEFT JOIN panel_accounts parent ON parent.id=a.parent_id
            {where}
            ORDER BY CASE a.role WHEN 'master_reseller' THEN 0 ELSE 1 END, LOWER(a.username)
            """,
            *params,
        )
    return {"count": len(rows), "resellers": [account_dict(row) for row in rows]}


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_reseller(
    payload: ResellerCreate,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    async with request.app.state.db.acquire() as connection:
        parent_id = await verify_parent(connection, session, payload.role, payload.parent_id)
        await ensure_package_assignment_allowed(connection, session, payload.package_ids)
        try:
            async with connection.transaction():
                master_balance_after = None
                if not is_admin(session) and payload.initial_credits:
                    master_id = uuid.UUID(session.account_id)
                    master = await connection.fetchrow(
                        "SELECT credit_balance FROM panel_accounts WHERE id=$1 FOR UPDATE",
                        master_id,
                    )
                    if master is None or int(master["credit_balance"]) < payload.initial_credits:
                        raise HTTPException(status_code=409, detail="Insufficient master-reseller credits.")
                    master_balance_after = int(master["credit_balance"]) - payload.initial_credits
                    await connection.execute(
                        "UPDATE panel_accounts SET credit_balance=$2, updated_at=NOW() WHERE id=$1",
                        master_id,
                        master_balance_after,
                    )

                row = await connection.fetchrow(
                    """
                    INSERT INTO panel_accounts
                        (username, display_name, password_hash, role, parent_id, enabled, credit_balance)
                    VALUES ($1,$2,$3,$4,$5,TRUE,$6)
                    RETURNING id, username, display_name, role, parent_id, enabled,
                              credit_balance, created_at, updated_at
                    """,
                    payload.username,
                    payload.display_name.strip(),
                    hash_password(payload.password),
                    payload.role,
                    parent_id,
                    payload.initial_credits,
                )
                if payload.package_ids:
                    await connection.executemany(
                        "INSERT INTO reseller_package_access (reseller_id, package_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
                        [(row["id"], package_id) for package_id in payload.package_ids],
                    )
                if payload.initial_credits:
                    child_type = "issue" if is_admin(session) else "transfer_in"
                    await connection.execute(
                        """
                        INSERT INTO credit_ledger
                            (reseller_id, amount, balance_after, transaction_type,
                             reference_type, reference_id, notes, created_by)
                        VALUES ($1,$2,$2,$3,'reseller',$4,$5,$6)
                        """,
                        row["id"],
                        payload.initial_credits,
                        child_type,
                        session.account_id,
                        "Initial reseller credits",
                        session.username,
                    )
                    if not is_admin(session):
                        await connection.execute(
                            """
                            INSERT INTO credit_ledger
                                (reseller_id, amount, balance_after, transaction_type,
                                 reference_type, reference_id, notes, created_by)
                            VALUES ($1,$2,$3,'transfer_out','reseller',$4,$5,$6)
                            """,
                            uuid.UUID(session.account_id),
                            -payload.initial_credits,
                            master_balance_after,
                            str(row["id"]),
                            f"Initial credit transfer to {payload.username}",
                            session.username,
                        )
                await audit_tx(
                    connection,
                    actor=session.username,
                    action="reseller.create",
                    target_type="reseller",
                    target_id=str(row["id"]),
                    details={
                        "username": payload.username,
                        "role": payload.role,
                        "initial_credits": payload.initial_credits,
                        "package_ids": [str(value) for value in payload.package_ids],
                    },
                )
        except Exception as exc:
            if "unique" in str(exc).lower():
                raise HTTPException(status_code=409, detail="That reseller username already exists.") from exc
            raise
    result = dict(row)
    result["user_count"] = 0
    result["package_ids"] = payload.package_ids
    return account_dict(result)


@router.put("/{reseller_id}")
async def update_reseller(
    reseller_id: uuid.UUID,
    payload: ResellerUpdate,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    if session.role == RESELLER_ROLE:
        raise HTTPException(status_code=403, detail="Reseller management is not available to this role.")
    async with request.app.state.db.acquire() as connection:
        await assert_account_in_scope(connection, session, reseller_id)
        if payload.package_ids is not None:
            await ensure_package_assignment_allowed(connection, session, payload.package_ids)
        async with connection.transaction():
            current = await connection.fetchrow("SELECT * FROM panel_accounts WHERE id=$1 FOR UPDATE", reseller_id)
            if current is None:
                raise HTTPException(status_code=404, detail="Reseller not found.")
            if not is_admin(session) and reseller_id == uuid.UUID(session.account_id):
                raise HTTPException(status_code=403, detail="A master reseller cannot edit its own role account here.")
            display_name = payload.display_name if payload.display_name is not None else current["display_name"]
            enabled = payload.enabled if payload.enabled is not None else current["enabled"]
            password_hash = hash_password(payload.password) if payload.password else current["password_hash"]
            row = await connection.fetchrow(
                """
                UPDATE panel_accounts
                SET display_name=$2, enabled=$3, password_hash=$4, updated_at=NOW()
                WHERE id=$1
                RETURNING id, username, display_name, role, parent_id, enabled,
                          credit_balance, created_at, updated_at
                """,
                reseller_id,
                display_name.strip(),
                enabled,
                password_hash,
            )
            if payload.package_ids is not None:
                await connection.execute("DELETE FROM reseller_package_access WHERE reseller_id=$1", reseller_id)
                if payload.package_ids:
                    await connection.executemany(
                        "INSERT INTO reseller_package_access (reseller_id, package_id) VALUES ($1,$2)",
                        [(reseller_id, package_id) for package_id in payload.package_ids],
                    )
            await audit_tx(
                connection,
                actor=session.username,
                action="reseller.update",
                target_type="reseller",
                target_id=str(reseller_id),
                details=payload.model_dump(exclude_unset=True, mode="json"),
            )
        packages = await connection.fetch(
            "SELECT package_id FROM reseller_package_access WHERE reseller_id=$1 ORDER BY package_id",
            reseller_id,
        )
        user_count = await connection.fetchval(
            "SELECT COUNT(*) FROM managed_jellyfin_users WHERE reseller_id=$1",
            reseller_id,
        )
    result = dict(row)
    result["package_ids"] = [item["package_id"] for item in packages]
    result["user_count"] = user_count
    return account_dict(result)


@router.post("/{reseller_id}/credits")
async def adjust_credits(
    reseller_id: uuid.UUID,
    payload: CreditAdjustment,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    if session.role == RESELLER_ROLE:
        raise HTTPException(status_code=403, detail="Only administrators and master resellers may adjust credits.")
    async with request.app.state.db.acquire() as connection:
        await assert_account_in_scope(connection, session, reseller_id)
        if not is_admin(session) and reseller_id == uuid.UUID(session.account_id):
            raise HTTPException(status_code=403, detail="Master resellers cannot adjust their own balance.")
        async with connection.transaction():
            account = await connection.fetchrow(
                "SELECT username, parent_id, credit_balance FROM panel_accounts WHERE id=$1 FOR UPDATE",
                reseller_id,
            )
            if account is None:
                raise HTTPException(status_code=404, detail="Reseller not found.")

            if is_admin(session):
                new_balance = int(account["credit_balance"]) + payload.amount
                if new_balance < 0:
                    raise HTTPException(status_code=409, detail="This adjustment would make the credit balance negative.")
                await connection.execute(
                    "UPDATE panel_accounts SET credit_balance=$2, updated_at=NOW() WHERE id=$1",
                    reseller_id,
                    new_balance,
                )
                transaction_type = "issue" if payload.amount > 0 else "remove"
                entry = await connection.fetchrow(
                    """
                    INSERT INTO credit_ledger
                        (reseller_id, amount, balance_after, transaction_type, notes, created_by)
                    VALUES ($1,$2,$3,$4,$5,$6)
                    RETURNING id, created_at
                    """,
                    reseller_id,
                    payload.amount,
                    new_balance,
                    transaction_type,
                    payload.notes,
                    session.username,
                )
            else:
                master_id = uuid.UUID(session.account_id)
                if account["parent_id"] != master_id:
                    raise HTTPException(status_code=403, detail="Credits may be transferred only to a direct child reseller.")
                master = await connection.fetchrow(
                    "SELECT credit_balance FROM panel_accounts WHERE id=$1 FOR UPDATE",
                    master_id,
                )
                if master is None:
                    raise HTTPException(status_code=404, detail="Master reseller account not found.")
                child_balance = int(account["credit_balance"])
                master_balance = int(master["credit_balance"])
                if payload.amount > 0:
                    if master_balance < payload.amount:
                        raise HTTPException(status_code=409, detail="Insufficient master-reseller credits.")
                    new_balance = child_balance + payload.amount
                    master_after = master_balance - payload.amount
                    child_type, master_type = "transfer_in", "transfer_out"
                else:
                    transfer_back = abs(payload.amount)
                    if child_balance < transfer_back:
                        raise HTTPException(status_code=409, detail="The child reseller does not have enough credits to transfer back.")
                    new_balance = child_balance - transfer_back
                    master_after = master_balance + transfer_back
                    child_type, master_type = "transfer_out", "transfer_in"

                await connection.execute(
                    "UPDATE panel_accounts SET credit_balance=$2, updated_at=NOW() WHERE id=$1",
                    reseller_id,
                    new_balance,
                )
                await connection.execute(
                    "UPDATE panel_accounts SET credit_balance=$2, updated_at=NOW() WHERE id=$1",
                    master_id,
                    master_after,
                )
                entry = await connection.fetchrow(
                    """
                    INSERT INTO credit_ledger
                        (reseller_id, amount, balance_after, transaction_type,
                         reference_type, reference_id, notes, created_by)
                    VALUES ($1,$2,$3,$4,'reseller',$5,$6,$7)
                    RETURNING id, created_at
                    """,
                    reseller_id,
                    payload.amount,
                    new_balance,
                    child_type,
                    str(master_id),
                    payload.notes,
                    session.username,
                )
                await connection.execute(
                    """
                    INSERT INTO credit_ledger
                        (reseller_id, amount, balance_after, transaction_type,
                         reference_type, reference_id, notes, created_by)
                    VALUES ($1,$2,$3,$4,'reseller',$5,$6,$7)
                    """,
                    master_id,
                    -payload.amount,
                    master_after,
                    master_type,
                    str(reseller_id),
                    payload.notes or f"Credit transfer with {account['username']}",
                    session.username,
                )

            await audit_tx(
                connection,
                actor=session.username,
                action="credits.adjust",
                target_type="reseller",
                target_id=str(reseller_id),
                details={"amount": payload.amount, "balance_after": new_balance, "notes": payload.notes},
            )
    return {
        "reseller_id": str(reseller_id),
        "amount": payload.amount,
        "balance": new_balance,
        "ledger_id": str(entry["id"]),
        "created_at": entry["created_at"],
    }


@router.get("/ledger/all")
async def credit_ledger(
    request: Request,
    limit: int = 200,
    session: PanelSession = Depends(require_session),
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    limit = max(1, min(limit, 500))
    async with request.app.state.db.acquire() as connection:
        scope = await scoped_reseller_ids(connection, session)
        params: list[Any] = [limit]
        where = ""
        if scope is not None:
            params.append(scope)
            where = "WHERE l.reseller_id = ANY($2::uuid[])"
        rows = await connection.fetch(
            f"""
            SELECT l.id::text, l.reseller_id::text, a.username, l.amount,
                   l.balance_after, l.transaction_type, l.reference_type,
                   l.reference_id, l.notes, l.created_by, l.created_at
            FROM credit_ledger l
            JOIN panel_accounts a ON a.id=l.reseller_id
            {where}
            ORDER BY l.created_at DESC
            LIMIT $1
            """,
            *params,
        )
    return {"count": len(rows), "entries": [dict(row) for row in rows]}


@router.get("/me/status")
async def reseller_status(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> dict[str, Any]:
    if is_admin(session):
        return {"role": "admin", "credit_balance": None, "account_id": None}
    if request.app.state.db is None or not session.account_id:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    async with request.app.state.db.acquire() as connection:
        row = await connection.fetchrow(
            "SELECT id::text, username, display_name, role, credit_balance, parent_id::text FROM panel_accounts WHERE id=$1",
            uuid.UUID(session.account_id),
        )
    if row is None:
        raise HTTPException(status_code=404, detail="Reseller account not found.")
    return dict(row)


@router.post("/actions/subscriptions", status_code=status.HTTP_201_CREATED)
async def create_subscription(
    payload: SubscriptionCreate,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    if is_admin(session):
        raise HTTPException(status_code=400, detail="Administrators should create users from the Users page, then assign a package.")
    if request.app.state.db is None or not session.account_id:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    owner_id = uuid.UUID(session.account_id)

    async with request.app.state.db.acquire() as connection:
        await assert_package_allowed(connection, session, payload.package_id)
        package = await connection.fetchrow(
            "SELECT * FROM account_packages WHERE id=$1 AND enabled=TRUE",
            payload.package_id,
        )
        if package is None:
            raise HTTPException(status_code=404, detail="Package not found or disabled.")
        account = await connection.fetchrow(
            "SELECT credit_balance, enabled FROM panel_accounts WHERE id=$1",
            owner_id,
        )
        if account is None or not account["enabled"]:
            raise HTTPException(status_code=403, detail="Reseller account is disabled.")
        cost = int(package["credit_cost"])
        if int(account["credit_balance"]) < cost:
            raise HTTPException(status_code=409, detail="Insufficient reseller credits.")

    created = await request_json(
        request.app.state.http,
        "POST",
        "Users/New",
        require_key=True,
        json_data={"Name": payload.name, "Password": payload.password or None},
        expected_statuses=(200,),
    )
    user_id = created.get("Id")
    if not user_id:
        raise HTTPException(status_code=502, detail="Jellyfin did not return the new user ID.")

    policy = dict(created.get("Policy") or {})
    policy.update(
        {
            "IsAdministrator": False,
            "IsHidden": package["hidden"],
            "IsDisabled": False,
            "EnableMediaPlayback": True,
            "EnableLiveTvAccess": package["live_tv"],
            "EnableLiveTvManagement": False,
            "EnableContentDownloading": package["downloads"],
            "EnableRemoteAccess": package["remote_access"],
            "EnableVideoPlaybackTranscoding": package["video_transcoding"],
            "EnableAudioPlaybackTranscoding": package["audio_transcoding"],
            "EnablePlaybackRemuxing": package["remuxing"],
            "MaxActiveSessions": package["max_sessions"],
            "EnableContentDeletion": False,
            "EnableCollectionManagement": False,
            "EnableSubtitleManagement": False,
            "EnablePublicSharing": False,
        }
    )
    try:
        await request_json(
            request.app.state.http,
            "POST",
            f"Users/{user_id}/Policy",
            require_key=True,
            json_data=policy,
            expected_statuses=(204,),
        )
        now = datetime.now(timezone.utc)
        expires_at = None if int(package["duration_days"]) == 0 else now + timedelta(days=int(package["duration_days"]))
        async with request.app.state.db.acquire() as connection:
            async with connection.transaction():
                locked = await connection.fetchrow(
                    "SELECT credit_balance FROM panel_accounts WHERE id=$1 FOR UPDATE",
                    owner_id,
                )
                if locked is None or int(locked["credit_balance"]) < cost:
                    raise HTTPException(status_code=409, detail="Insufficient reseller credits.")
                new_balance = int(locked["credit_balance"]) - cost
                await connection.execute(
                    "UPDATE panel_accounts SET credit_balance=$2, updated_at=NOW() WHERE id=$1",
                    owner_id,
                    new_balance,
                )
                await connection.execute(
                    """
                    INSERT INTO managed_jellyfin_users
                        (jellyfin_user_id, reseller_id, package_id, expires_at, max_sessions,
                         managed, notes, created_by, disabled_by_expiration, last_policy_sync_at)
                    VALUES ($1,$2,$3,$4,$5,TRUE,$6,$7,FALSE,NOW())
                    """,
                    uuid.UUID(user_id),
                    owner_id,
                    package["id"],
                    expires_at,
                    package["max_sessions"],
                    payload.notes,
                    session.username,
                )
                if cost:
                    await connection.execute(
                        """
                        INSERT INTO credit_ledger
                            (reseller_id, amount, balance_after, transaction_type,
                             reference_type, reference_id, notes, created_by)
                        VALUES ($1,$2,$3,'subscription','jellyfin_user',$4,$5,$6)
                        """,
                        owner_id,
                        -cost,
                        new_balance,
                        user_id,
                        f"New subscription: {payload.name} / {package['name']}",
                        session.username,
                    )
                await audit_tx(
                    connection,
                    actor=session.username,
                    action="reseller.subscription.create",
                    target_type="jellyfin_user",
                    target_id=user_id,
                    details={
                        "name": payload.name,
                        "package": package["name"],
                        "credit_cost": cost,
                        "balance_after": new_balance,
                        "expires_at": expires_at.isoformat() if expires_at else None,
                    },
                )
    except Exception:
        try:
            await request_json(
                request.app.state.http,
                "DELETE",
                f"Users/{user_id}",
                require_key=True,
                expected_statuses=(204,),
            )
        except Exception:
            pass
        raise

    return {
        "created": True,
        "user_id": user_id,
        "name": payload.name,
        "package_id": str(package["id"]),
        "package_name": package["name"],
        "expires_at": expires_at,
        "credit_cost": cost,
        "credit_balance": new_balance,
    }
