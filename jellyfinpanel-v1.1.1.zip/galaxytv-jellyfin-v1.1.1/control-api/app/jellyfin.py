from __future__ import annotations

from typing import Any

import httpx
from fastapi import HTTPException

from .settings import settings


def jellyfin_headers() -> dict[str, str]:
    if not settings.jellyfin_api_key:
        return {}
    return {"X-Emby-Token": settings.jellyfin_api_key}


async def request_json(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    *,
    require_key: bool = False,
    json_data: Any | None = None,
    params: dict[str, Any] | None = None,
    expected_statuses: tuple[int, ...] = (200, 204),
) -> Any:
    if require_key and not settings.jellyfin_api_key:
        raise HTTPException(status_code=428, detail="JELLYFIN_API_KEY is not configured yet.")

    url = f"{settings.jellyfin_url.rstrip('/')}/{path.lstrip('/')}"
    try:
        response = await client.request(
            method,
            url,
            headers=jellyfin_headers(),
            json=json_data,
            params=params,
        )
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"Jellyfin is unreachable: {exc}") from exc

    if response.status_code in (401, 403):
        raise HTTPException(status_code=502, detail="Jellyfin rejected the configured API key.")
    if response.status_code not in expected_statuses:
        detail = response.text.strip()
        if len(detail) > 500:
            detail = detail[:500] + "…"
        raise HTTPException(
            status_code=502,
            detail=f"Jellyfin returned HTTP {response.status_code}: {detail or 'no response body'}",
        )
    if response.status_code == 204 or not response.content:
        return None
    try:
        return response.json()
    except ValueError as exc:
        raise HTTPException(status_code=502, detail="Jellyfin returned invalid JSON.") from exc
