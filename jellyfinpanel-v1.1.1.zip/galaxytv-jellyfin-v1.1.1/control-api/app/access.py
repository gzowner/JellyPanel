from __future__ import annotations

import uuid
from typing import Any

from fastapi import HTTPException, status

from .security import PanelSession


ADMIN_ROLE = "admin"
MASTER_ROLE = "master_reseller"
RESELLER_ROLE = "reseller"


def is_admin(session: PanelSession) -> bool:
    return session.role == ADMIN_ROLE


def require_admin_role(session: PanelSession) -> None:
    if not is_admin(session):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrator access is required.",
        )


async def descendant_account_ids(connection: Any, account_id: uuid.UUID) -> list[uuid.UUID]:
    rows = await connection.fetch(
        """
        WITH RECURSIVE tree AS (
            SELECT id FROM panel_accounts WHERE id=$1
            UNION ALL
            SELECT p.id
            FROM panel_accounts p
            JOIN tree t ON p.parent_id=t.id
        )
        SELECT id FROM tree
        """,
        account_id,
    )
    return [row["id"] for row in rows]


async def scoped_reseller_ids(connection: Any, session: PanelSession) -> list[uuid.UUID] | None:
    if is_admin(session):
        return None
    if not session.account_id:
        return []
    account_id = uuid.UUID(session.account_id)
    if session.role == MASTER_ROLE:
        return await descendant_account_ids(connection, account_id)
    return [account_id]


async def assert_account_in_scope(connection: Any, session: PanelSession, target_id: uuid.UUID) -> None:
    scope = await scoped_reseller_ids(connection, session)
    if scope is None:
        return
    if target_id not in scope:
        raise HTTPException(status_code=403, detail="That reseller is outside your account scope.")


async def assert_user_in_scope(connection: Any, session: PanelSession, user_id: uuid.UUID) -> None:
    if is_admin(session):
        return
    scope = await scoped_reseller_ids(connection, session)
    row = await connection.fetchrow(
        "SELECT reseller_id FROM managed_jellyfin_users WHERE jellyfin_user_id=$1",
        user_id,
    )
    if row is None or row["reseller_id"] is None or row["reseller_id"] not in (scope or []):
        raise HTTPException(status_code=403, detail="That Jellyfin user is outside your reseller account.")


async def allowed_package_ids(connection: Any, session: PanelSession) -> list[uuid.UUID] | None:
    if is_admin(session):
        return None
    if not session.account_id:
        return []
    rows = await connection.fetch(
        "SELECT package_id FROM reseller_package_access WHERE reseller_id=$1",
        uuid.UUID(session.account_id),
    )
    return [row["package_id"] for row in rows]


async def assert_package_allowed(
    connection: Any,
    session: PanelSession,
    package_id: uuid.UUID,
) -> None:
    allowed = await allowed_package_ids(connection, session)
    if allowed is None:
        return
    if package_id not in allowed:
        raise HTTPException(status_code=403, detail="That package is not assigned to your reseller account.")
