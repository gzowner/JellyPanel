from __future__ import annotations

import asyncio
import csv
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, AsyncIterator

import asyncpg
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from .access import require_admin_role
from .jellyfin import request_json
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf
from .settings import settings

router = APIRouter(prefix="/media", tags=["media"])

VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".m4v", ".avi", ".mov", ".wmv", ".ts", ".m2ts",
    ".mpg", ".mpeg", ".webm", ".iso", ".strm", ".vob", ".ogm", ".ogv",
}
AUDIO_EXTENSIONS = {
    ".mp3", ".flac", ".m4a", ".aac", ".ogg", ".opus", ".wav", ".wma",
    ".ape", ".alac", ".aiff", ".mka",
}


class StartScanRequest(BaseModel):
    mode: str = Field(default="auto", pattern="^(auto|rclone|filesystem)$")


class MediaScanSettingsRequest(BaseModel):
    host_path: str = Field(min_length=1, max_length=1000)
    mode: str = Field(default="auto", pattern="^(auto|rclone|filesystem)$")


class RefreshRequest(BaseModel):
    force: bool = False


class ScanCancelled(Exception):
    pass


@dataclass(frozen=True)
class ScanConfig:
    host_path: str
    container_path: str
    relative_path: str
    path_prefix: str
    rclone_target: str
    mode: str


async def write_session(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


async def read_session(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


def get_pool(request: Request) -> asyncpg.Pool:
    pool = request.app.state.db
    if pool is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    return pool



def normalize_host_path(value: str) -> tuple[str, str]:
    base = os.path.normpath(settings.media_host_path)
    candidate = os.path.normpath(value.strip())
    if not os.path.isabs(candidate):
        candidate = os.path.normpath(os.path.join(base, candidate))
    try:
        common = os.path.commonpath([base, candidate])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid media scan path.") from exc
    if common != base:
        raise HTTPException(
            status_code=400,
            detail=f"Scan path must remain inside the mounted media root: {base}",
        )
    relative = os.path.relpath(candidate, base)
    if relative == ".":
        relative = ""
    return candidate, relative.replace(os.sep, "/").strip("/")


def build_rclone_target(base_remote: str, relative: str) -> str:
    remote = base_remote.strip()
    if ":" not in remote:
        raise HTTPException(status_code=400, detail="RCLONE_REMOTE must use rclone remote syntax, such as union:.")
    name, existing = remote.split(":", 1)
    parts = [part.strip("/") for part in (existing, relative) if part.strip("/")]
    return f"{name}:{'/'.join(parts)}"


async def load_scan_config(pool: asyncpg.Pool) -> ScanConfig:
    async with pool.acquire() as connection:
        row = await connection.fetchrow(
            "SELECT host_path, mode FROM media_scan_settings WHERE id=1"
        )
    host_path = str(row["host_path"] if row else settings.media_scan_host_root)
    mode = str(row["mode"] if row else settings.media_scan_mode)
    normalized, relative = normalize_host_path(host_path)
    container = os.path.normpath(os.path.join(settings.media_scan_root, relative))
    return ScanConfig(
        host_path=normalized,
        container_path=container,
        relative_path=relative,
        path_prefix=relative,
        rclone_target=build_rclone_target(settings.rclone_remote, relative),
        mode=mode if mode in {"auto", "rclone", "filesystem"} else "auto",
    )


def prefixed_path(prefix: str, value: str) -> str:
    clean = value.strip().lstrip("/")
    if not prefix:
        return clean
    return f"{prefix.rstrip('/')}/{clean}" if clean else prefix.rstrip("/")


def process_maps(app: Any) -> tuple[dict[str, asyncio.subprocess.Process], dict[str, asyncio.Event]]:
    if not hasattr(app.state, "media_scan_processes"):
        app.state.media_scan_processes = {}
    if not hasattr(app.state, "media_scan_cancel_events"):
        app.state.media_scan_cancel_events = {}
    return app.state.media_scan_processes, app.state.media_scan_cancel_events


async def register_process(app: Any, job_id: uuid.UUID, process: asyncio.subprocess.Process) -> asyncio.Event:
    processes, events = process_maps(app)
    key = str(job_id)
    processes[key] = process
    return events.setdefault(key, asyncio.Event())


def unregister_process(app: Any, job_id: uuid.UUID, process: asyncio.subprocess.Process | None = None) -> None:
    processes, _ = process_maps(app)
    key = str(job_id)
    current = processes.get(key)
    if process is None or current is process:
        processes.pop(key, None)


async def terminate_process(process: asyncio.subprocess.Process) -> None:
    if process.returncode is not None:
        return
    try:
        process.terminate()
    except ProcessLookupError:
        return
    try:
        await asyncio.wait_for(process.wait(), timeout=5)
    except asyncio.TimeoutError:
        try:
            process.kill()
        except ProcessLookupError:
            return
        await process.wait()


def parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    value = value.strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except ValueError:
        return None


def classify(path: str) -> tuple[str, str]:
    extension = PurePosixPath(path).suffix.lower()
    if extension in VIDEO_EXTENSIONS:
        return extension, "video"
    if extension in AUDIO_EXTENSIONS:
        return extension, "audio"
    return extension, "other"


async def rclone_rows(
    app: Any,
    job_id: uuid.UUID,
    config_value: ScanConfig,
) -> AsyncIterator[tuple[str, str, int, datetime | None, str, str]]:
    config = settings.rclone_config
    if not config or not Path(config).is_file():
        raise RuntimeError(f"rclone config was not found at {config}")

    command = [
        "rclone", "lsf", config_value.rclone_target,
        "--recursive", "--files-only", "--fast-list", "--csv",
        "--format", "istp", "--time-format", "RFC3339",
        "--config", config,
        "--checkers", str(max(1, settings.media_scan_checkers)),
    ]
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        start_new_session=True,
    )
    cancel_event = await register_process(app, job_id, process)
    assert process.stdout is not None
    assert process.stderr is not None

    try:
        while True:
            if cancel_event.is_set():
                await terminate_process(process)
                raise ScanCancelled()
            raw = await process.stdout.readline()
            if not raw:
                break
            line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            if not line:
                continue
            try:
                row = next(csv.reader([line]))
            except (csv.Error, StopIteration):
                continue
            if len(row) < 4:
                continue
            remote_id, size_text, modified_text = row[0], row[1], row[2]
            relative = ",".join(row[3:]).strip().lstrip("/")
            path = prefixed_path(config_value.path_prefix, relative)
            if not path:
                continue
            extension, media_type = classify(path)
            try:
                size = int(size_text or 0)
            except ValueError:
                size = 0
            yield path, remote_id, size, parse_time(modified_text), extension, media_type
    finally:
        stderr = (await process.stderr.read()).decode("utf-8", errors="replace").strip()
        return_code = await process.wait()
        unregister_process(app, job_id, process)
        if cancel_event.is_set():
            raise ScanCancelled()
        if return_code != 0:
            raise RuntimeError(stderr[-2000:] or f"rclone exited with code {return_code}")


async def filesystem_rows(
    app: Any,
    job_id: uuid.UUID,
    config_value: ScanConfig,
) -> AsyncIterator[tuple[str, str, int, datetime | None, str, str]]:
    root = Path(config_value.container_path)
    if not root.is_dir():
        raise RuntimeError(f"media root was not found at {root}")

    process = await asyncio.create_subprocess_exec(
        "find", str(root), "-type", "f", "-printf", "%s\\t%T@\\t%P\\0",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        start_new_session=True,
    )
    cancel_event = await register_process(app, job_id, process)
    assert process.stdout is not None
    assert process.stderr is not None
    buffer = b""
    try:
        while True:
            if cancel_event.is_set():
                await terminate_process(process)
                raise ScanCancelled()
            chunk = await process.stdout.read(65536)
            if not chunk:
                break
            buffer += chunk
            while b"\0" in buffer:
                raw, buffer = buffer.split(b"\0", 1)
                if not raw:
                    continue
                parts = raw.decode("utf-8", errors="replace").split("\t", 2)
                if len(parts) != 3:
                    continue
                size_text, epoch_text, relative = parts
                path = prefixed_path(config_value.path_prefix, relative)
                if not path:
                    continue
                try:
                    size = int(size_text or 0)
                except ValueError:
                    size = 0
                try:
                    modified = datetime.fromtimestamp(float(epoch_text), tz=timezone.utc)
                except ValueError:
                    modified = None
                extension, media_type = classify(path)
                yield path, "", size, modified, extension, media_type
    finally:
        stderr = (await process.stderr.read()).decode("utf-8", errors="replace").strip()
        return_code = await process.wait()
        unregister_process(app, job_id, process)
        if cancel_event.is_set():
            raise ScanCancelled()
        if return_code != 0:
            raise RuntimeError(stderr[-2000:] or f"find exited with code {return_code}")


async def stage_batch(
    connection: asyncpg.Connection,
    job_id: uuid.UUID,
    batch: list[tuple[str, str, int, datetime | None, str, str]],
) -> None:
    await connection.executemany(
        """
        INSERT INTO media_scan_staging
            (job_id, path, remote_id, size_bytes, modified_at, extension, media_type)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (job_id, path) DO UPDATE SET
            remote_id = EXCLUDED.remote_id,
            size_bytes = EXCLUDED.size_bytes,
            modified_at = EXCLUDED.modified_at,
            extension = EXCLUDED.extension,
            media_type = EXCLUDED.media_type
        """,
        [(job_id, *row) for row in batch],
    )


async def finalize_inventory(pool: asyncpg.Pool, job_id: uuid.UUID, path_prefix: str) -> dict[str, int]:
    async with pool.acquire() as connection:
        async with connection.transaction():
            counts = await connection.fetchrow(
                """
                SELECT
                    COUNT(*) FILTER (WHERE i.path IS NULL) AS added,
                    COUNT(*) FILTER (
                        WHERE i.path IS NOT NULL AND (
                            i.size_bytes IS DISTINCT FROM s.size_bytes OR
                            i.modified_at IS DISTINCT FROM s.modified_at OR
                            (s.remote_id <> '' AND i.remote_id IS DISTINCT FROM s.remote_id) OR
                            i.active = FALSE
                        )
                    ) AS changed
                FROM media_scan_staging s
                LEFT JOIN media_inventory i ON i.path = s.path
                WHERE s.job_id = $1 AND s.media_type <> 'other'
                """,
                job_id,
            )
            missing = await connection.fetchval(
                """
                SELECT COUNT(*)
                FROM media_inventory i
                WHERE i.active = TRUE
                  AND ($2 = '' OR i.path = $2 OR i.path LIKE $2 || '/%')
                  AND NOT EXISTS (
                      SELECT 1 FROM media_scan_staging s
                      WHERE s.job_id = $1 AND s.path = i.path AND s.media_type <> 'other'
                  )
                """,
                job_id,
                path_prefix,
            )

            await connection.execute(
                """
                INSERT INTO media_inventory
                    (path, remote_id, size_bytes, modified_at, extension, media_type,
                     active, first_seen_at, last_seen_at, last_changed_at,
                     last_seen_job, last_change_job, last_change_type)
                SELECT s.path, NULLIF(s.remote_id, ''), s.size_bytes, s.modified_at,
                       s.extension, s.media_type, TRUE, NOW(), NOW(), NOW(),
                       $1, $1, 'added'
                FROM media_scan_staging s
                WHERE s.job_id = $1 AND s.media_type <> 'other'
                ON CONFLICT (path) DO UPDATE SET
                    remote_id = COALESCE(EXCLUDED.remote_id, media_inventory.remote_id),
                    size_bytes = EXCLUDED.size_bytes,
                    modified_at = EXCLUDED.modified_at,
                    extension = EXCLUDED.extension,
                    media_type = EXCLUDED.media_type,
                    active = TRUE,
                    last_seen_at = NOW(),
                    last_seen_job = $1,
                    last_changed_at = CASE
                        WHEN media_inventory.size_bytes IS DISTINCT FROM EXCLUDED.size_bytes
                          OR media_inventory.modified_at IS DISTINCT FROM EXCLUDED.modified_at
                          OR (EXCLUDED.remote_id IS NOT NULL AND media_inventory.remote_id IS DISTINCT FROM EXCLUDED.remote_id)
                          OR media_inventory.active = FALSE
                        THEN NOW() ELSE media_inventory.last_changed_at END,
                    last_change_job = CASE
                        WHEN media_inventory.size_bytes IS DISTINCT FROM EXCLUDED.size_bytes
                          OR media_inventory.modified_at IS DISTINCT FROM EXCLUDED.modified_at
                          OR (EXCLUDED.remote_id IS NOT NULL AND media_inventory.remote_id IS DISTINCT FROM EXCLUDED.remote_id)
                          OR media_inventory.active = FALSE
                        THEN $1 ELSE media_inventory.last_change_job END,
                    last_change_type = CASE
                        WHEN media_inventory.size_bytes IS DISTINCT FROM EXCLUDED.size_bytes
                          OR media_inventory.modified_at IS DISTINCT FROM EXCLUDED.modified_at
                          OR (EXCLUDED.remote_id IS NOT NULL AND media_inventory.remote_id IS DISTINCT FROM EXCLUDED.remote_id)
                          OR media_inventory.active = FALSE
                        THEN 'changed' ELSE media_inventory.last_change_type END
                """,
                job_id,
            )

            await connection.execute(
                """
                UPDATE media_inventory i
                SET active = FALSE,
                    last_changed_at = NOW(),
                    last_change_job = $1,
                    last_change_type = 'missing'
                WHERE i.active = TRUE
                  AND ($2 = '' OR i.path = $2 OR i.path LIKE $2 || '/%')
                  AND NOT EXISTS (
                      SELECT 1 FROM media_scan_staging s
                      WHERE s.job_id = $1 AND s.path = i.path AND s.media_type <> 'other'
                  )
                """,
                job_id,
                path_prefix,
            )

            media_files = await connection.fetchval(
                "SELECT COUNT(*) FROM media_scan_staging WHERE job_id = $1 AND media_type <> 'other'",
                job_id,
            )
            await connection.execute("DELETE FROM media_scan_staging WHERE job_id = $1", job_id)

    return {
        "media_files": int(media_files or 0),
        "added": int(counts["added"] or 0),
        "changed": int(counts["changed"] or 0),
        "missing": int(missing or 0),
    }


async def execute_scan(
    app: Any,
    job_id: uuid.UUID,
    requested_mode: str,
    scan_config: ScanConfig,
) -> None:
    pool: asyncpg.Pool = app.state.db
    redis_client = app.state.redis
    lock_key = "galaxytv:media-scan:lock"
    token = str(job_id)
    _, events = process_maps(app)
    cancel_event = events.setdefault(token, asyncio.Event())
    acquired = await redis_client.set(lock_key, token, nx=True, ex=21600)
    if not acquired:
        async with pool.acquire() as connection:
            await connection.execute(
                "UPDATE media_scan_jobs SET status='failed', finished_at=NOW(), error='Another scan is already running.' WHERE id=$1",
                job_id,
            )
        return

    actual_mode = requested_mode
    files_seen = 0
    batch: list[tuple[str, str, int, datetime | None, str, str]] = []
    try:
        async with pool.acquire() as connection:
            cancel_requested = await connection.fetchval(
                "SELECT cancel_requested FROM media_scan_jobs WHERE id=$1", job_id
            )
        if cancel_requested or cancel_event.is_set():
            raise ScanCancelled()

        if requested_mode == "auto":
            actual_mode = "rclone" if settings.rclone_config and Path(settings.rclone_config).is_file() else "filesystem"

        async with pool.acquire() as connection:
            await connection.execute(
                "UPDATE media_scan_jobs SET status='running', actual_mode=$2, source_path=$3, started_at=NOW() WHERE id=$1",
                job_id, actual_mode, scan_config.host_path,
            )

        iterator = rclone_rows(app, job_id, scan_config) if actual_mode == "rclone" else filesystem_rows(app, job_id, scan_config)
        try:
            async for row in iterator:
                if cancel_event.is_set():
                    raise ScanCancelled()
                files_seen += 1
                batch.append(row)
                if len(batch) >= 1000:
                    async with pool.acquire() as connection:
                        await stage_batch(connection, job_id, batch)
                        await connection.execute("UPDATE media_scan_jobs SET files_seen=$2 WHERE id=$1", job_id, files_seen)
                    batch.clear()
        except ScanCancelled:
            raise
        except Exception:
            if requested_mode == "auto" and actual_mode == "rclone" and not cancel_event.is_set():
                async with pool.acquire() as connection:
                    await connection.execute("DELETE FROM media_scan_staging WHERE job_id=$1", job_id)
                    await connection.execute("UPDATE media_scan_jobs SET actual_mode='filesystem', files_seen=0 WHERE id=$1", job_id)
                actual_mode = "filesystem"
                files_seen = 0
                batch.clear()
                async for row in filesystem_rows(app, job_id, scan_config):
                    if cancel_event.is_set():
                        raise ScanCancelled()
                    files_seen += 1
                    batch.append(row)
                    if len(batch) >= 1000:
                        async with pool.acquire() as connection:
                            await stage_batch(connection, job_id, batch)
                            await connection.execute("UPDATE media_scan_jobs SET files_seen=$2 WHERE id=$1", job_id, files_seen)
                        batch.clear()
            else:
                raise

        if cancel_event.is_set():
            raise ScanCancelled()
        if batch:
            async with pool.acquire() as connection:
                await stage_batch(connection, job_id, batch)
                await connection.execute("UPDATE media_scan_jobs SET files_seen=$2 WHERE id=$1", job_id, files_seen)
        if cancel_event.is_set():
            raise ScanCancelled()

        result = await finalize_inventory(pool, job_id, scan_config.path_prefix)
        async with pool.acquire() as connection:
            await connection.execute(
                """
                UPDATE media_scan_jobs
                SET status='completed', finished_at=NOW(), files_seen=$2, media_files=$3,
                    added_count=$4, changed_count=$5, missing_count=$6
                WHERE id=$1
                """,
                job_id, files_seen, result["media_files"], result["added"], result["changed"], result["missing"],
            )
            await connection.execute(
                """
                INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
                SELECT 'system', 'media-indexer', 'media.fast_scan.completed', 'media_scan', id::text,
                       jsonb_build_object('mode', actual_mode, 'source_path', source_path,
                           'files_seen', files_seen, 'media_files', media_files,
                           'added', added_count, 'changed', changed_count, 'missing', missing_count)
                FROM media_scan_jobs WHERE id=$1
                """, job_id,
            )
    except ScanCancelled:
        async with pool.acquire() as connection:
            await connection.execute("DELETE FROM media_scan_staging WHERE job_id=$1", job_id)
            await connection.execute(
                """UPDATE media_scan_jobs SET status='cancelled', finished_at=NOW(), files_seen=$2,
                       error=NULL, cancel_requested=TRUE WHERE id=$1""",
                job_id, files_seen,
            )
            await connection.execute(
                """INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
                   VALUES ('system', 'media-indexer', 'media.fast_scan.cancelled', 'media_scan', $1,
                           jsonb_build_object('files_seen', $2::bigint))""",
                str(job_id), files_seen,
            )
    except Exception as exc:
        async with pool.acquire() as connection:
            await connection.execute("DELETE FROM media_scan_staging WHERE job_id=$1", job_id)
            await connection.execute("UPDATE media_scan_jobs SET status='failed', finished_at=NOW(), error=$2 WHERE id=$1", job_id, str(exc)[:3000])
    finally:
        unregister_process(app, job_id)
        _, events = process_maps(app)
        events.pop(token, None)
        current = await redis_client.get(lock_key)
        if current == token:
            await redis_client.delete(lock_key)


@router.get("/settings")
async def get_media_settings(request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    config_value = await load_scan_config(get_pool(request))
    return {
        "host_path": config_value.host_path,
        "container_path": config_value.container_path,
        "rclone_target": config_value.rclone_target,
        "mode": config_value.mode,
        "allowed_root": settings.media_host_path,
    }


@router.put("/settings")
async def update_media_settings(
    request: Request,
    data: MediaScanSettingsRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    active = await request.app.state.redis.get("galaxytv:media-scan:lock")
    if active:
        raise HTTPException(status_code=409, detail="Stop the running scan before changing its location.")
    normalized, _ = normalize_host_path(data.host_path)
    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute(
                """
                INSERT INTO media_scan_settings (id, host_path, mode, updated_at, updated_by)
                VALUES (1, $1, $2, NOW(), $3)
                ON CONFLICT (id) DO UPDATE SET host_path=EXCLUDED.host_path, mode=EXCLUDED.mode,
                    updated_at=NOW(), updated_by=EXCLUDED.updated_by
                """, normalized, data.mode, session.username,
            )
            await connection.execute(
                """INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
                   VALUES ('panel', $1, 'media.scan_settings.updated', 'media_scan_settings', '1',
                           jsonb_build_object('host_path', $2::text, 'mode', $3::text))""",
                session.username, normalized, data.mode,
            )
    config_value = await load_scan_config(pool)
    return {"host_path": config_value.host_path, "container_path": config_value.container_path,
            "rclone_target": config_value.rclone_target, "mode": config_value.mode}


@router.get("/status")
async def media_status(request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    config_value = await load_scan_config(pool)
    async with pool.acquire() as connection:
        job = await connection.fetchrow(
            """
            SELECT id::text, status, requested_mode, actual_mode, source_path, started_at,
                   finished_at, files_seen, media_files, added_count, changed_count,
                   missing_count, jellyfin_refresh_queued, cancel_requested, error, created_at
            FROM media_scan_jobs ORDER BY created_at DESC LIMIT 1
            """
        )
        counts = await connection.fetchrow(
            """SELECT COUNT(*) FILTER (WHERE active) AS active,
                      COUNT(*) FILTER (WHERE active AND media_type='video') AS video,
                      COUNT(*) FILTER (WHERE active AND media_type='audio') AS audio,
                      COUNT(*) FILTER (WHERE NOT active) AS missing
               FROM media_inventory
               WHERE $1 = '' OR path = $1 OR path LIKE $1 || '/%'""",
            config_value.path_prefix,
        )
    return {
        "configured_mode": config_value.mode,
        "host_path": config_value.host_path,
        "container_path": config_value.container_path,
        "rclone_remote": config_value.rclone_target,
        "rclone_configured": bool(settings.rclone_config and Path(settings.rclone_config).is_file()),
        "inventory": dict(counts),
        "last_job": dict(job) if job else None,
    }


@router.post("/scan", status_code=202)
async def start_scan(request: Request, data: StartScanRequest, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    active = await request.app.state.redis.get("galaxytv:media-scan:lock")
    async with pool.acquire() as connection:
        active_job = await connection.fetchval("SELECT COUNT(*) FROM media_scan_jobs WHERE status IN ('queued','running')")
    if active or active_job:
        raise HTTPException(status_code=409, detail="A media scan is already running.")
    scan_config = await load_scan_config(pool)
    mode = data.mode if data.mode != "auto" else scan_config.mode
    if mode not in {"auto", "rclone", "filesystem"}:
        mode = "auto"
    job_id = uuid.uuid4()
    async with pool.acquire() as connection:
        await connection.execute(
            """INSERT INTO media_scan_jobs
                   (id, status, requested_mode, source_path, created_by, cancel_requested)
               VALUES ($1, 'queued', $2, $3, $4, FALSE)""",
            job_id, mode, scan_config.host_path, session.username,
        )
    _, events = process_maps(request.app)
    events[str(job_id)] = asyncio.Event()
    task = asyncio.create_task(execute_scan(request.app, job_id, mode, scan_config))
    request.app.state.background_tasks.add(task)
    task.add_done_callback(request.app.state.background_tasks.discard)
    return {"id": str(job_id), "status": "queued", "mode": mode, "source_path": scan_config.host_path}


@router.post("/jobs/{job_id}/cancel", status_code=202)
async def cancel_scan(request: Request, job_id: uuid.UUID, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        row = await connection.fetchrow("SELECT status FROM media_scan_jobs WHERE id=$1", job_id)
        if row is None:
            raise HTTPException(status_code=404, detail="Scan job not found.")
        if row["status"] not in {"queued", "running"}:
            return {"id": str(job_id), "status": row["status"], "message": "Scan is not running."}
        await connection.execute("UPDATE media_scan_jobs SET cancel_requested=TRUE WHERE id=$1", job_id)
        await connection.execute(
            """INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
               VALUES ('panel', $1, 'media.fast_scan.cancel_requested', 'media_scan', $2, '{}'::jsonb)""",
            session.username, str(job_id),
        )
    processes, events = process_maps(request.app)
    events.setdefault(str(job_id), asyncio.Event()).set()
    process = processes.get(str(job_id))
    if process is not None:
        await terminate_process(process)
    return {"id": str(job_id), "status": "cancelling"}


@router.get("/jobs/{job_id}")
async def get_job(
    request: Request,
    job_id: uuid.UUID,
    _: PanelSession = Depends(read_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        row = await connection.fetchrow(
            """
            SELECT id::text, status, requested_mode, actual_mode, source_path, started_at,
                   finished_at, files_seen, media_files, added_count, changed_count,
                   missing_count, jellyfin_refresh_queued, cancel_requested, error, created_at
            FROM media_scan_jobs WHERE id=$1
            """,
            job_id,
        )
    if row is None:
        raise HTTPException(status_code=404, detail="Scan job not found.")
    return dict(row)


@router.get("/changes")
async def recent_changes(
    request: Request,
    limit: int = 100,
    _: PanelSession = Depends(read_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    limit = max(1, min(limit, 500))
    async with pool.acquire() as connection:
        latest_job = await connection.fetchval(
            "SELECT id FROM media_scan_jobs WHERE status='completed' ORDER BY finished_at DESC LIMIT 1"
        )
        if latest_job is None:
            return {"count": 0, "changes": []}
        rows = await connection.fetch(
            """
            SELECT path, size_bytes, modified_at, media_type, active,
                   last_change_type, last_changed_at
            FROM media_inventory
            WHERE last_change_job=$1
            ORDER BY last_changed_at DESC, path
            LIMIT $2
            """,
            latest_job,
            limit,
        )
    return {"count": len(rows), "changes": [dict(row) for row in rows]}


@router.post("/jellyfin/refresh")
async def refresh_jellyfin(
    request: Request,
    data: RefreshRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        job = await connection.fetchrow(
            """
            SELECT id, added_count, changed_count, missing_count, jellyfin_refresh_queued
            FROM media_scan_jobs WHERE status='completed' ORDER BY finished_at DESC LIMIT 1
            """
        )
    if job is None:
        raise HTTPException(status_code=409, detail="Run a fast media scan first.")
    total_changes = int(job["added_count"] + job["changed_count"] + job["missing_count"])
    if total_changes == 0 and not data.force:
        return {"queued": False, "changes": 0, "message": "No media changes were detected."}

    await request_json(
        request.app.state.http,
        "POST",
        "Library/Refresh",
        require_key=True,
        expected_statuses=(204,),
    )
    async with pool.acquire() as connection:
        await connection.execute(
            "UPDATE media_scan_jobs SET jellyfin_refresh_queued=TRUE WHERE id=$1",
            job["id"],
        )
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, 'jellyfin.library.refresh_queued', 'media_scan', $2,
                    jsonb_build_object('changes', $3::bigint, 'force', $4::boolean))
            """,
            session.username,
            str(job["id"]),
            total_changes,
            data.force,
        )
    return {"queued": True, "changes": total_changes}
