from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
import uuid
from dataclasses import dataclass
from typing import Any

from fastapi import Cookie, Header, HTTPException, Request, status

from .settings import settings

SESSION_COOKIE = "galaxy_session"
PBKDF2_ITERATIONS = 260_000
VALID_ROLES = {"admin", "master_reseller", "reseller"}


@dataclass(frozen=True)
class PanelSession:
    username: str
    expires_at: int
    csrf: str
    role: str = "admin"
    account_id: str | None = None


def _b64url_encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def _b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def hash_password(password: str, *, salt: bytes | None = None) -> str:
    if not password:
        raise ValueError("Password must not be empty")
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
    )
    return f"pbkdf2_sha256:{PBKDF2_ITERATIONS}:{salt.hex()}:{digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, iterations_text, salt_hex, digest_hex = encoded.split(":", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        iterations = int(iterations_text)
        if iterations < 100_000 or iterations > 2_000_000:
            return False
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(digest_hex)
    except (ValueError, TypeError):
        return False

    actual = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        iterations,
    )
    return hmac.compare_digest(actual, expected)


def create_session_token(
    username: str,
    *,
    role: str = "admin",
    account_id: str | None = None,
) -> tuple[str, PanelSession]:
    if role not in VALID_ROLES:
        raise ValueError("Invalid panel role")
    expires_at = int(time.time()) + max(1, settings.session_ttl_hours) * 3600
    session = PanelSession(
        username=username,
        expires_at=expires_at,
        csrf=secrets.token_urlsafe(24),
        role=role,
        account_id=account_id,
    )
    payload: dict[str, Any] = {
        "sub": session.username,
        "exp": session.expires_at,
        "csrf": session.csrf,
        "role": session.role,
        "aid": session.account_id,
        "v": 2,
    }
    encoded_payload = _b64url_encode(
        json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    )
    signature = hmac.new(
        settings.app_secret.encode("utf-8"),
        encoded_payload.encode("ascii"),
        hashlib.sha256,
    ).digest()
    return f"{encoded_payload}.{_b64url_encode(signature)}", session


def decode_session_token(token: str) -> PanelSession:
    try:
        encoded_payload, encoded_signature = token.split(".", 1)
        expected = hmac.new(
            settings.app_secret.encode("utf-8"),
            encoded_payload.encode("ascii"),
            hashlib.sha256,
        ).digest()
        actual = _b64url_decode(encoded_signature)
        if not hmac.compare_digest(actual, expected):
            raise ValueError("bad signature")
        payload = json.loads(_b64url_decode(encoded_payload))
        username = str(payload["sub"])
        expires_at = int(payload["exp"])
        csrf = str(payload["csrf"])
        role = str(payload.get("role") or "admin")
        account_id = payload.get("aid")
        if expires_at <= int(time.time()):
            raise ValueError("expired")
        if role not in VALID_ROLES:
            raise ValueError("bad role")
        if account_id is not None:
            account_id = str(account_id)
        return PanelSession(
            username=username,
            expires_at=expires_at,
            csrf=csrf,
            role=role,
            account_id=account_id,
        )
    except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Panel session is missing or expired.",
        ) from exc


async def require_session(
    request: Request,
    galaxy_session: str | None = Cookie(default=None, alias=SESSION_COOKIE),
) -> PanelSession:
    if not galaxy_session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Panel login required.",
        )
    session = decode_session_token(galaxy_session)
    if session.account_id:
        db = getattr(request.app.state, "db", None)
        if db is None:
            raise HTTPException(status_code=503, detail="Database is unavailable.")
        async with db.acquire() as connection:
            row = await connection.fetchrow(
                "SELECT username, role, enabled FROM panel_accounts WHERE id=$1",
                uuid.UUID(session.account_id),
            )
        if row is None or not row["enabled"]:
            raise HTTPException(status_code=401, detail="This reseller account is disabled.")
        if row["role"] != session.role or row["username"] != session.username:
            raise HTTPException(status_code=401, detail="Panel account changed. Sign in again.")
    return session


def require_admin(session: PanelSession) -> PanelSession:
    if session.role != "admin":
        raise HTTPException(status_code=403, detail="Administrator access is required.")
    return session


def validate_csrf(session: PanelSession, csrf_header: str | None) -> None:
    if not csrf_header or not hmac.compare_digest(csrf_header, session.csrf):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Missing or invalid CSRF token.",
        )


def ensure_writes_enabled() -> None:
    if not settings.write_actions_enabled:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Write actions are disabled by server configuration.",
        )
