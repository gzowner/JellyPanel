from __future__ import annotations

import ipaddress
import json
import uuid
from collections import Counter
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from .access import assert_user_in_scope, is_admin, require_admin_role, scoped_reseller_ids
from .jellyfin import request_json
from .multiserver import (
    all_server_sessions, assignment_identity_map, get_server,
    propagate_policy, server_request_json, split_session_key,
)
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf

router = APIRouter(prefix="/stream-operations", tags=["Stream Operations"])


class StreamSettingsRequest(BaseModel):
    monitoring_enabled: bool = True
    sample_interval_seconds: int = Field(default=60, ge=60, le=3600)
    history_days: int = Field(default=30, ge=1, le=365)
    alert_window_minutes: int = Field(default=30, ge=5, le=1440)
    distinct_ip_warning: int = Field(default=3, ge=2, le=50)
    reconnect_warning: int = Field(default=8, ge=2, le=100)
    auto_stop_over_limit: bool = False


class MessageRequest(BaseModel):
    header: str = Field(default="Message from GalaxyTV", max_length=120)
    text: str = Field(min_length=1, max_length=1000)
    timeout_seconds: int = Field(default=12, ge=3, le=120)


class SuspendRequest(BaseModel):
    reason: str = Field(default="Suspended by GalaxyTV", max_length=1000)
    stop_playback: bool = True


class ResolveAlertRequest(BaseModel):
    notes: str = Field(default="", max_length=1000)


async def write_session(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


async def write_admin(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


def normalize_user_id(value: Any) -> str:
    text = str(value or "").replace("-", "").lower()
    if len(text) != 32:
        return ""
    try:
        return str(uuid.UUID(text))
    except ValueError:
        return ""


def endpoint_ip(value: str | None) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    candidate = text
    if candidate.startswith("[") and "]" in candidate:
        candidate = candidate[1:candidate.index("]")]
    else:
        try:
            ipaddress.ip_address(candidate)
            return candidate
        except ValueError:
            if candidate.count(":") == 1:
                host, port = candidate.rsplit(":", 1)
                if port.isdigit():
                    candidate = host
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return candidate[:255]


def item_title(item: dict[str, Any]) -> str:
    name = str(item.get("Name") or "")
    series = str(item.get("SeriesName") or "")
    season = item.get("ParentIndexNumber")
    episode = item.get("IndexNumber")
    if series and season is not None and episode is not None:
        return f"{series} · S{int(season):02d}E{int(episode):02d} · {name}"
    return name or series


async def audit(
    request: Request,
    *,
    actor: str,
    action: str,
    target_type: str,
    target_id: str,
    details: dict[str, Any],
) -> None:
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, $2, $3, $4, $5::jsonb)
            """,
            actor,
            action,
            target_type,
            target_id,
            json.dumps(details),
        )


async def get_settings(request: Request) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        row = await connection.fetchrow(
            """
            SELECT monitoring_enabled, sample_interval_seconds, history_days,
                   alert_window_minutes, distinct_ip_warning, reconnect_warning,
                   auto_stop_over_limit, updated_at, updated_by
            FROM stream_operations_settings
            WHERE id = 1
            """
        )
    if not row:
        raise HTTPException(status_code=500, detail="Stream operation settings are missing.")
    return dict(row)


async def current_jellyfin_sessions(request: Request) -> list[dict[str, Any]]:
    result, failures = await all_server_sessions(request.app.state.db, request.app.state.http)
    request.state.server_failures = failures
    return result


async def user_context(request: Request) -> dict[str, dict[str, Any]]:
    async with request.app.state.db.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT m.jellyfin_user_id::text,
                   m.max_sessions,
                   m.reseller_id::text,
                   r.username AS reseller_username,
                   p.name AS package_name
            FROM managed_jellyfin_users m
            LEFT JOIN panel_accounts r ON r.id = m.reseller_id
            LEFT JOIN account_packages p ON p.id = m.package_id
            """
        )
    return {normalize_user_id(row["jellyfin_user_id"]): dict(row) for row in rows}


async def allowed_user_ids(request: Request, session: PanelSession) -> set[str] | None:
    if is_admin(session):
        return None
    async with request.app.state.db.acquire() as connection:
        scope = await scoped_reseller_ids(connection, session)
        rows = await connection.fetch(
            """
            SELECT jellyfin_user_id::text
            FROM managed_jellyfin_users
            WHERE reseller_id = ANY($1::uuid[])
            """,
            scope or [],
        )
    return {normalize_user_id(row["jellyfin_user_id"]) for row in rows}


async def enriched_sessions(request: Request, session: PanelSession) -> list[dict[str, Any]]:
    raw_sessions = await current_jellyfin_sessions(request)
    managed = await user_context(request)
    identities = await assignment_identity_map(request.app.state.db)
    allowed = await allowed_user_ids(request, session)

    normalized: list[tuple[dict[str, Any], str, str]] = []
    playback_counts: Counter[str] = Counter()
    for current in raw_sessions:
        server_id = str(current.get("_server_id") or "")
        remote_user_id = normalize_user_id(current.get("_remote_user_id") or current.get("UserId"))
        canonical_user_id = identities.get((server_id, remote_user_id), remote_user_id)
        if not canonical_user_id:
            continue
        if allowed is not None and canonical_user_id not in allowed:
            continue
        normalized.append((current, canonical_user_id, remote_user_id))
        if current.get("NowPlayingItem"):
            playback_counts[canonical_user_id] += 1

    result: list[dict[str, Any]] = []
    for current, user_id, remote_user_id in normalized:
        now_playing = current.get("NowPlayingItem") or {}
        play_state = current.get("PlayState") or {}
        transcode = current.get("TranscodingInfo") or {}
        user = current.get("_server_user") or {}
        managed_user = managed.get(user_id, {})
        policy = user.get("Policy") or {}
        configured_limit = managed_user.get("max_sessions")
        if configured_limit is None:
            configured_limit = policy.get("MaxActiveSessions", 0)
        max_sessions = int(configured_limit or 0)
        current_count = int(playback_counts.get(user_id, 0))
        runtime_ticks = now_playing.get("RunTimeTicks")
        position_ticks = play_state.get("PositionTicks")
        progress = None
        if runtime_ticks and position_ticks is not None:
            try:
                progress = max(0.0, min(100.0, float(position_ticks) / float(runtime_ticks) * 100.0))
            except (TypeError, ValueError, ZeroDivisionError):
                progress = None
        play_method = str(play_state.get("PlayMethod") or "")
        is_transcoding = bool(transcode) or play_method.casefold() == "transcode"
        server_id = str(current.get("_server_id") or "")
        raw_session_id = str(current.get("Id") or "")
        result.append(
            {
                "id": f"{server_id}~{raw_session_id}",
                "raw_session_id": raw_session_id,
                "server_id": server_id,
                "server_name": current.get("_server_name"),
                "server_public_url": current.get("_server_public_url"),
                "user_id": user_id,
                "remote_user_id": remote_user_id,
                "user_name": current.get("UserName") or user.get("Name"),
                "is_administrator": bool(policy.get("IsAdministrator", False)),
                "is_disabled": bool(policy.get("IsDisabled", False)),
                "reseller_id": managed_user.get("reseller_id"),
                "reseller_username": managed_user.get("reseller_username"),
                "package_name": managed_user.get("package_name"),
                "managed": bool(managed_user),
                "max_sessions": max_sessions,
                "concurrent_playbacks": current_count,
                "over_limit": bool(max_sessions > 0 and current_count > max_sessions),
                "client": current.get("Client"),
                "device_name": current.get("DeviceName"),
                "device_id": current.get("DeviceId"),
                "device_type": current.get("DeviceType"),
                "application_version": current.get("ApplicationVersion"),
                "remote_endpoint": current.get("RemoteEndPoint"),
                "remote_ip": endpoint_ip(current.get("RemoteEndPoint")),
                "last_activity_date": current.get("LastActivityDate"),
                "last_playback_check_in": current.get("LastPlaybackCheckIn"),
                "is_active": bool(current.get("IsActive", False)),
                "supports_media_control": bool(current.get("SupportsMediaControl", False)),
                "supports_remote_control": bool(current.get("SupportsRemoteControl", False)),
                "now_playing": item_title(now_playing),
                "item_id": now_playing.get("Id"),
                "media_type": now_playing.get("MediaType") or now_playing.get("Type"),
                "runtime_ticks": runtime_ticks,
                "position_ticks": position_ticks,
                "progress_percent": progress,
                "is_paused": bool(play_state.get("IsPaused", False)),
                "play_method": play_method or ("Transcode" if is_transcoding else ""),
                "is_transcoding": is_transcoding,
                "bitrate": transcode.get("Bitrate"),
                "video_codec": transcode.get("VideoCodec"),
                "audio_codec": transcode.get("AudioCodec"),
                "width": transcode.get("Width"),
                "height": transcode.get("Height"),
                "framerate": transcode.get("Framerate"),
                "hardware_acceleration": transcode.get("HardwareAccelerationType"),
                "transcode_reasons": transcode.get("TranscodeReasons"),
            }
        )
    result.sort(
        key=lambda item: (
            not bool(item.get("now_playing")),
            str(item.get("server_name") or "").casefold(),
            str(item.get("user_name") or "").casefold(),
        )
    )
    return result


async def find_current_session(request: Request, panel_session: PanelSession, session_id: str) -> dict[str, Any]:
    for current in await enriched_sessions(request, panel_session):
        if str(current.get("id") or "") == session_id:
            return current
    raise HTTPException(status_code=404, detail="That Jellyfin session is no longer active or is outside your account scope.")


@router.get("/settings")
async def stream_settings(request: Request, session: PanelSession = Depends(require_session)) -> dict[str, Any]:
    require_admin_role(session)
    return await get_settings(request)


@router.put("/settings")
async def update_stream_settings(
    payload: StreamSettingsRequest,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        async with connection.transaction():
            await connection.execute(
                """
                UPDATE stream_operations_settings
                SET monitoring_enabled=$1,
                    sample_interval_seconds=$2,
                    history_days=$3,
                    alert_window_minutes=$4,
                    distinct_ip_warning=$5,
                    reconnect_warning=$6,
                    auto_stop_over_limit=$7,
                    updated_at=NOW(),
                    updated_by=$8
                WHERE id=1
                """,
                payload.monitoring_enabled,
                payload.sample_interval_seconds,
                payload.history_days,
                payload.alert_window_minutes,
                payload.distinct_ip_warning,
                payload.reconnect_warning,
                payload.auto_stop_over_limit,
                session.username,
            )
            await connection.execute(
                """
                INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
                VALUES ('panel', $1, 'stream_operations.settings.updated', 'stream_operations', 'settings', $2::jsonb)
                """,
                session.username,
                json.dumps(payload.model_dump()),
            )
    return await get_settings(request)


@router.get("/status")
async def status_view(request: Request, session: PanelSession = Depends(require_session)) -> dict[str, Any]:
    sessions = await enriched_sessions(request, session)
    server_failures = getattr(request.state, "server_failures", [])
    playing = [item for item in sessions if item.get("now_playing")]
    total_bitrate = sum(int(item.get("bitrate") or 0) for item in playing)
    async with request.app.state.db.acquire() as connection:
        scope = await scoped_reseller_ids(connection, session)
        if scope is None:
            alert_count = await connection.fetchval(
                "SELECT COUNT(*) FROM stream_operation_alerts WHERE resolved_at IS NULL"
            )
        else:
            alert_count = await connection.fetchval(
                """
                SELECT COUNT(*)
                FROM stream_operation_alerts
                WHERE resolved_at IS NULL AND reseller_id = ANY($1::uuid[])
                """,
                scope or [],
            )
    return {
        "settings": await get_settings(request) if is_admin(session) else None,
        "sessions": sessions,
        "count": len(sessions),
        "playing": len(playing),
        "idle": len(sessions) - len(playing),
        "transcoding": sum(1 for item in playing if item.get("is_transcoding")),
        "direct": sum(1 for item in playing if not item.get("is_transcoding")),
        "over_limit_users": len({item.get("user_id") for item in playing if item.get("over_limit")}),
        "total_bitrate": total_bitrate,
        "open_alerts": int(alert_count or 0),
        "server_failures": server_failures,
        "servers_reporting": len({item.get("server_id") for item in sessions}),
    }


@router.get("/alerts")
async def list_alerts(
    request: Request,
    limit: int = Query(default=100, ge=1, le=500),
    include_resolved: bool = False,
    session: PanelSession = Depends(require_session),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        scope = await scoped_reseller_ids(connection, session)
        where = []
        args: list[Any] = []
        if not include_resolved:
            where.append("a.resolved_at IS NULL")
        if scope is not None:
            args.append(scope or [])
            where.append(f"a.reseller_id = ANY(${len(args)}::uuid[])")
        args.append(limit)
        rows = await connection.fetch(
            f"""
            SELECT a.id::text, a.alert_type, a.severity, a.jellyfin_user_id::text,
                   a.user_name, a.reseller_id::text, r.username AS reseller_username,
                   a.session_id, a.remote_endpoint, a.details, a.first_seen_at,
                   a.last_seen_at, a.occurrence_count, a.resolved_at, a.resolved_by,
                   a.resolution_notes, a.server_id::text, a.server_name
            FROM stream_operation_alerts a
            LEFT JOIN panel_accounts r ON r.id = a.reseller_id
            {('WHERE ' + ' AND '.join(where)) if where else ''}
            ORDER BY (a.resolved_at IS NULL) DESC, a.last_seen_at DESC
            LIMIT ${len(args)}
            """,
            *args,
        )
    return {"alerts": [dict(row) for row in rows], "count": len(rows)}


@router.get("/history")
async def session_history(
    request: Request,
    user_id: uuid.UUID | None = None,
    limit: int = Query(default=200, ge=1, le=1000),
    session: PanelSession = Depends(require_session),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        scope = await scoped_reseller_ids(connection, session)
        where: list[str] = []
        args: list[Any] = []
        if scope is not None:
            args.append(scope or [])
            where.append(f"s.reseller_id = ANY(${len(args)}::uuid[])")
        if user_id is not None:
            if not is_admin(session):
                await assert_user_in_scope(connection, session, user_id)
            args.append(user_id)
            where.append(f"s.jellyfin_user_id = ${len(args)}")
        args.append(limit)
        rows = await connection.fetch(
            f"""
            SELECT s.id, s.observed_at, s.jellyfin_session_id,
                   s.jellyfin_user_id::text, s.user_name, s.reseller_id::text,
                   r.username AS reseller_username, s.remote_endpoint, s.remote_ip,
                   s.client, s.device_name, s.application_version, s.item_name,
                   s.media_type, s.play_method, s.is_paused, s.bitrate,
                   s.video_codec, s.audio_codec, s.width, s.height,
                   s.position_ticks, s.runtime_ticks, s.server_id::text, s.server_name
            FROM stream_session_samples s
            LEFT JOIN panel_accounts r ON r.id = s.reseller_id
            {('WHERE ' + ' AND '.join(where)) if where else ''}
            ORDER BY s.observed_at DESC
            LIMIT ${len(args)}
            """,
            *args,
        )
    return {"samples": [dict(row) for row in rows], "count": len(rows)}


@router.post("/sessions/{session_id}/stop")
async def stop_playback(
    session_id: str,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    current = await find_current_session(request, session, session_id)
    if not current.get("now_playing"):
        raise HTTPException(status_code=409, detail="That session is not currently playing media.")
    server_id, raw_session_id = split_session_key(session_id)
    server = await get_server(request.app.state.db, server_id, enabled_only=True)
    await server_request_json(
        request.app.state.http,
        server,
        "POST",
        f"Sessions/{raw_session_id}/Playing/Stop",
        expected_statuses=(204,),
    )
    await audit(
        request,
        actor=session.username,
        action="stream.session.stop",
        target_type="jellyfin_session",
        target_id=session_id,
        details={
            "user_id": current.get("user_id"),
            "user_name": current.get("user_name"),
            "item": current.get("now_playing"),
            "remote_endpoint": current.get("remote_endpoint"),
            "server_id": current.get("server_id"),
            "server_name": current.get("server_name"),
        },
    )
    return {"stopped": True}


@router.post("/sessions/{session_id}/message")
async def send_message(
    session_id: str,
    payload: MessageRequest,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    current = await find_current_session(request, session, session_id)
    server_id, raw_session_id = split_session_key(session_id)
    server = await get_server(request.app.state.db, server_id, enabled_only=True)
    await server_request_json(
        request.app.state.http,
        server,
        "POST",
        f"Sessions/{raw_session_id}/Message",
        json_data={
            "Header": payload.header.strip() or "Message from GalaxyTV",
            "Text": payload.text.strip(),
            "TimeoutMs": payload.timeout_seconds * 1000,
        },
        expected_statuses=(204,),
    )
    await audit(
        request,
        actor=session.username,
        action="stream.session.message",
        target_type="jellyfin_session",
        target_id=session_id,
        details={
            "user_id": current.get("user_id"),
            "user_name": current.get("user_name"),
            "header": payload.header,
            "server_id": current.get("server_id"),
            "server_name": current.get("server_name"),
        },
    )
    return {"sent": True}


async def change_user_disabled(
    user_id: uuid.UUID,
    disabled: bool,
    payload: SuspendRequest,
    request: Request,
    session: PanelSession,
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    async with request.app.state.db.acquire() as connection:
        await assert_user_in_scope(connection, session, user_id)
    user = await request_json(
        request.app.state.http,
        "GET",
        f"Users/{user_id}",
        require_key=True,
        expected_statuses=(200,),
    )
    policy = dict(user.get("Policy") or {})
    if policy.get("IsAdministrator", False):
        raise HTTPException(status_code=403, detail="Jellyfin administrator accounts are protected.")
    policy["IsDisabled"] = disabled
    await request_json(
        request.app.state.http,
        "POST",
        f"Users/{user_id}/Policy",
        require_key=True,
        json_data=policy,
        expected_statuses=(204,),
    )
    remote_sync = await propagate_policy(
        request.app.state.db, request.app.state.http, user_id, policy
    )

    stopped = 0
    if disabled and payload.stop_playback:
        for current in await enriched_sessions(request, session):
            if current.get("user_id") == str(user_id) and current.get("now_playing"):
                try:
                    current_server_id, raw_session_id = split_session_key(str(current["id"]))
                    current_server = await get_server(
                        request.app.state.db, current_server_id, enabled_only=True
                    )
                    await server_request_json(
                        request.app.state.http,
                        current_server,
                        "POST",
                        f"Sessions/{raw_session_id}/Playing/Stop",
                        expected_statuses=(204,),
                    )
                    stopped += 1
                except HTTPException:
                    pass

    async with request.app.state.db.acquire() as connection:
        async with connection.transaction():
            await connection.execute(
                """
                UPDATE managed_jellyfin_users
                SET disabled_by_expiration = FALSE,
                    last_policy_sync_at = NOW(),
                    updated_at = NOW()
                WHERE jellyfin_user_id = $1
                """,
                user_id,
            )
            await connection.execute(
                """
                INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
                VALUES ('panel', $1, $2, 'jellyfin_user', $3, $4::jsonb)
                """,
                session.username,
                "stream.user.suspended" if disabled else "stream.user.reenabled",
                str(user_id),
                json.dumps({"name": user.get("Name"), "reason": payload.reason, "stopped_sessions": stopped, "remote_sync": remote_sync}),
            )
    return {"updated": True, "disabled": disabled, "stopped_sessions": stopped, "remote_sync": remote_sync}


@router.post("/users/{user_id}/suspend")
async def suspend_user(
    user_id: uuid.UUID,
    payload: SuspendRequest,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    return await change_user_disabled(user_id, True, payload, request, session)


@router.post("/users/{user_id}/enable")
async def enable_user(
    user_id: uuid.UUID,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    return await change_user_disabled(user_id, False, SuspendRequest(reason="Re-enabled by GalaxyTV", stop_playback=False), request, session)


@router.post("/alerts/{alert_id}/resolve")
async def resolve_alert(
    alert_id: uuid.UUID,
    payload: ResolveAlertRequest,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        row = await connection.fetchrow(
            "SELECT reseller_id FROM stream_operation_alerts WHERE id=$1",
            alert_id,
        )
        if row is None:
            raise HTTPException(status_code=404, detail="Alert not found.")
        if not is_admin(session):
            scope = await scoped_reseller_ids(connection, session)
            if row["reseller_id"] not in (scope or []):
                raise HTTPException(status_code=403, detail="That alert is outside your account scope.")
        await connection.execute(
            """
            UPDATE stream_operation_alerts
            SET resolved_at=NOW(), resolved_by=$2, resolution_notes=$3
            WHERE id=$1 AND resolved_at IS NULL
            """,
            alert_id,
            session.username,
            payload.notes,
        )
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, 'stream.alert.resolved', 'stream_alert', $2, $3::jsonb)
            """,
            session.username,
            str(alert_id),
            json.dumps({"notes": payload.notes}),
        )
    return {"resolved": True}
