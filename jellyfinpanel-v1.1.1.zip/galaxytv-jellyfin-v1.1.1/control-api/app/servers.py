from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field, field_validator

from .access import require_admin_role
from .multiserver import (
    JellyfinServer,
    assignment_rows,
    check_server_health,
    ensure_default_server,
    get_enabled_servers,
    get_server,
    normalize_url,
    safe_server,
    server_request_json,
    sync_user_to_server,
)
from .secret_store import encrypt_secret
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf

router = APIRouter(prefix="/servers", tags=["Jellyfin Servers"])


class ServerPayload(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    internal_url: str = Field(min_length=8, max_length=1000)
    public_url: str = Field(min_length=8, max_length=1000)
    api_key: str = Field(default="", max_length=1000)
    enabled: bool = True
    verify_tls: bool = True
    connect_timeout_seconds: int = Field(default=20, ge=3, le=120)
    notes: str = Field(default="", max_length=2000)

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Server name cannot be blank.")
        return value

    @field_validator("internal_url", "public_url")
    @classmethod
    def clean_url(cls, value: str) -> str:
        return normalize_url(value)


class AssignmentRequest(BaseModel):
    password: str | None = Field(default=None, max_length=256)
    create_missing: bool = True


class RemoveAssignmentRequest(BaseModel):
    delete_remote_user: bool = False


async def read_admin(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


async def write_admin(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


async def audit(
    request: Request,
    *,
    actor: str,
    action: str,
    target_id: str,
    details: dict[str, Any],
) -> None:
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, $2, 'jellyfin_server', $3, $4::jsonb)
            """,
            actor,
            action,
            target_id,
            json.dumps(details),
        )


def temporary_server(payload: ServerPayload) -> JellyfinServer:
    return JellyfinServer(
        id=uuid.uuid4(),
        name=payload.name,
        internal_url=payload.internal_url,
        public_url=payload.public_url,
        api_key=payload.api_key.strip(),
        enabled=True,
        is_default=False,
        is_local=False,
        verify_tls=payload.verify_tls,
        connect_timeout_seconds=payload.connect_timeout_seconds,
        notes=payload.notes,
    )


async def verify_temporary_server(client: httpx.AsyncClient, server: JellyfinServer) -> dict[str, Any]:
    public = await server_request_json(
        client,
        server,
        "GET",
        "System/Info/Public",
        require_key=False,
        expected_statuses=(200,),
    )
    await server_request_json(
        client,
        server,
        "GET",
        "System/Info",
        require_key=True,
        expected_statuses=(200,),
    )
    return public or {}


@router.get("")
async def list_servers(
    request: Request,
    _: PanelSession = Depends(read_admin),
) -> dict[str, Any]:
    await ensure_default_server(request.app.state.db)
    async with request.app.state.db.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT s.*,
                   COUNT(a.id)::integer AS assigned_users,
                   COUNT(a.id) FILTER (WHERE a.last_sync_status='failed')::integer AS failed_assignments
            FROM jellyfin_servers s
            LEFT JOIN server_user_assignments a ON a.server_id=s.id
            GROUP BY s.id
            ORDER BY s.is_default DESC, LOWER(s.name)
            """
        )
    servers = [safe_server(row) for row in rows]
    return {
        "count": len(servers),
        "enabled": sum(1 for item in servers if item["enabled"]),
        "online": sum(1 for item in servers if item["last_status"] == "online"),
        "servers": servers,
    }


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_server(
    payload: ServerPayload,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    if not payload.api_key.strip():
        raise HTTPException(status_code=422, detail="An API key is required for an additional server.")
    public = await verify_temporary_server(request.app.state.http, temporary_server(payload))
    async with request.app.state.db.acquire() as connection:
        try:
            row = await connection.fetchrow(
                """
                INSERT INTO jellyfin_servers
                    (name, internal_url, public_url, api_key_encrypted, enabled,
                     is_default, is_local, verify_tls, connect_timeout_seconds,
                     notes, last_status, last_status_message, last_server_name,
                     last_version, last_checked_at)
                VALUES ($1,$2,$3,$4,$5,FALSE,FALSE,$6,$7,$8,'online','Connected',$9,$10,NOW())
                RETURNING *
                """,
                payload.name,
                payload.internal_url,
                payload.public_url,
                encrypt_secret(payload.api_key),
                payload.enabled,
                payload.verify_tls,
                payload.connect_timeout_seconds,
                payload.notes,
                public.get("ServerName") or public.get("Name"),
                public.get("Version"),
            )
        except Exception as exc:
            if "unique" in str(exc).lower():
                raise HTTPException(status_code=409, detail="A server with that name already exists.") from exc
            raise
    await audit(
        request,
        actor=session.username,
        action="server.create",
        target_id=str(row["id"]),
        details={"name": payload.name, "internal_url": payload.internal_url, "public_url": payload.public_url},
    )
    return safe_server(row)


@router.put("/{server_id}")
async def update_server(
    server_id: uuid.UUID,
    payload: ServerPayload,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    current = await get_server(request.app.state.db, server_id)
    if current.is_local:
        if payload.internal_url != current.internal_url or payload.public_url != current.public_url:
            raise HTTPException(
                status_code=409,
                detail="The local primary server URLs are controlled by .env. Change them with the installer or repair mode.",
            )
        if payload.api_key.strip():
            raise HTTPException(
                status_code=409,
                detail="The local primary API key is controlled by .env. Use the Jellyfin key management script.",
            )
        api_key = current.api_key
    else:
        api_key = payload.api_key.strip() or current.api_key
    candidate = temporary_server(payload)
    candidate.id = current.id
    candidate.api_key = api_key
    public = await verify_temporary_server(request.app.state.http, candidate)
    async with request.app.state.db.acquire() as connection:
        try:
            row = await connection.fetchrow(
                """
                UPDATE jellyfin_servers
                SET name=$2,
                    internal_url=$3,
                    public_url=$4,
                    api_key_encrypted=$5,
                    enabled=$6,
                    verify_tls=$7,
                    connect_timeout_seconds=$8,
                    notes=$9,
                    last_status='online',
                    last_status_message='Connected',
                    last_server_name=$10,
                    last_version=$11,
                    last_checked_at=NOW(),
                    updated_at=NOW()
                WHERE id=$1
                RETURNING *
                """,
                server_id,
                payload.name,
                current.internal_url if current.is_local else payload.internal_url,
                current.public_url if current.is_local else payload.public_url,
                encrypt_secret(api_key),
                payload.enabled,
                payload.verify_tls,
                payload.connect_timeout_seconds,
                payload.notes,
                public.get("ServerName") or public.get("Name"),
                public.get("Version"),
            )
        except Exception as exc:
            if "unique" in str(exc).lower():
                raise HTTPException(status_code=409, detail="A server with that name already exists.") from exc
            raise
    await audit(
        request,
        actor=session.username,
        action="server.update",
        target_id=str(server_id),
        details={"name": payload.name, "enabled": payload.enabled},
    )
    return safe_server(row)


@router.delete("/{server_id}")
async def delete_server(
    server_id: uuid.UUID,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, bool]:
    server = await get_server(request.app.state.db, server_id)
    if server.is_default or server.is_local:
        raise HTTPException(status_code=409, detail="The primary local server cannot be removed.")
    async with request.app.state.db.acquire() as connection:
        await connection.execute("DELETE FROM jellyfin_servers WHERE id=$1", server_id)
    await audit(
        request,
        actor=session.username,
        action="server.delete",
        target_id=str(server_id),
        details={"name": server.name},
    )
    return {"deleted": True}


@router.post("/{server_id}/test")
async def test_server(
    server_id: uuid.UUID,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    server = await get_server(request.app.state.db, server_id)
    result = await check_server_health(request.app.state.db, request.app.state.http, server)
    await audit(
        request,
        actor=session.username,
        action="server.test",
        target_id=str(server_id),
        details={"status": result["status"], "message": result["message"]},
    )
    return result


@router.post("/actions/test-all")
async def test_all_servers(
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    servers = await get_enabled_servers(request.app.state.db)
    results = list(
        await asyncio.gather(
            *(
                check_server_health(request.app.state.db, request.app.state.http, server)
                for server in servers
            )
        )
    )
    await audit(
        request,
        actor=session.username,
        action="server.test_all",
        target_id="all",
        details={"servers": len(results), "online": sum(1 for item in results if item["status"] == "online")},
    )
    return {"results": results}


@router.get("/users/{user_id}/assignments")
async def user_assignments(
    user_id: uuid.UUID,
    request: Request,
    _: PanelSession = Depends(read_admin),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        exists = await connection.fetchval(
            "SELECT EXISTS(SELECT 1 FROM managed_jellyfin_users WHERE jellyfin_user_id=$1)",
            user_id,
        )
    if not exists:
        raise HTTPException(status_code=404, detail="Manage this Jellyfin user before assigning additional servers.")
    rows = await assignment_rows(request.app.state.db, user_id)
    return {"user_id": str(user_id), "assignments": rows}


@router.post("/{server_id}/users/{user_id}/assign")
async def assign_user(
    server_id: uuid.UUID,
    user_id: uuid.UUID,
    payload: AssignmentRequest,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    result = await sync_user_to_server(
        request.app.state.db,
        request.app.state.http,
        user_id,
        server_id,
        password=payload.password,
        create_missing=payload.create_missing,
    )
    await audit(
        request,
        actor=session.username,
        action="server.user.assign",
        target_id=str(server_id),
        details={"user_id": str(user_id), **result},
    )
    return result


@router.post("/users/{user_id}/sync-all")
async def sync_all_assignments(
    user_id: uuid.UUID,
    payload: AssignmentRequest,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    rows = await assignment_rows(request.app.state.db, user_id)
    results = []
    for row in rows:
        if row["is_default"] or not row["enabled"] or not row["assignment_id"]:
            continue
        try:
            results.append(
                await sync_user_to_server(
                    request.app.state.db,
                    request.app.state.http,
                    user_id,
                    uuid.UUID(row["server_id"]),
                    password=payload.password,
                    create_missing=payload.create_missing,
                )
            )
        except HTTPException as exc:
            results.append(
                {
                    "server_id": row["server_id"],
                    "server_name": row["server_name"],
                    "status": "failed",
                    "message": str(exc.detail),
                }
            )
    await audit(
        request,
        actor=session.username,
        action="server.user.sync_all",
        target_id="all",
        details={"user_id": str(user_id), "results": results},
    )
    return {
        "user_id": str(user_id),
        "synced": sum(1 for item in results if item.get("status") in ("synced", "warning")),
        "failed": sum(1 for item in results if item.get("status") == "failed"),
        "results": results,
    }


@router.delete("/{server_id}/users/{user_id}/assignment")
async def remove_user_assignment(
    server_id: uuid.UUID,
    user_id: uuid.UUID,
    request: Request,
    delete_remote_user: bool = Query(default=False),
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    server = await get_server(request.app.state.db, server_id)
    if server.is_default:
        raise HTTPException(status_code=409, detail="The primary-server assignment cannot be removed.")
    async with request.app.state.db.acquire() as connection:
        row = await connection.fetchrow(
            """
            SELECT remote_user_id, remote_user_name
            FROM server_user_assignments
            WHERE server_id=$1 AND jellyfin_user_id=$2
            """,
            server_id,
            user_id,
        )
    if row is None:
        raise HTTPException(status_code=404, detail="Assignment not found.")
    deleted_remote = False
    if delete_remote_user and row["remote_user_id"]:
        await server_request_json(
            request.app.state.http,
            server,
            "DELETE",
            f"Users/{row['remote_user_id']}",
            expected_statuses=(204,),
            allow_not_found=True,
        )
        deleted_remote = True
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            "DELETE FROM server_user_assignments WHERE server_id=$1 AND jellyfin_user_id=$2",
            server_id,
            user_id,
        )
    await audit(
        request,
        actor=session.username,
        action="server.user.unassign",
        target_id=str(server_id),
        details={"user_id": str(user_id), "remote_user_deleted": deleted_remote},
    )
    return {"removed": True, "remote_user_deleted": deleted_remote}
