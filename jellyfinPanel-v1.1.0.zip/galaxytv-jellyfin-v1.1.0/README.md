# GalaxyTV Jellyfin v1.1.0 Multi-Server

GalaxyTV v1.1.0 adds central management for multiple independent Jellyfin servers while preserving the complete v1.0 feature set: users, expiration, packages, resellers, credits, M3U, XMLTV, EPG mapping, media inventory, STRM mirror, stream operations, backups, restore, diagnostics, and repair.

The original Jellyfin instance is automatically registered as **Local Jellyfin**, marked as the protected default server, and receives assignments for all existing managed users. Existing accounts and settings remain unchanged.

## What multi-server support does

- Registers additional Jellyfin servers by internal API URL, public client URL, and API key.
- Tests server reachability, API authentication, version, and server identity.
- Keeps each Jellyfin installation and database independent.
- Assigns a GalaxyTV-managed user to selected servers.
- Links an existing same-name remote Jellyfin user or creates a missing account.
- Synchronizes the default server's user policy to assigned servers.
- Synchronizes later policy, package, expiration, suspension, and password changes.
- Aggregates active sessions from every enabled server.
- Applies package connection limits across the combined servers.
- Sends messages and stop commands to the correct server.
- Shows per-server health and failed user synchronization.
- Protects the local default server from deletion.

GalaxyTV does not share or copy the Jellyfin database between servers. It controls each server through its supported API.

## Upgrade from v1.0.0 or v1.0.1

```bash
cd /root
unzip galaxytv-jellyfin-v1.1.0.zip
cd galaxytv-jellyfin-v1.1.0
sudo bash install.sh --mode upgrade
```

The upgrade process:

1. Verifies the release checksum manifest.
2. Checks Docker, disk space, and the current installation.
3. Creates an application rollback snapshot and requests a managed backup.
4. Preserves `.env`, Jellyfin, PostgreSQL, Redis, backups, logs, credentials, and STRM output.
5. Applies additive database migration 14.
6. Registers the current Jellyfin server as the protected default.
7. Rebuilds the Control API and worker with multi-server support.
8. Validates all critical services and database schema.
9. Restores the previous application files automatically if validation fails.

After upgrading, force-refresh the browser with `Ctrl+F5`.

## Add another Jellyfin server

On the additional Jellyfin server, create an API key under:

```text
Dashboard → Advanced → API Keys
```

In GalaxyTV:

1. Open **Servers**.
2. Click **Add server**.
3. Enter a recognizable name.
4. Enter the internal/API address, such as `http://10.0.0.25:8096`.
5. Enter the public/client address customers use.
6. Enter the Jellyfin API key.
7. Keep certificate verification enabled for valid HTTPS certificates.
8. Click **Test and save**.

The internal address must be reachable from the GalaxyTV Control API container. A private LAN, WireGuard, Tailscale, or other protected network address is preferred over exposing Jellyfin's API directly to the public internet.

## Assign users

Open **Users**, then click **Servers** beside a managed account.

For each additional server:

- **Assign** links an existing same-name account or creates a missing account.
- **Sync** reapplies policy and optionally a supplied password.
- **Unassign** removes GalaxyTV's link. You choose whether the remote Jellyfin user is also deleted.
- **Sync assigned** synchronizes every existing non-default assignment.

Jellyfin does not expose existing user passwords through its API. GalaxyTV therefore cannot read or copy a password from the default server. Enter a password when assigning a newly created remote account. Leaving it blank creates a blank-password account only when no matching remote account exists.

Administrator accounts cannot be assigned, overwritten, suspended, or deleted through the multi-server controls.

## Policy behavior

The default local Jellyfin user remains the canonical account. GalaxyTV propagates these supported settings to assigned servers:

- Disabled or enabled state.
- Hidden state.
- Live TV access.
- Download permission.
- Remote access.
- Video and audio transcoding.
- Remuxing.
- Active-session limit.
- Enabled channel and folder policy fields.

Package renewal and expiration processing also update assigned servers. A failure on one server is recorded without preventing the primary account from being updated.

## Stream Operations

Stream Operations combines sessions from all enabled servers and shows the server for every playback. Connection limits are calculated per canonical GalaxyTV user across the combined servers.

Commands are routed back to the correct Jellyfin server:

- Send client message.
- Stop playback.
- Suspend the managed user across assigned servers.
- Re-enable the managed user across assigned servers.

Unlinked remote sessions remain visible to administrators but cannot be suspended as a GalaxyTV-managed user until the account is assigned.

Automatic over-limit stopping remains disabled by default. Test session reporting on the clients you support before enabling it.

## Server outages

An offline or unauthorized secondary server does not prevent the panel from operating. GalaxyTV records the failure, continues querying other enabled servers, and displays the affected server in **Servers** and **Stream Operations**.

Disable a server temporarily when it is intentionally offline. Disabled servers are excluded from session aggregation and policy synchronization.

## API-key security

Additional-server API keys are encrypted before storage using a key derived from GalaxyTV's `APP_SECRET`. API keys are never returned to the browser after being saved.

Keep `/opt/galaxytv-jellyfin/.env` private. Changing `APP_SECRET` makes previously stored additional-server API keys unreadable. Re-enter each remote API key if the secret is intentionally rotated.

Managed backups include PostgreSQL and an `.env` snapshot, but restore does not automatically replace the active `.env`. When moving a backup to another GalaxyTV host, restore the original `APP_SECRET` securely or re-enter all additional-server API keys.

## Fresh installation

```bash
sudo apt-get update
sudo apt-get install -y unzip
unzip galaxytv-jellyfin-v1.1.0.zip
cd galaxytv-jellyfin-v1.1.0
sudo bash install.sh
```

Select:

```text
1) Fresh installation
```

Supported and tested target: Ubuntu Server 24.04 LTS on `amd64` or `arm64`.

Default ports:

```text
GalaxyTV panel:       8181
Control API:          8182, localhost only
M3U gateway:          8183, localhost only
Jellyfin:             8097
Media gateway:        8190, Docker internal
Operations Agent:     8191, Docker internal
```

## Installer modes

```bash
sudo bash install.sh --mode fresh
sudo bash install.sh --mode upgrade
sudo bash install.sh --mode repair
sudo bash install.sh --mode restore
sudo bash install.sh --mode diagnostics
sudo bash install.sh --mode uninstall
```

Data-preserving uninstall removes the GalaxyTV containers and network without deleting Jellyfin data, PostgreSQL, Redis, backups, logs, STRM output, or media.

## Management commands

```bash
sudo /opt/galaxytv-jellyfin/scripts/manage.sh status
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
sudo /opt/galaxytv-jellyfin/scripts/manage.sh logs
sudo /opt/galaxytv-jellyfin/scripts/manage.sh backup
sudo /opt/galaxytv-jellyfin/scripts/manage.sh diagnostics
sudo /opt/galaxytv-jellyfin/scripts/manage.sh streams
```

## Persistent data

```text
/opt/galaxytv-jellyfin/.env
/opt/galaxytv-jellyfin/jellyfin/config
/opt/galaxytv-jellyfin/jellyfin/cache
/opt/galaxytv-jellyfin/postgres/data
/opt/galaxytv-jellyfin/redis/data
/opt/galaxytv-jellyfin/backups
/opt/galaxytv-jellyfin/logs
/opt/galaxytv-jellyfin/strm-library
```

The media mount is read-only to the GalaxyTV scan and playback gateways and is never removed by the installer.

## Security and legal notice

- Do not expose the panel or server API addresses publicly without HTTPS, firewall rules, and a correctly configured reverse proxy or private network.
- API keys, `.env`, backups, credentials, and diagnostics must remain private.
- No media, television channels, EPG feeds, or provider service is included.
- Use only media and sources you own or are authorized to distribute.
- GalaxyTV is independent software and is not an official Jellyfin product.

See `SECURITY.md` for additional deployment guidance.

## Release validation

The archive contains `release-files.sha256`. Fresh, upgrade, and repair modes verify extracted files before modifying the server.

Validation includes:

- Bash syntax checks.
- Python bytecode compilation.
- Docker Compose YAML parsing.
- Browser JavaScript syntax checks.
- HTML ID/reference consistency.
- Migration sequencing and expected schema 14.
- Cumulative ZIP integrity and internal SHA-256 verification.

The v1.0.1 upgrade mechanism was verified successfully on the user's server. Docker runtime validation of the new multi-server paths must be completed on the local test installation before public release.
