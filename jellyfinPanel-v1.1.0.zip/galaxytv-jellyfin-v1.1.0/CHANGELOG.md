# Changelog

## 1.1.0 Multi-Server

- Adds a central Jellyfin server registry with encrypted API keys and health checks.
- Automatically registers the existing local Jellyfin installation as the protected default server.
- Adds per-user server assignments, existing-account linking, remote-user creation, and synchronization status.
- Propagates policy, package, expiration, suspension, enablement, and password changes to assigned servers.
- Aggregates live sessions and package connection limits across enabled servers.
- Routes playback messages and stop commands to the correct Jellyfin server.
- Adds server-aware stream samples, alerts, operations status, and user synchronization warnings.
- Adds database schema 14.
- Preserves all v1.0.1 data and installer rollback behavior.

## 1.0.1 Update-System Test

- Adds an administrator-only Update History page.
- Records installed GalaxyTV release versions in PostgreSQL.
- Displays the current application version and database schema.
- Provides a safe cumulative upgrade package for testing v1.0.0 to v1.0.1 backup, migration, validation, and rollback behavior.
- No user, package, reseller, M3U, EPG, media, mirror, or Jellyfin settings are changed.

# GalaxyTV Changelog

## 1.0.0 Stable

- Consolidated all releases through v0.11.0 into one cumulative archive.
- Added guided fresh-install and automatic upgrade detection.
- Added explicit fresh, upgrade, repair, restore, diagnostics, and uninstall modes.
- Added Ubuntu 24.04, architecture, memory, disk, Docker, port, path, and mount preflight checks.
- Added configurable media path, inventory root, rclone settings, timezone, ports, credentials, and GPU access.
- Added release-file checksum verification.
- Added local application/PostgreSQL rollback snapshots before upgrades and repairs.
- Added managed pre-upgrade backup requests.
- Added automatic application rollback after failed deployment validation.
- Added complete service, endpoint, media-mount, and migration health checks.
- Added generic rollback-last-upgrade command.
- Added host-side diagnostics fallback.
- Added data-preserving container uninstall.
- Updated managed restore so PostgreSQL-only restore points can complete when a Jellyfin archive is unavailable.
- Removed development-version rollback scripts from the stable distribution.
