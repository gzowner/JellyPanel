from __future__ import annotations

import mimetypes
import os
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

import asyncpg
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse

DATABASE_URL = os.environ["DATABASE_URL"]
MEDIA_ROOT = Path(os.environ.get("MEDIA_ROOT", "/media")).resolve()


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.db = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=8)
    yield
    await app.state.db.close()


app = FastAPI(title="GalaxyTV Media Gateway", version="1.1.0", lifespan=lifespan, docs_url=None, redoc_url=None)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"service": "GalaxyTV Media Gateway", "version": "1.1.0", "status": "ok"}


@app.api_route("/media/{stable_id}/stream{suffix:path}", methods=["GET", "HEAD"])
async def stream_media(stable_id: uuid.UUID, suffix: str, request: Request):
    async with request.app.state.db.acquire() as connection:
        row = await connection.fetchrow(
            "SELECT inventory_path FROM library_mirror_items WHERE stable_id=$1 AND active=TRUE",
            stable_id,
        )
    if row is None:
        raise HTTPException(status_code=404, detail="Media mapping was not found.")
    target = (MEDIA_ROOT / str(row["inventory_path"])).resolve()
    if MEDIA_ROOT not in target.parents or not target.is_file():
        raise HTTPException(status_code=404, detail="Media file is unavailable.")
    media_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    return FileResponse(target, media_type=media_type, filename=target.name, content_disposition_type="inline")
