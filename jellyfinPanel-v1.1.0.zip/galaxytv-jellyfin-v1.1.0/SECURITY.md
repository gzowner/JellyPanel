# GalaxyTV Security Notes

GalaxyTV v1.1.0 defaults to local HTTP because the development and first stable tests use local systems.

Before exposing GalaxyTV or Jellyfin outside a trusted private network:

- Use HTTPS through a maintained reverse proxy.
- Restrict the GalaxyTV panel by firewall, VPN, or trusted source addresses.
- Keep the Control API and M3U gateway bound to localhost.
- Do not publish the Operations Agent or media gateway ports.
- Configure Jellyfin Known Proxies when a reverse proxy is introduced.
- Protect `.env`, the panel credential file, managed backups, and diagnostic archives.
- Use a unique panel password and rotate any copied API keys.
- Review diagnostics manually before sharing them.
- Keep automatic over-limit stopping disabled until client behavior has been observed.

The installer does not modify the host firewall because network requirements differ between local, VPN, and public deployments.
