#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${GALAXYTV_BASE_DIR:-/opt/galaxytv-jellyfin}"
COMPOSE="$BASE_DIR/scripts/compose.sh"
cd "$BASE_DIR"

usage() {
  cat <<EOF_USAGE
Usage: $0 COMMAND

Commands:
  status          Show container status
  health          Run the complete stable health check
  start           Start the stack
  stop            Stop the stack without deleting data
  restart         Restart the stack
  logs            Follow logs from all services
  update-images   Pull/build current images and recreate services
  backup          Start a managed PostgreSQL and Jellyfin backup
  restore         Open the stable restore workflow
  diagnostics     Create a redacted diagnostics ZIP
  repair          Rebuild the currently installed files and validate services
  streams         Show stream-operation diagnostics
  servers         Show multi-server registry and sync diagnostics
  credentials     Show generated panel credentials when available
  panel-password  Change panel credentials interactively
  jellyfin-key    Set or replace the Jellyfin API key
  uninstall       Remove containers and preserve all data
  version         Show the installed GalaxyTV release
EOF_USAGE
}

case "${1:-}" in
  status) "$COMPOSE" ps ;;
  health) exec "$BASE_DIR/scripts/health-check.sh" ;;
  start) "$COMPOSE" up -d ;;
  stop) "$COMPOSE" stop ;;
  restart) "$COMPOSE" restart ;;
  logs) "$COMPOSE" logs -f --tail=200 ;;
  update-images)
    "$COMPOSE" pull --ignore-buildable
    "$COMPOSE" build --pull
    "$COMPOSE" up -d --remove-orphans
    ;;
  backup)
    "$COMPOSE" exec -T ops-agent python - <<'PY'
import json, os, urllib.request
body=json.dumps({"backup_type":"manual","requested_by":"manage.sh","include_mirror":False,"retention_daily":7,"retention_weekly":4}).encode()
req=urllib.request.Request('http://127.0.0.1:8191/backups',data=body,method='POST',headers={'Content-Type':'application/json','X-Ops-Token':os.environ['OPS_AGENT_TOKEN']})
with urllib.request.urlopen(req,timeout=30) as response:
    print(json.dumps(json.load(response),indent=2))
PY
    ;;
  restore) exec "$BASE_DIR/scripts/installer.sh" --mode restore ;;
  diagnostics) exec "$BASE_DIR/scripts/export-diagnostics.sh" ;;
  repair) exec "$BASE_DIR/scripts/installer.sh" --mode repair ;;
  streams) exec "$BASE_DIR/scripts/check-stream-operations.sh" ;;
  servers) exec "$BASE_DIR/scripts/check-servers.sh" ;;
  credentials)
    if [[ -f panel-admin-credentials.txt ]]; then
      cat panel-admin-credentials.txt
    else
      echo "Generated credential file is absent. Change the panel password with:"
      echo "  sudo $BASE_DIR/scripts/set-panel-password.sh admin"
    fi
    ;;
  panel-password) exec "$BASE_DIR/scripts/set-panel-password.sh" "${2:-admin}" ;;
  jellyfin-key) exec "$BASE_DIR/scripts/set-jellyfin-api-key.sh" ;;
  uninstall) exec "$BASE_DIR/scripts/installer.sh" --mode uninstall ;;
  version) cat "$BASE_DIR/.galaxytv-version" 2>/dev/null || cat "$BASE_DIR/VERSION" ;;
  *) usage; exit 1 ;;
esac
