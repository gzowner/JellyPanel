#!/usr/bin/env bash
set -u
BASE_DIR="/opt/galaxytv-jellyfin"
ENV_FILE="$BASE_DIR/.env"
cd "$BASE_DIR" 2>/dev/null || { echo "Installation not found at $BASE_DIR"; exit 1; }
get_env(){ grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2-; }

echo "=== GalaxyTV release ==="
echo "Control release: 1.1.0"
echo
echo "=== OS ==="
grep -E 'PRETTY_NAME|VERSION_ID' /etc/os-release

echo
echo "=== Docker ==="
docker version --format 'Server: {{.Server.Version}}' 2>/dev/null || true
docker compose version 2>/dev/null || true

echo
echo "=== Ports ==="
ss -lntup 2>/dev/null | grep -E ":($(get_env JELLYFIN_HTTP_PORT)|$(get_env PANEL_HTTP_PORT)|$(get_env CONTROL_API_PORT)|$(get_env M3U_GATEWAY_PORT)|8096)\b" || true

echo
echo "=== Containers ==="
docker compose --env-file .env ps 2>/dev/null || true

echo
echo "=== Jellyfin public info ==="
curl -fsS "http://127.0.0.1:$(get_env JELLYFIN_HTTP_PORT)/System/Info/Public" || true

echo
echo "=== Control API health ==="
curl -fsS "http://127.0.0.1:$(get_env CONTROL_API_PORT)/health" || true

echo
echo "=== M3U gateway health ==="
curl -fsS "http://127.0.0.1:$(get_env M3U_GATEWAY_PORT)/health" || true

echo
echo "=== Filtered playlist sample ==="
curl -fsS "http://127.0.0.1:$(get_env M3U_GATEWAY_PORT)/playlist/master.m3u" 2>/dev/null | head -n 8 || true

echo
echo "=== Expiration worker ==="
docker inspect -f '{{.State.Status}}' galaxytv-control-worker 2>/dev/null || true

echo
echo "=== Panel authentication ==="
if [[ -n "$(get_env PANEL_ADMIN_PASSWORD_HASH)" ]]; then echo "configured"; else echo "MISSING"; fi

echo
echo "=== Media mount ==="
findmnt "$(get_env MEDIA_PATH)" 2>/dev/null || ls -ld "$(get_env MEDIA_PATH)" 2>/dev/null || true


echo "=== Media inventory ==="
if [[ -f "$BASE_DIR/.env" ]]; then
  API_PORT="$(grep -E '^CONTROL_API_PORT=' "$BASE_DIR/.env" | tail -n1 | cut -d= -f2-)"
  curl -fsS "http://127.0.0.1:${API_PORT:-8182}/media/status" 2>/dev/null || echo "Login is required for detailed media status; use the panel."
fi


echo
echo "=== Media scanner ==="
if curl -fsS "http://127.0.0.1:$(get_env CONTROL_API_PORT)/health" >/dev/null 2>&1; then
  echo "Open GalaxyTV Control > Media Scan to view and edit /mnt/unionfs/Media."
else
  echo "Control API unavailable."
fi

echo
echo "=== Media gateway ==="
docker compose --env-file .env exec -T media-gateway python -c "import urllib.request; print(urllib.request.urlopen('http://127.0.0.1:8190/health', timeout=5).read().decode())" 2>/dev/null || echo "Media gateway unavailable."

echo
echo "=== STRM library mirror ==="
find "$BASE_DIR/strm-library" -type f \( -name '*.strm' -o -name '*.nfo' \) 2>/dev/null | awk '
  /\/Movies\// && /\.strm$/ {movies++}
  /\/TV Shows\// && /\.strm$/ {episodes++}
  /\.nfo$/ {nfo++}
  END {printf "Movies: %d\nTV episodes: %d\nNFO files: %d\n", movies, episodes, nfo}
'
ls -ld "$BASE_DIR/strm-library" "$BASE_DIR/strm-library/Movies" "$BASE_DIR/strm-library/TV Shows" 2>/dev/null || true


echo
echo "=== Operations agent ==="
docker compose --env-file .env ps ops-agent 2>/dev/null || true
docker compose --env-file .env logs --tail=80 ops-agent 2>/dev/null || true

echo
echo "=== Managed backups ==="
find "$BASE_DIR/backups/managed" -maxdepth 2 -type f -printf '%TY-%Tm-%Td %TH:%TM  %10s  %p\n' 2>/dev/null | sort -r | head -40 || true

echo
echo "=== Stream operations ==="
if [[ -x "$BASE_DIR/scripts/check-stream-operations.sh" ]]; then
  "$BASE_DIR/scripts/check-stream-operations.sh" 2>/dev/null | tail -n 120 || true
else
  echo "Stream operations diagnostic script is missing."
fi
