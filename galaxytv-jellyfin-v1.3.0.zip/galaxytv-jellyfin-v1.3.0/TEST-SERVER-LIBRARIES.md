# GalaxyTV v1.3.0 Per-Server Library Test Plan

## Upgrade validation

```bash
cd /root
sha256sum -c galaxytv-jellyfin-v1.3.0.zip.sha256
unzip -o galaxytv-jellyfin-v1.3.0.zip
cd galaxytv-jellyfin-v1.3.0
sudo bash install.sh --mode upgrade
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
sudo /opt/galaxytv-jellyfin/scripts/manage.sh libraries
```


Expected:

- Installed version `1.3.0`.
- Database schema `16`.
- `galaxytv-library-agent` is running and healthy.
- The existing Local Jellyfin server appears under Server Libraries.

## Safe first test

1. Create a small test folder under the configured media root.
2. Place one movie and one episode in it.
3. Configure Local Jellyfin's Server Library source path to that test folder's agent path.
4. Set a separate output folder such as `/strm-library/local-test`.
5. Click Test.
6. Run Sync.
7. Confirm one movie STRM and one episode STRM were created.
8. Add those paths as temporary Jellyfin libraries.
9. Confirm metadata and playback.

## Incremental test

Run Sync again without changing the source.

Expected:

- Added: 0
- Updated: 0
- Unchanged: 2
- Existing STRM and NFO modification times do not change.

## Changed-file test

Touch or replace one source file, then Sync.

Expected:

- Only that item is updated.
- The other item remains unchanged.

## Existing STRM protection

Create an unmarked STRM file in the expected output path before Sync.

Expected:

- GalaxyTV reports `user_managed_strm`.
- The existing file is not overwritten.

## Direct-library duplicate test

Leave the source item in an existing direct Jellyfin library and enable **Skip existing direct-library duplicates**.

Expected:

- The item is classified as `direct_library_duplicate`.
- No duplicate STRM is written for that item.

This matching is intentionally conservative. A false positive should be reviewed before changing the option.

## Missing grace test

1. Set the grace period to 1 day for testing.
2. Complete a successful Sync.
3. Remove one source file.
4. Sync again.

Expected: the item is marked missing but the generated files remain.

After the grace period, Sync again.

Expected: only GalaxyTV-managed STRM and NFO files for the missing item are removed.

## Mount failure test

Temporarily configure an unavailable source path and start Sync.

Expected:

- The job fails before cleanup.
- Existing generated STRM files remain.

## Remote node test

On another Jellyfin server:

```bash
sudo bash library-node/install-node.sh
sudo nano /opt/galaxytv-library-node/.env
sudo bash library-node/install-node.sh
```

Allow central access to port `8292`, enter both tokens in the panel, and click Test.

Verify:

- Agent status is returned.
- Remote source files are scanned locally on that server.
- STRM files are written to that server's configured output path.
- The remote Jellyfin container mounts the same host `STRM_PATH` at `/strm-library`.
- The remote Jellyfin server can play the agent media URL.
- Disconnecting the remote node does not stop Local Jellyfin or other server jobs.

## Daily schedule

Set the daily time a few minutes ahead and enable scheduling.

Expected:

- One job starts after the configured time.
- Another job does not start again on the same date.
- The next day can start a new scheduled job.
