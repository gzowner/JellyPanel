from __future__ import annotations

import asyncio
import json
import os
import re
import uuid
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo

import asyncpg
import httpx
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator

from .access import require_admin_role
from .multiserver import JellyfinServer, get_server
from .secret_store import decrypt_secret, encrypt_secret
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf
from .settings import settings

router = APIRouter(prefix="/server-libraries", tags=["Per-Server Libraries"])
ACTIVE_STATUSES = {"queued", "running"}
MONITORING_JOBS: set[uuid.UUID] = set()
ACTIVE_MONITOR_TASKS: set[asyncio.Task[Any]] = set()


def track_monitor_task(task: asyncio.Task[Any]) -> asyncio.Task[Any]:
    ACTIVE_MONITOR_TASKS.add(task)
    task.add_done_callback(ACTIVE_MONITOR_TASKS.discard)
    return task


class LibrarySettingsPayload(BaseModel):
    enabled: bool = True
    agent_url: str = Field(min_length=8, max_length=1000)
    agent_token: str = Field(default="", max_length=2000)
    media_token: str = Field(default="", max_length=2000)
    source_path: str = Field(min_length=1, max_length=2000)
    output_path: str = Field(min_length=1, max_length=2000)
    movies_folder: str = Field(default="Movies", min_length=1, max_length=120)
    tv_folder: str = Field(default="TV Shows", min_length=1, max_length=120)
    playback_base_url: str = Field(min_length=8, max_length=1000)
    schedule_enabled: bool = True
    daily_time: str = Field(default="02:00", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    missing_grace_days: int = Field(default=7, ge=1, le=365)
    remove_missing: bool = True
    adopt_existing: bool = True
    skip_direct_duplicates: bool = True
    refresh_jellyfin: bool = True

    @field_validator("agent_url", "playback_base_url")
    @classmethod
    def normalize_url(cls, value: str) -> str:
        value = value.strip().rstrip("/")
        if not value.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")
        return value

    @field_validator("source_path", "output_path", "movies_folder", "tv_folder")
    @classmethod
    def strip_value(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be blank")
        return value


class StartJobPayload(BaseModel):
    job_type: str = Field(default="sync", pattern="^(sync|adopt|verify|cleanup|full)$")


async def read_admin(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


async def write_admin(request: Request, session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


def slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-") or "jellyfin-server"


def local_source_path() -> str:
    host_media = os.path.normpath(settings.media_host_path)
    host_scan = os.path.normpath(settings.media_scan_host_root)
    try:
        relative = os.path.relpath(host_scan, host_media)
    except ValueError:
        relative = "Media"
    if relative in {".", ""}:
        return "/media"
    if relative.startswith(".."):
        relative = "Media"
    return "/media/" + relative.replace(os.sep, "/").strip("/")


async def ensure_server_library_settings(pool: asyncpg.Pool) -> None:
    async with pool.acquire() as connection:
        rows = await connection.fetch("SELECT id,name,is_default,is_local FROM jellyfin_servers ORDER BY is_default DESC")
        for row in rows:
            is_local = bool(row["is_local"])
            await connection.execute(
                """
                INSERT INTO server_library_settings
                    (server_id, enabled, agent_url, source_path, output_path,
                     playback_base_url, schedule_enabled, last_status, last_status_message)
                VALUES ($1, TRUE, $2, $3, $4, $5, TRUE, $6, $7)
                ON CONFLICT (server_id) DO NOTHING
                """,
                row["id"],
                "http://library-agent:8192" if is_local else "http://SERVER-IP:8292",
                local_source_path() if is_local else "/media/Media",
                f"/strm-library/{slug(str(row['name']))}",
                "http://library-agent:8192" if is_local else "http://SERVER-IP:8292",
                "ready" if is_local else "not_configured",
                "Local library agent is available." if is_local else "Install the GalaxyTV Library Node on this server and enter its connection details.",
            )


def decrypt_or_blank(value: str | None) -> str:
    try:
        return decrypt_secret(value)
    except ValueError:
        return ""


def tokens_for(row: asyncpg.Record, server: JellyfinServer) -> tuple[str, str]:
    agent_token = decrypt_or_blank(row["agent_token_encrypted"])
    media_token = decrypt_or_blank(row["media_token_encrypted"])
    if server.is_local:
        agent_token = agent_token or settings.library_agent_token
        media_token = media_token or settings.library_media_token
    return agent_token, media_token


def safe_settings(row: asyncpg.Record, server: JellyfinServer) -> dict[str, Any]:
    agent_token, media_token = tokens_for(row, server)
    result = dict(row)
    result.pop("agent_token_encrypted", None)
    result.pop("media_token_encrypted", None)
    result["server_id"] = str(result["server_id"])
    result["server_name"] = server.name
    result["server_enabled"] = server.enabled
    result["is_local"] = server.is_local
    result["agent_token_configured"] = bool(agent_token)
    result["media_token_configured"] = bool(media_token)
    result["daily_time"] = str(result["daily_time"])[:5]
    return result


async def config_for(pool: asyncpg.Pool, server_id: uuid.UUID) -> tuple[JellyfinServer, asyncpg.Record, dict[str, Any], str]:
    server = await get_server(pool, server_id)
    async with pool.acquire() as connection:
        row = await connection.fetchrow("SELECT * FROM server_library_settings WHERE server_id=$1", server_id)
    if row is None:
        await ensure_server_library_settings(pool)
        async with pool.acquire() as connection:
            row = await connection.fetchrow("SELECT * FROM server_library_settings WHERE server_id=$1", server_id)
    agent_token, media_token = tokens_for(row, server)
    if not agent_token:
        raise HTTPException(status_code=428, detail=f"{server.name} does not have a library-agent token configured.")
    if not media_token:
        raise HTTPException(status_code=428, detail=f"{server.name} does not have a library media token configured.")
    payload = {
        "server_id": str(server.id),
        "source_path": row["source_path"],
        "output_path": row["output_path"],
        "movies_folder": row["movies_folder"],
        "tv_folder": row["tv_folder"],
        "playback_base_url": row["playback_base_url"],
        "media_token": media_token,
        "jellyfin_url": server.internal_url,
        "jellyfin_api_key": server.api_key,
        "verify_tls": server.verify_tls,
        "missing_grace_days": int(row["missing_grace_days"]),
        "remove_missing": bool(row["remove_missing"]),
        "adopt_existing": bool(row["adopt_existing"]),
        "skip_direct_duplicates": bool(row["skip_direct_duplicates"]),
        "refresh_jellyfin": bool(row["refresh_jellyfin"]),
    }
    return server, row, payload, agent_token


async def agent_request(client: httpx.AsyncClient, row: asyncpg.Record, token: str, method: str, path: str, *, json_data: Any | None = None, timeout: float = 30) -> Any:
    try:
        response = await client.request(
            method,
            f"{str(row['agent_url']).rstrip('/')}/{path.lstrip('/')}",
            headers={"X-Library-Token": token},
            json=json_data,
            timeout=timeout,
        )
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"Library agent is unreachable: {exc}") from exc
    if response.status_code in {401, 403}:
        raise HTTPException(status_code=502, detail="Library agent rejected its configured token.")
    if response.status_code not in {200, 201, 202, 204}:
        detail = response.text.strip()[:500]
        raise HTTPException(status_code=502, detail=f"Library agent returned HTTP {response.status_code}: {detail}")
    return response.json() if response.content else None


async def save_conflicts(pool: asyncpg.Pool, server_id: uuid.UUID, job_id: uuid.UUID, conflicts: list[dict[str, Any]]) -> None:
    async with pool.acquire() as connection:
        await connection.execute("DELETE FROM server_library_conflicts WHERE job_id=$1", job_id)
        for conflict in conflicts[:500]:
            conflict_type = str(conflict.get("conflict_type") or "agent_warning")
            if conflict_type not in {"direct_library_duplicate","user_managed_strm","identity_collision","unmatched_existing_strm","agent_warning"}:
                conflict_type = "agent_warning"
            await connection.execute(
                """
                INSERT INTO server_library_conflicts
                    (server_id,job_id,source_path,output_path,conflict_type,message,details)
                VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)
                """,
                server_id, job_id, str(conflict.get("source_path") or ""), str(conflict.get("output_path") or ""),
                conflict_type, str(conflict.get("message") or "")[:4000], json.dumps(conflict.get("details") or {}),
            )


async def monitor_job(pool: asyncpg.Pool, client: httpx.AsyncClient, job_id: uuid.UUID, server_id: uuid.UUID, remote_job_id: str, row: asyncpg.Record, token: str) -> None:
    try:
        for _ in range(43200):
            async with pool.acquire() as connection:
                cancelled = await connection.fetchval("SELECT cancel_requested FROM server_library_jobs WHERE id=$1", job_id)
            if cancelled:
                try:
                    await agent_request(client, row, token, "POST", f"jobs/{remote_job_id}/cancel")
                except Exception:
                    pass
            remote = await agent_request(client, row, token, "GET", f"jobs/{remote_job_id}", timeout=45)
            counters = remote.get("counters") or {}
            result = remote.get("result") or {}
            status = str(remote.get("status") or "running")
            async with pool.acquire() as connection:
                await connection.execute(
                    """
                    UPDATE server_library_jobs SET status=$2,progress_percent=$3,current_path=$4,
                        total_items=$5,processed_items=$6,added_items=$7,updated_items=$8,
                        unchanged_items=$9,adopted_items=$10,skipped_duplicates=$11,
                        missing_items=$12,removed_items=$13,conflict_items=$14,failed_items=$15,
                        result=$16::jsonb,error=$17,
                        started_at=COALESCE(started_at,NOW()),
                        finished_at=CASE WHEN $2 IN ('completed','warning','failed','cancelled') THEN NOW() ELSE finished_at END
                    WHERE id=$1
                    """,
                    job_id, status, int(remote.get("progress_percent") or 0), remote.get("current_path"),
                    int(counters.get("total") or 0), int(counters.get("processed") or 0),
                    int(counters.get("added") or 0), int(counters.get("updated") or 0),
                    int(counters.get("unchanged") or 0), int(counters.get("adopted") or 0),
                    int(counters.get("skipped_duplicates") or 0), int(counters.get("missing") or 0),
                    int(counters.get("removed") or 0), int(counters.get("conflicts") or 0),
                    int(counters.get("failed") or 0), json.dumps(result), remote.get("error"),
                )
                if status in {"completed", "warning"}:
                    await connection.execute(
                        "UPDATE server_library_settings SET last_status=$2,last_status_message=$3,last_checked_at=NOW(),last_success_at=NOW(),updated_at=NOW() WHERE server_id=$1",
                        server_id, status, f"Library sync finished with {int(counters.get('added') or 0)} added, {int(counters.get('updated') or 0)} updated, and {int(counters.get('removed') or 0)} removed.",
                    )
                elif status == "failed":
                    await connection.execute(
                        "UPDATE server_library_settings SET last_status='failed',last_status_message=$2,last_checked_at=NOW(),updated_at=NOW() WHERE server_id=$1",
                        server_id, str(remote.get("error") or "Library synchronization failed.")[:2000],
                    )
            if status in {"completed", "warning", "failed", "cancelled"}:
                await save_conflicts(pool, server_id, job_id, list(result.get("conflicts") or []))
                return
            await asyncio.sleep(2)
        raise RuntimeError("Library synchronization exceeded the monitoring timeout.")
    except Exception as exc:
        async with pool.acquire() as connection:
            await connection.execute(
                "UPDATE server_library_jobs SET status='failed',error=$2,finished_at=NOW() WHERE id=$1",
                job_id, str(exc)[-4000:],
            )
            await connection.execute(
                "UPDATE server_library_settings SET last_status='offline',last_status_message=$2,last_checked_at=NOW(),updated_at=NOW() WHERE server_id=$1",
                server_id, str(exc)[-2000:],
            )
    finally:
        MONITORING_JOBS.discard(job_id)


async def resume_job_monitors(pool: asyncpg.Pool, client: httpx.AsyncClient) -> list[asyncio.Task[Any]]:
    await ensure_server_library_settings(pool)
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT j.id,j.server_id,j.remote_job_id,l.*
            FROM server_library_jobs j
            JOIN server_library_settings l ON l.server_id=j.server_id
            WHERE j.status IN ('queued','running')
            ORDER BY j.created_at
            """
        )
    tasks: list[asyncio.Task[Any]] = []
    for row in rows:
        job_id = row["id"]
        if job_id in MONITORING_JOBS:
            continue
        if not row["remote_job_id"]:
            async with pool.acquire() as connection:
                await connection.execute(
                    "UPDATE server_library_jobs SET status='failed',error='Job never received a remote agent ID.',finished_at=NOW() WHERE id=$1",
                    job_id,
                )
            continue
        server = await get_server(pool, row["server_id"])
        token, _ = tokens_for(row, server)
        if not token:
            async with pool.acquire() as connection:
                await connection.execute(
                    "UPDATE server_library_jobs SET status='failed',error='Library agent token is unavailable.',finished_at=NOW() WHERE id=$1",
                    job_id,
                )
            continue
        MONITORING_JOBS.add(job_id)
        tasks.append(track_monitor_task(asyncio.create_task(monitor_job(pool, client, job_id, row["server_id"], str(row["remote_job_id"]), row, token))))
    return tasks


async def launch_job(pool: asyncpg.Pool, client: httpx.AsyncClient, server_id: uuid.UUID, job_type: str, requested_by: str) -> tuple[uuid.UUID, asyncio.Task[Any]]:
    server, row, payload, token = await config_for(pool, server_id)
    if not bool(row["enabled"]):
        raise HTTPException(status_code=409, detail="Per-server library synchronization is disabled for this server.")
    async with pool.acquire() as connection:
        running = await connection.fetchval("SELECT EXISTS(SELECT 1 FROM server_library_jobs WHERE server_id=$1 AND status IN ('queued','running'))", server_id)
        if running:
            raise HTTPException(status_code=409, detail=f"A library job is already running for {server.name}.")
        job_id = uuid.uuid4()
        await connection.execute(
            "INSERT INTO server_library_jobs(id,server_id,job_type,status,requested_by) VALUES($1,$2,$3,'queued',$4)",
            job_id, server_id, job_type, requested_by,
        )
    try:
        remote = await agent_request(client, row, token, "POST", "jobs", json_data={**payload, "job_type": job_type}, timeout=45)
        remote_job_id = str(remote["job_id"])
        async with pool.acquire() as connection:
            await connection.execute(
                "UPDATE server_library_jobs SET remote_job_id=$2,status='running',started_at=NOW() WHERE id=$1",
                job_id, remote_job_id,
            )
            await connection.execute(
                "UPDATE server_library_settings SET last_status='running',last_status_message=$2,last_checked_at=NOW(),updated_at=NOW() WHERE server_id=$1",
                server_id, f"{job_type.title()} job is running.",
            )
    except Exception:
        async with pool.acquire() as connection:
            await connection.execute("UPDATE server_library_jobs SET status='failed',error='Unable to start the library agent job.',finished_at=NOW() WHERE id=$1", job_id)
        raise
    MONITORING_JOBS.add(job_id)
    task = track_monitor_task(asyncio.create_task(monitor_job(pool, client, job_id, server_id, remote_job_id, row, token)))
    return job_id, task


async def run_due_library_schedules(pool: asyncpg.Pool, client: httpx.AsyncClient) -> list[str]:
    await ensure_server_library_settings(pool)
    try:
        now = datetime.now(ZoneInfo(settings.timezone_name))
    except Exception:
        now = datetime.now(timezone.utc)
    today = now.date()
    current_hm = now.strftime("%H:%M")
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT l.server_id,to_char(l.daily_time,'HH24:MI') AS daily_time
            FROM server_library_settings l
            JOIN jellyfin_servers s ON s.id=l.server_id
            WHERE l.enabled=TRUE AND l.schedule_enabled=TRUE AND s.enabled=TRUE
              AND (l.last_schedule_date IS NULL OR l.last_schedule_date < $1)
            ORDER BY s.is_default DESC,LOWER(s.name)
            """,
            today,
        )
    started: list[str] = []
    for row in rows:
        if current_hm < str(row["daily_time"]):
            continue
        try:
            job_id, _ = await launch_job(pool, client, row["server_id"], "sync", "daily-scheduler")
            async with pool.acquire() as connection:
                await connection.execute("UPDATE server_library_settings SET last_schedule_date=$2 WHERE server_id=$1", row["server_id"], today)
            started.append(str(job_id))
        except HTTPException as exc:
            if exc.status_code != 409:
                async with pool.acquire() as connection:
                    await connection.execute("UPDATE server_library_settings SET last_status='failed',last_status_message=$2,last_checked_at=NOW() WHERE server_id=$1", row["server_id"], str(exc.detail)[:2000])
        except Exception as exc:
            async with pool.acquire() as connection:
                await connection.execute("UPDATE server_library_settings SET last_status='failed',last_status_message=$2,last_checked_at=NOW() WHERE server_id=$1", row["server_id"], str(exc)[:2000])
    return started


@router.get("")
async def list_libraries(request: Request, _: PanelSession = Depends(read_admin)) -> dict[str, Any]:
    pool = request.app.state.db
    await ensure_server_library_settings(pool)
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT l.*,s.name AS server_name,s.enabled AS server_enabled,s.is_local,
                   j.id AS job_id,j.status AS job_status,j.job_type,j.progress_percent,
                   j.current_path,j.total_items,j.processed_items,j.added_items,j.updated_items,
                   j.unchanged_items,j.adopted_items,j.skipped_duplicates,j.missing_items,
                   j.removed_items,j.conflict_items,j.failed_items,j.started_at,j.finished_at,j.error
            FROM server_library_settings l
            JOIN jellyfin_servers s ON s.id=l.server_id
            LEFT JOIN LATERAL (
                SELECT * FROM server_library_jobs WHERE server_id=l.server_id ORDER BY created_at DESC LIMIT 1
            ) j ON TRUE
            ORDER BY s.is_default DESC,LOWER(s.name)
            """
        )
    items=[]
    for row in rows:
        server=await get_server(pool,row["server_id"])
        data=safe_settings(row,server)
        data["latest_job"]={key:row[key] for key in ("job_id","job_status","job_type","progress_percent","current_path","total_items","processed_items","added_items","updated_items","unchanged_items","adopted_items","skipped_duplicates","missing_items","removed_items","conflict_items","failed_items","started_at","finished_at","error")}
        if data["latest_job"]["job_id"]:
            data["latest_job"]["job_id"]=str(data["latest_job"]["job_id"])
        items.append(data)
    return {"libraries":items,"timezone":settings.timezone_name}


@router.get("/{server_id}")
async def get_library(server_id: uuid.UUID, request: Request, _: PanelSession = Depends(read_admin)) -> dict[str, Any]:
    await ensure_server_library_settings(request.app.state.db)
    server=await get_server(request.app.state.db,server_id)
    async with request.app.state.db.acquire() as connection:
        row=await connection.fetchrow("SELECT * FROM server_library_settings WHERE server_id=$1",server_id)
    return safe_settings(row,server)


@router.put("/{server_id}")
async def save_library(server_id: uuid.UUID,payload:LibrarySettingsPayload,request:Request,session:PanelSession=Depends(write_admin))->dict[str,Any]:
    pool=request.app.state.db
    await ensure_server_library_settings(pool)
    server=await get_server(pool,server_id)
    async with pool.acquire() as connection:
        current=await connection.fetchrow("SELECT * FROM server_library_settings WHERE server_id=$1",server_id)
        current_agent=tokens_for(current,server)[0]
        current_media=tokens_for(current,server)[1]
        agent_token=payload.agent_token.strip() or current_agent
        media_token=payload.media_token.strip() or current_media
        row=await connection.fetchrow(
            """
            UPDATE server_library_settings SET enabled=$2,agent_url=$3,agent_token_encrypted=$4,
                media_token_encrypted=$5,source_path=$6,output_path=$7,movies_folder=$8,tv_folder=$9,
                playback_base_url=$10,schedule_enabled=$11,daily_time=$12::time,missing_grace_days=$13,
                remove_missing=$14,adopt_existing=$15,skip_direct_duplicates=$16,refresh_jellyfin=$17,
                updated_at=NOW() WHERE server_id=$1 RETURNING *
            """,
            server_id,payload.enabled,payload.agent_url,encrypt_secret(agent_token),encrypt_secret(media_token),
            payload.source_path,payload.output_path,payload.movies_folder,payload.tv_folder,payload.playback_base_url,
            payload.schedule_enabled,payload.daily_time,payload.missing_grace_days,payload.remove_missing,
            payload.adopt_existing,payload.skip_direct_duplicates,payload.refresh_jellyfin,
        )
        await connection.execute("INSERT INTO audit_log(actor_type,actor_id,action,target_type,target_id,details) VALUES('panel',$1,'server_library.settings.updated','jellyfin_server',$2,$3::jsonb)",session.username,str(server_id),json.dumps({"server":server.name,"source_path":payload.source_path,"output_path":payload.output_path,"daily_time":payload.daily_time}))
    return safe_settings(row,server)


@router.post("/{server_id}/test")
async def test_library_agent(server_id:uuid.UUID,request:Request,session:PanelSession=Depends(write_admin))->dict[str,Any]:
    server,row,_,token=await config_for(request.app.state.db,server_id)
    result=await agent_request(request.app.state.http,row,token,"GET","status",timeout=30)
    async with request.app.state.db.acquire() as connection:
        await connection.execute("UPDATE server_library_settings SET last_status='ready',last_status_message=$2,last_checked_at=NOW(),updated_at=NOW() WHERE server_id=$1",server_id,f"Agent {result.get('version','unknown')} is responding.")
    return {"server_id":str(server_id),"server_name":server.name,"agent":result}


@router.post("/{server_id}/jobs")
async def start_job(server_id:uuid.UUID,payload:StartJobPayload,request:Request,session:PanelSession=Depends(write_admin))->dict[str,Any]:
    job_id,task=await launch_job(request.app.state.db,request.app.state.http,server_id,payload.job_type,session.username)
    request.app.state.background_tasks.add(task)
    task.add_done_callback(request.app.state.background_tasks.discard)
    return {"id":str(job_id),"status":"running","job_type":payload.job_type}


@router.get("/job/{job_id}")
async def get_job(job_id:uuid.UUID,request:Request,_:PanelSession=Depends(read_admin))->dict[str,Any]:
    async with request.app.state.db.acquire() as connection:
        row=await connection.fetchrow("SELECT j.*,s.name AS server_name FROM server_library_jobs j JOIN jellyfin_servers s ON s.id=j.server_id WHERE j.id=$1",job_id)
    if row is None: raise HTTPException(status_code=404,detail="Library job was not found.")
    result=dict(row);result["id"]=str(result["id"]);result["server_id"]=str(result["server_id"])
    return result


@router.post("/job/{job_id}/cancel")
async def cancel_job(job_id:uuid.UUID,request:Request,_:PanelSession=Depends(write_admin))->dict[str,Any]:
    async with request.app.state.db.acquire() as connection:
        status=await connection.fetchval("SELECT status FROM server_library_jobs WHERE id=$1",job_id)
        if status is None: raise HTTPException(status_code=404,detail="Library job was not found.")
        if status not in ACTIVE_STATUSES: return {"id":str(job_id),"status":status}
        await connection.execute("UPDATE server_library_jobs SET cancel_requested=TRUE WHERE id=$1",job_id)
    return {"id":str(job_id),"status":"cancelling"}


@router.get("/{server_id}/conflicts")
async def conflicts(server_id:uuid.UUID,request:Request,limit:int=200,_:PanelSession=Depends(read_admin))->dict[str,Any]:
    limit=min(max(limit,1),500)
    async with request.app.state.db.acquire() as connection:
        rows=await connection.fetch("SELECT * FROM server_library_conflicts WHERE server_id=$1 AND resolved_at IS NULL ORDER BY created_at DESC LIMIT $2",server_id,limit)
    return {"conflicts":[{**dict(row),"id":str(row["id"]),"server_id":str(row["server_id"]),"job_id":str(row["job_id"]) if row["job_id"] else None} for row in rows]}
