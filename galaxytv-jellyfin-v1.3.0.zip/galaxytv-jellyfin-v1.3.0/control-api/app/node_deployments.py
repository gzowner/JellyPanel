from __future__ import annotations

import asyncio
import json
import os
import re
import secrets
import shlex
import tarfile
import tempfile
import uuid
from pathlib import Path
from typing import Any, Literal

import asyncpg
import asyncssh
import httpx
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator, model_validator

from .access import require_admin_role
from .multiserver import get_server
from .secret_store import encrypt_secret
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf
from .settings import settings

router = APIRouter(prefix="/node-deployments", tags=["Remote Library Node Deployment"])
PAYLOAD_DIR = Path(settings.node_deployment_payload_path)
ACTIVE_TASKS: set[asyncio.Task[Any]] = set()
FINAL_STATUSES = {"completed", "warning", "failed"}


class RemoteNodeDeploymentPayload(BaseModel):
    deployment_type: Literal["docker", "native"] = "docker"
    ssh_host: str = Field(min_length=1, max_length=255)
    ssh_port: int = Field(default=22, ge=1, le=65535)
    ssh_username: str = Field(default="root", min_length=1, max_length=128)
    auth_type: Literal["password", "private_key"] = "password"
    ssh_password: str = Field(default="", max_length=4096)
    ssh_private_key: str = Field(default="", max_length=65536)
    ssh_key_passphrase: str = Field(default="", max_length=4096)
    sudo_password: str = Field(default="", max_length=4096)
    verify_host_key: bool = False
    known_host_key: str = Field(default="", max_length=16384)

    install_path: str = Field(default="/opt/galaxytv-library-node", max_length=1000)
    source_host_path: str = Field(default="/mnt/unionfs/Media", max_length=2000)
    strm_host_path: str = Field(default="/opt/galaxytv-library-node/strm-library", max_length=2000)
    agent_bind_ip: str = Field(default="0.0.0.0", max_length=64)
    agent_port: int = Field(default=8292, ge=1, le=65535)
    agent_url: str = Field(min_length=8, max_length=1000)
    jellyfin_local_url: str = Field(min_length=8, max_length=1000)
    timezone: str = Field(default="America/Chicago", min_length=1, max_length=128)
    native_service_user: str = Field(default="root", min_length=1, max_length=64)
    install_docker: bool = True

    @field_validator("ssh_host", "ssh_username", "agent_bind_ip", "timezone", "native_service_user")
    @classmethod
    def safe_simple_value(cls, value: str) -> str:
        value = value.strip()
        if not value or any(character in value for character in "\r\n\x00"):
            raise ValueError("Value contains unsupported characters")
        return value

    @field_validator("install_path", "source_host_path", "strm_host_path")
    @classmethod
    def absolute_path(cls, value: str) -> str:
        value = value.strip().rstrip("/") or "/"
        if not value.startswith("/") or any(character in value for character in "\r\n\x00"):
            raise ValueError("A safe absolute Linux path is required")
        return value

    @field_validator("agent_url", "jellyfin_local_url")
    @classmethod
    def normalize_url(cls, value: str) -> str:
        value = value.strip().rstrip("/")
        if not value.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")
        if any(character in value for character in "\r\n\x00"):
            raise ValueError("URL contains unsupported characters")
        return value

    @field_validator("known_host_key")
    @classmethod
    def normalize_known_host(cls, value: str) -> str:
        value = value.strip()
        if "\x00" in value or value.count("\n") > 1:
            raise ValueError("Enter one OpenSSH known-host key line")
        return value

    @model_validator(mode="after")
    def validate_authentication(self) -> "RemoteNodeDeploymentPayload":
        if self.auth_type == "password" and not self.ssh_password:
            raise ValueError("SSH password is required for password authentication")
        if self.auth_type == "private_key" and not self.ssh_private_key.strip():
            raise ValueError("SSH private key is required for private-key authentication")
        if self.verify_host_key and not self.known_host_key:
            raise ValueError("A known-host key is required when host-key verification is enabled")
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", self.ssh_username):
            raise ValueError("SSH username contains unsupported characters")
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", self.native_service_user):
            raise ValueError("Native service user contains unsupported characters")
        return self


async def read_admin(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


async def write_admin(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


def deployment_row(row: asyncpg.Record) -> dict[str, Any]:
    result = dict(row)
    result["id"] = str(result["id"])
    result["server_id"] = str(result["server_id"])
    return result


async def update_job(
    pool: asyncpg.Pool,
    job_id: uuid.UUID,
    *,
    status: str | None = None,
    progress: int | None = None,
    step: str | None = None,
    log_line: str | None = None,
    error: str | None = None,
    result: dict[str, Any] | None = None,
    finished: bool = False,
) -> None:
    async with pool.acquire() as connection:
        row = await connection.fetchrow(
            "SELECT log_text FROM library_node_deployments WHERE id=$1",
            job_id,
        )
        if row is None:
            return
        log_text = str(row["log_text"] or "")
        if log_line:
            clean = log_line.replace("\x00", "")[-12000:]
            log_text = (log_text + ("\n" if log_text else "") + clean)[-60000:]
        await connection.execute(
            """
            UPDATE library_node_deployments
            SET status=COALESCE($2,status),
                progress_percent=COALESCE($3,progress_percent),
                current_step=COALESCE($4,current_step),
                log_text=$5,
                error=COALESCE($6,error),
                result=COALESCE($7::jsonb,result),
                started_at=COALESCE(started_at,NOW()),
                finished_at=CASE WHEN $8 THEN NOW() ELSE finished_at END
            WHERE id=$1
            """,
            job_id,
            status,
            progress,
            step,
            log_text,
            error,
            json.dumps(result) if result is not None else None,
            finished,
        )


def shell_env(values: dict[str, str]) -> str:
    return "\n".join(f"{key}={shlex.quote(value)}" for key, value in values.items()) + "\n"


def remote_installer_script() -> str:
    return r'''#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
STAGE_DIR="${1:?staging directory is required}"
# shellcheck disable=SC1090
source "$STAGE_DIR/install.env"
SYSTEMD_UNIT_PATH="${SYSTEMD_UNIT_PATH:-/etc/systemd/system/galaxytv-library-node.service}"
SYSTEM_ENV_PATH="${SYSTEM_ENV_PATH:-/etc/galaxytv-library-node.env}"

log() { printf '[3] %s\n' "$*"; }
require_apt() {
  command -v apt-get >/dev/null 2>&1 || {
    echo "Only Ubuntu/Debian apt-based hosts are supported by remote deployment." >&2
    exit 12
  }
}

require_apt
export DEBIAN_FRONTEND=noninteractive
[[ -d "$SOURCE_HOST_PATH" ]] || {
  echo "Media scan path does not exist: $SOURCE_HOST_PATH" >&2
  exit 11
}
mkdir -p "$INSTALL_PATH" "$INSTALL_PATH/state" "$STRM_HOST_PATH"
chmod 700 "$INSTALL_PATH/state"

log "Extracting the signed release payload"
rm -rf "$INSTALL_PATH/.incoming-library-agent"
mkdir -p "$INSTALL_PATH/.incoming-library-agent"
tar -xzf "$STAGE_DIR/payload.tar.gz" -C "$INSTALL_PATH/.incoming-library-agent"
[[ -f "$INSTALL_PATH/.incoming-library-agent/library-agent/app/main.py" ]] || {
  echo "Library Agent payload is incomplete." >&2
  exit 13
}

if [[ -d "$INSTALL_PATH/library-agent" ]]; then
  rm -rf "$INSTALL_PATH/.previous-library-agent"
  mv "$INSTALL_PATH/library-agent" "$INSTALL_PATH/.previous-library-agent"
fi
mv "$INSTALL_PATH/.incoming-library-agent/library-agent" "$INSTALL_PATH/library-agent"
rm -rf "$INSTALL_PATH/.incoming-library-agent"

write_common_env() {
  cat > "$INSTALL_PATH/.env" <<EOF
LIBRARY_NODE_BASE_DIR=$INSTALL_PATH
LIBRARY_NODE_BIND_IP=$AGENT_BIND_IP
LIBRARY_NODE_PORT=$AGENT_PORT
TZ=$TIMEZONE
SOURCE_PATH=$SOURCE_HOST_PATH
STRM_PATH=$STRM_HOST_PATH
JELLYFIN_URL=$JELLYFIN_LOCAL_URL
JELLYFIN_API_KEY=$JELLYFIN_API_KEY
LIBRARY_PLAYBACK_BASE_URL=$AGENT_URL
LIBRARY_AGENT_TOKEN=$LIBRARY_AGENT_TOKEN
LIBRARY_MEDIA_TOKEN=$LIBRARY_MEDIA_TOKEN
EOF
  chmod 600 "$INSTALL_PATH/.env"
}

install_docker_node() {
  log "Preparing Docker deployment"
  if ! command -v docker >/dev/null 2>&1; then
    [[ "$INSTALL_DOCKER" == "true" ]] || {
      echo "Docker is not installed and automatic Docker installation is disabled." >&2
      exit 21
    }
    apt-get update -y
    apt-get install -y ca-certificates curl
    curl -fsSL https://get.docker.com | sh
  fi
  if ! docker compose version >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y docker-compose-plugin || apt-get install -y docker-compose-v2
  fi
  docker compose version >/dev/null 2>&1 || {
    echo "Docker Compose v2 is required." >&2
    exit 22
  }

  write_common_env
  cat > "$INSTALL_PATH/compose.yml" <<'COMPOSE'
name: galaxytv-library-node
services:
  library-agent:
    build:
      context: ./library-agent
    container_name: galaxytv-library-node
    restart: unless-stopped
    ports:
      - "${LIBRARY_NODE_BIND_IP:-0.0.0.0}:${LIBRARY_NODE_PORT:-8292}:8192/tcp"
    environment:
      TZ: "${TZ:-America/Chicago}"
      LIBRARY_AGENT_TOKEN: "${LIBRARY_AGENT_TOKEN:?LIBRARY_AGENT_TOKEN is required}"
      LIBRARY_MEDIA_TOKEN: "${LIBRARY_MEDIA_TOKEN:?LIBRARY_MEDIA_TOKEN is required}"
      LIBRARY_AGENT_STATE: "/state"
      LIBRARY_SOURCE_PATH: "/media/Media"
      LIBRARY_OUTPUT_PATH: "/strm-library"
      LIBRARY_PLAYBACK_BASE_URL: "${LIBRARY_PLAYBACK_BASE_URL:?LIBRARY_PLAYBACK_BASE_URL is required}"
      JELLYFIN_URL: "${JELLYFIN_URL:?JELLYFIN_URL is required}"
      JELLYFIN_API_KEY: "${JELLYFIN_API_KEY:-}"
    volumes:
      - "${LIBRARY_NODE_BASE_DIR:-/opt/galaxytv-library-node}/state:/state"
      - "${SOURCE_PATH:?SOURCE_PATH is required}:/media/Media:ro,rslave"
      - "${STRM_PATH:?STRM_PATH is required}:/strm-library"
    extra_hosts:
      - "host.docker.internal:host-gateway"
COMPOSE
  log "Building and starting the Docker Library Node"
  cd "$INSTALL_PATH"
  docker compose --env-file .env up -d --build --remove-orphans
}

escape_systemd_value() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

install_native_node() {
  log "Preparing native Python/systemd deployment"
  apt-get update -y
  apt-get install -y python3 python3-venv python3-pip ca-certificates curl

  if [[ "$NATIVE_SERVICE_USER" != "root" ]] && ! id "$NATIVE_SERVICE_USER" >/dev/null 2>&1; then
    useradd --system --home "$INSTALL_PATH" --shell /usr/sbin/nologin "$NATIVE_SERVICE_USER"
  fi

  rm -rf "$INSTALL_PATH/venv.new"
  python3 -m venv "$INSTALL_PATH/venv.new"
  "$INSTALL_PATH/venv.new/bin/pip" install --no-cache-dir --upgrade pip
  "$INSTALL_PATH/venv.new/bin/pip" install --no-cache-dir -r "$INSTALL_PATH/library-agent/requirements.txt"
  rm -rf "$INSTALL_PATH/venv.previous"
  [[ -d "$INSTALL_PATH/venv" ]] && mv "$INSTALL_PATH/venv" "$INSTALL_PATH/venv.previous"
  mv "$INSTALL_PATH/venv.new" "$INSTALL_PATH/venv"

  cat > "$SYSTEM_ENV_PATH" <<EOF
LIBRARY_AGENT_TOKEN="$(escape_systemd_value "$LIBRARY_AGENT_TOKEN")"
LIBRARY_MEDIA_TOKEN="$(escape_systemd_value "$LIBRARY_MEDIA_TOKEN")"
LIBRARY_AGENT_STATE="$(escape_systemd_value "$INSTALL_PATH/state")"
LIBRARY_SOURCE_PATH="$(escape_systemd_value "$SOURCE_HOST_PATH")"
LIBRARY_OUTPUT_PATH="$(escape_systemd_value "$STRM_HOST_PATH")"
LIBRARY_PLAYBACK_BASE_URL="$(escape_systemd_value "$AGENT_URL")"
JELLYFIN_URL="$(escape_systemd_value "$JELLYFIN_LOCAL_URL")"
JELLYFIN_API_KEY="$(escape_systemd_value "$JELLYFIN_API_KEY")"
TZ="$(escape_systemd_value "$TIMEZONE")"
EOF
  chmod 600 "$SYSTEM_ENV_PATH"

  cat > "$SYSTEMD_UNIT_PATH" <<EOF
[Unit]
Description=GalaxyTV JellyPanel Library Node
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$NATIVE_SERVICE_USER
WorkingDirectory=$INSTALL_PATH/library-agent
EnvironmentFile=$SYSTEM_ENV_PATH
ExecStart=$INSTALL_PATH/venv/bin/uvicorn app.main:app --host $AGENT_BIND_IP --port $AGENT_PORT
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=$INSTALL_PATH $STRM_HOST_PATH

[Install]
WantedBy=multi-user.target
EOF

  if [[ "$NATIVE_SERVICE_USER" != "root" ]]; then
    chown -R "$NATIVE_SERVICE_USER":"$NATIVE_SERVICE_USER" "$INSTALL_PATH/state" "$STRM_HOST_PATH"
  fi
  systemctl daemon-reload
  systemctl enable --now galaxytv-library-node.service
}

case "$DEPLOYMENT_TYPE" in
  docker) install_docker_node ;;
  native) install_native_node ;;
  *) echo "Unsupported deployment type: $DEPLOYMENT_TYPE" >&2; exit 30 ;;
esac

log "Waiting for the Library Node health endpoint"
for attempt in $(seq 1 60); do
  if curl -fsS -H "X-Library-Token: $LIBRARY_AGENT_TOKEN" \
      "http://127.0.0.1:$AGENT_PORT/status" >/dev/null 2>&1; then
    log "Library Node is healthy"
    rm -rf "$STAGE_DIR"
    exit 0
  fi
  sleep 2
done

echo "Library Node did not become healthy within 120 seconds." >&2
if [[ "$DEPLOYMENT_TYPE" == "docker" ]]; then
  cd "$INSTALL_PATH" && docker compose --env-file .env logs --tail=120 || true
else
  systemctl status galaxytv-library-node.service --no-pager || true
  journalctl -u galaxytv-library-node.service --no-pager -n 120 || true
fi
exit 31
'''


def create_payload_archive(destination: Path) -> None:
    if not PAYLOAD_DIR.is_dir():
        raise RuntimeError(f"Node deployment payload is missing at {PAYLOAD_DIR}")
    with tarfile.open(destination, "w:gz") as archive:
        for path in sorted(PAYLOAD_DIR.rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
                archive.add(path, arcname=path.relative_to(PAYLOAD_DIR))


async def connect_ssh(payload: RemoteNodeDeploymentPayload, temp_dir: Path) -> asyncssh.SSHClientConnection:
    known_hosts: str | None = None
    if payload.verify_host_key:
        host_key = payload.known_host_key.strip()
        host_label = payload.ssh_host if payload.ssh_port == 22 else f"[{payload.ssh_host}]:{payload.ssh_port}"
        if not host_key.startswith((payload.ssh_host, "[", "@cert-authority", "@revoked")):
            host_key = f"{host_label} {host_key}"
        known_hosts_path = temp_dir / "known_hosts"
        known_hosts_path.write_text(host_key + "\n", encoding="utf-8")
        known_hosts = str(known_hosts_path)

    arguments: dict[str, Any] = {
        "host": payload.ssh_host,
        "port": payload.ssh_port,
        "username": payload.ssh_username,
        "known_hosts": known_hosts,
        "login_timeout": 25,
        "connect_timeout": 25,
        "keepalive_interval": 20,
        "keepalive_count_max": 3,
    }

    if payload.auth_type == "password":
        arguments["password"] = payload.ssh_password
    else:
        key_path = temp_dir / "deployment_key"
        key_path.write_text(payload.ssh_private_key.strip() + "\n", encoding="utf-8")
        os.chmod(key_path, 0o600)
        arguments["client_keys"] = [str(key_path)]
        if payload.ssh_key_passphrase:
            arguments["passphrase"] = payload.ssh_key_passphrase

    return await asyncssh.connect(**arguments)


async def verify_public_agent(
    client: httpx.AsyncClient,
    agent_url: str,
    agent_token: str,
) -> dict[str, Any]:
    last_error = "Agent did not respond"
    for _ in range(45):
        try:
            response = await client.get(
                f"{agent_url.rstrip('/')}/status",
                headers={"X-Library-Token": agent_token},
                timeout=10,
            )
            if response.status_code == 200:
                return response.json()
            last_error = f"HTTP {response.status_code}: {response.text[:300]}"
        except httpx.RequestError as exc:
            last_error = str(exc)
        await asyncio.sleep(2)
    raise RuntimeError(f"The node is healthy locally but the panel cannot reach {agent_url}: {last_error}")


async def run_deployment(
    app: Any,
    job_id: uuid.UUID,
    server_id: uuid.UUID,
    payload: RemoteNodeDeploymentPayload,
    requested_by: str,
) -> None:
    pool: asyncpg.Pool = app.state.db
    agent_token = secrets.token_hex(32)
    media_token = secrets.token_hex(32)
    try:
        server = await get_server(pool, server_id)
        if server.is_local:
            raise RuntimeError("The built-in local Library Agent is managed by the main JellyPanel installation and does not require remote deployment.")
        if not server.api_key:
            raise RuntimeError("The selected Jellyfin server does not have an API key configured.")

        await update_job(pool, job_id, status="connecting", progress=5, step="Connecting over SSH", log_line=f"Connecting to {payload.ssh_username}@{payload.ssh_host}:{payload.ssh_port}")

        with tempfile.TemporaryDirectory(prefix="jellypanel-node-deploy-") as temporary:
            temp_dir = Path(temporary)
            archive_path = temp_dir / "payload.tar.gz"
            create_payload_archive(archive_path)

            env_values = {
                "DEPLOYMENT_TYPE": payload.deployment_type,
                "INSTALL_PATH": payload.install_path,
                "SOURCE_HOST_PATH": payload.source_host_path,
                "STRM_HOST_PATH": payload.strm_host_path,
                "AGENT_BIND_IP": payload.agent_bind_ip,
                "AGENT_PORT": str(payload.agent_port),
                "AGENT_URL": payload.agent_url,
                "JELLYFIN_LOCAL_URL": payload.jellyfin_local_url,
                "JELLYFIN_API_KEY": server.api_key,
                "LIBRARY_AGENT_TOKEN": agent_token,
                "LIBRARY_MEDIA_TOKEN": media_token,
                "TIMEZONE": payload.timezone,
                "NATIVE_SERVICE_USER": payload.native_service_user,
                "INSTALL_DOCKER": "true" if payload.install_docker else "false",
            }
            env_path = temp_dir / "install.env"
            env_path.write_text(shell_env(env_values), encoding="utf-8")
            os.chmod(env_path, 0o600)
            script_path = temp_dir / "remote-install.sh"
            script_path.write_text(remote_installer_script(), encoding="utf-8")
            os.chmod(script_path, 0o700)

            connection = await connect_ssh(payload, temp_dir)
            async with connection:
                remote_stage = f"/tmp/galaxytv-node-{job_id}"
                await connection.run(f"umask 077 && mkdir -p {shlex.quote(remote_stage)}", check=True)
                await update_job(pool, job_id, status="uploading", progress=20, step="Uploading Library Node", log_line="Uploading the Library Agent release and installation configuration")
                async with connection.start_sftp_client() as sftp:
                    await sftp.put(str(archive_path), f"{remote_stage}/payload.tar.gz")
                    await sftp.put(str(env_path), f"{remote_stage}/install.env")
                    await sftp.put(str(script_path), f"{remote_stage}/remote-install.sh")
                    await sftp.chmod(f"{remote_stage}/remote-install.sh", 0o700)
                    await sftp.chmod(f"{remote_stage}/install.env", 0o600)

                await update_job(pool, job_id, status="installing", progress=40, step=f"Installing {payload.deployment_type} node", log_line=f"Running the {payload.deployment_type} installer with elevated privileges")
                remote_script = f"{remote_stage}/remote-install.sh"
                command = f"bash {shlex.quote(remote_script)} {shlex.quote(remote_stage)}"
                input_data: str | None = None
                if payload.ssh_username != "root":
                    if payload.sudo_password:
                        command = f"sudo -S -p '' {command}"
                        input_data = payload.sudo_password + "\n"
                    else:
                        command = f"sudo -n {command}"
                result = await connection.run(command, input=input_data, check=False, timeout=1800)
                combined = "\n".join(part.strip() for part in (result.stdout, result.stderr) if part and part.strip())
                if combined:
                    await update_job(pool, job_id, log_line=combined[-30000:])
                if result.exit_status != 0:
                    raise RuntimeError(f"Remote installer exited with status {result.exit_status}. Review the deployment log.")

        await update_job(pool, job_id, status="verifying", progress=85, step="Verifying from JellyPanel", log_line=f"Remote installation completed. Testing {payload.agent_url} from the central panel")
        status = await verify_public_agent(app.state.http, payload.agent_url, agent_token)

        output_path = "/strm-library" if payload.deployment_type == "docker" else payload.strm_host_path
        source_path = "/media/Media" if payload.deployment_type == "docker" else payload.source_host_path
        async with pool.acquire() as connection:
            await connection.execute(
                """
                INSERT INTO server_library_settings
                    (server_id,enabled,agent_url,agent_token_encrypted,media_token_encrypted,
                     source_path,output_path,playback_base_url,schedule_enabled,last_status,
                     last_status_message,last_checked_at,updated_at)
                VALUES ($1,TRUE,$2,$3,$4,$5,$6,$2,TRUE,'ready',$7,NOW(),NOW())
                ON CONFLICT (server_id) DO UPDATE
                SET enabled=TRUE,
                    agent_url=EXCLUDED.agent_url,
                    agent_token_encrypted=EXCLUDED.agent_token_encrypted,
                    media_token_encrypted=EXCLUDED.media_token_encrypted,
                    source_path=EXCLUDED.source_path,
                    output_path=EXCLUDED.output_path,
                    playback_base_url=EXCLUDED.playback_base_url,
                    last_status='ready',
                    last_status_message=EXCLUDED.last_status_message,
                    last_checked_at=NOW(),
                    updated_at=NOW()
                """,
                server_id,
                payload.agent_url,
                encrypt_secret(agent_token),
                encrypt_secret(media_token),
                source_path,
                output_path,
                f"Remote {payload.deployment_type} Library Node {status.get('version', 'unknown')} installed successfully.",
            )
            await connection.execute(
                """
                INSERT INTO audit_log(actor_type,actor_id,action,target_type,target_id,details)
                VALUES ('panel',$1,'library_node.deployed','jellyfin_server',$2,$3::jsonb)
                """,
                requested_by,
                str(server_id),
                json.dumps({
                    "server": server.name,
                    "deployment_type": payload.deployment_type,
                    "ssh_host": payload.ssh_host,
                    "agent_url": payload.agent_url,
                    "source_host_path": payload.source_host_path,
                    "strm_host_path": payload.strm_host_path,
                }),
            )

        final_result = {
            "server_name": server.name,
            "deployment_type": payload.deployment_type,
            "agent_url": payload.agent_url,
            "agent_version": status.get("version"),
            "source_path": source_path,
            "output_path": output_path,
            "host_strm_path": payload.strm_host_path,
            "jellyfin_library_path": "/strm-library" if payload.deployment_type == "docker" else payload.strm_host_path,
            "message": "Library Node installed and connected. The SSH credentials were not retained.",
        }
        await update_job(pool, job_id, status="completed", progress=100, step="Deployment completed", log_line="Library Node is reachable from JellyPanel and its generated tokens have been saved.", result=final_result, finished=True)
    except asyncio.CancelledError:
        await update_job(pool, job_id, status="failed", error="Deployment task was cancelled.", step="Cancelled", finished=True)
        raise
    except (asyncssh.Error, OSError) as exc:
        await update_job(pool, job_id, status="failed", error=f"SSH connection failed: {exc}", step="SSH failed", log_line=f"SSH error: {exc}", finished=True)
    except Exception as exc:
        await update_job(pool, job_id, status="failed", error=str(exc)[-4000:], step="Deployment failed", log_line=f"Deployment failed: {exc}", finished=True)


@router.get("")
async def list_deployments(
    request: Request,
    server_id: uuid.UUID | None = None,
    limit: int = 100,
    _: PanelSession = Depends(read_admin),
) -> dict[str, Any]:
    limit = min(max(limit, 1), 500)
    async with request.app.state.db.acquire() as connection:
        if server_id:
            rows = await connection.fetch(
                """
                SELECT d.*,s.name AS server_name
                FROM library_node_deployments d
                JOIN jellyfin_servers s ON s.id=d.server_id
                WHERE d.server_id=$1
                ORDER BY d.created_at DESC LIMIT $2
                """,
                server_id,
                limit,
            )
        else:
            rows = await connection.fetch(
                """
                SELECT d.*,s.name AS server_name
                FROM library_node_deployments d
                JOIN jellyfin_servers s ON s.id=d.server_id
                ORDER BY d.created_at DESC LIMIT $1
                """,
                limit,
            )
    return {"deployments": [deployment_row(row) for row in rows]}


@router.get("/{job_id}")
async def get_deployment(
    job_id: uuid.UUID,
    request: Request,
    _: PanelSession = Depends(read_admin),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        row = await connection.fetchrow(
            """
            SELECT d.*,s.name AS server_name
            FROM library_node_deployments d
            JOIN jellyfin_servers s ON s.id=d.server_id
            WHERE d.id=$1
            """,
            job_id,
        )
    if row is None:
        raise HTTPException(status_code=404, detail="Node deployment job was not found.")
    return deployment_row(row)


@router.post("/{server_id}")
async def start_deployment(
    server_id: uuid.UUID,
    payload: RemoteNodeDeploymentPayload,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    pool: asyncpg.Pool = request.app.state.db
    server = await get_server(pool, server_id)
    if server.is_local:
        raise HTTPException(status_code=409, detail="The local Library Agent is already installed with JellyPanel.")
    async with pool.acquire() as connection:
        running = await connection.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM library_node_deployments
                WHERE server_id=$1 AND status NOT IN ('completed','warning','failed')
            )
            """,
            server_id,
        )
        if running:
            raise HTTPException(status_code=409, detail=f"A node deployment is already running for {server.name}.")
        job_id = uuid.uuid4()
        await connection.execute(
            """
            INSERT INTO library_node_deployments
                (id,server_id,deployment_type,status,ssh_host,ssh_port,ssh_username,
                 auth_type,install_path,source_host_path,strm_host_path,agent_url,
                 agent_port,native_service_user,progress_percent,current_step,requested_by)
            VALUES ($1,$2,$3,'queued',$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,0,'Queued',$14)
            """,
            job_id,
            server_id,
            payload.deployment_type,
            payload.ssh_host,
            payload.ssh_port,
            payload.ssh_username,
            payload.auth_type,
            payload.install_path,
            payload.source_host_path,
            payload.strm_host_path,
            payload.agent_url,
            payload.agent_port,
            payload.native_service_user,
            session.username,
        )
    task = asyncio.create_task(run_deployment(request.app, job_id, server_id, payload, session.username))
    ACTIVE_TASKS.add(task)
    request.app.state.background_tasks.add(task)
    task.add_done_callback(ACTIVE_TASKS.discard)
    task.add_done_callback(request.app.state.background_tasks.discard)
    return {"id": str(job_id), "status": "queued", "server_id": str(server_id)}
