CREATE TABLE IF NOT EXISTS library_node_deployments (
    id UUID PRIMARY KEY,
    server_id UUID NOT NULL REFERENCES jellyfin_servers(id) ON DELETE CASCADE,
    deployment_type TEXT NOT NULL CHECK (deployment_type IN ('docker','native')),
    status TEXT NOT NULL CHECK (status IN ('queued','connecting','uploading','installing','verifying','completed','warning','failed')),
    ssh_host TEXT NOT NULL,
    ssh_port INTEGER NOT NULL DEFAULT 22 CHECK (ssh_port BETWEEN 1 AND 65535),
    ssh_username TEXT NOT NULL,
    auth_type TEXT NOT NULL CHECK (auth_type IN ('password','private_key')),
    install_path TEXT NOT NULL DEFAULT '/opt/galaxytv-library-node',
    source_host_path TEXT NOT NULL,
    strm_host_path TEXT NOT NULL,
    agent_url TEXT NOT NULL,
    agent_port INTEGER NOT NULL DEFAULT 8292 CHECK (agent_port BETWEEN 1 AND 65535),
    native_service_user TEXT NOT NULL DEFAULT 'root',
    progress_percent INTEGER NOT NULL DEFAULT 0 CHECK (progress_percent BETWEEN 0 AND 100),
    current_step TEXT NOT NULL DEFAULT '',
    log_text TEXT NOT NULL DEFAULT '',
    result JSONB NOT NULL DEFAULT '{}'::jsonb,
    error TEXT,
    requested_by TEXT,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_library_node_deployments_server_created
    ON library_node_deployments (server_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_library_node_deployments_status
    ON library_node_deployments (status, created_at DESC);
