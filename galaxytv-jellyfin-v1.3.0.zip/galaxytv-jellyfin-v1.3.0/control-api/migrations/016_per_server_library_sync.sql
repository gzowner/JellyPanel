CREATE TABLE IF NOT EXISTS server_library_settings (
    server_id UUID PRIMARY KEY REFERENCES jellyfin_servers(id) ON DELETE CASCADE,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    agent_url TEXT NOT NULL DEFAULT '',
    agent_token_encrypted TEXT NOT NULL DEFAULT '',
    media_token_encrypted TEXT NOT NULL DEFAULT '',
    source_path TEXT NOT NULL DEFAULT '/media/Media',
    output_path TEXT NOT NULL DEFAULT '/strm-library',
    movies_folder TEXT NOT NULL DEFAULT 'Movies',
    tv_folder TEXT NOT NULL DEFAULT 'TV Shows',
    playback_base_url TEXT NOT NULL DEFAULT '',
    schedule_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    daily_time TIME NOT NULL DEFAULT '02:00',
    missing_grace_days INTEGER NOT NULL DEFAULT 7 CHECK (missing_grace_days BETWEEN 1 AND 365),
    remove_missing BOOLEAN NOT NULL DEFAULT TRUE,
    adopt_existing BOOLEAN NOT NULL DEFAULT TRUE,
    skip_direct_duplicates BOOLEAN NOT NULL DEFAULT TRUE,
    refresh_jellyfin BOOLEAN NOT NULL DEFAULT TRUE,
    last_schedule_date DATE,
    last_status TEXT NOT NULL DEFAULT 'not_configured'
        CHECK (last_status IN ('not_configured','ready','running','completed','warning','failed','offline')),
    last_status_message TEXT NOT NULL DEFAULT '',
    last_checked_at TIMESTAMPTZ,
    last_success_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS server_library_jobs (
    id UUID PRIMARY KEY,
    server_id UUID NOT NULL REFERENCES jellyfin_servers(id) ON DELETE CASCADE,
    job_type TEXT NOT NULL CHECK (job_type IN ('sync','adopt','verify','cleanup','full')),
    status TEXT NOT NULL CHECK (status IN ('queued','running','completed','warning','failed','cancelled')),
    remote_job_id TEXT,
    progress_percent INTEGER NOT NULL DEFAULT 0 CHECK (progress_percent BETWEEN 0 AND 100),
    current_path TEXT,
    total_items BIGINT NOT NULL DEFAULT 0,
    processed_items BIGINT NOT NULL DEFAULT 0,
    added_items BIGINT NOT NULL DEFAULT 0,
    updated_items BIGINT NOT NULL DEFAULT 0,
    unchanged_items BIGINT NOT NULL DEFAULT 0,
    adopted_items BIGINT NOT NULL DEFAULT 0,
    skipped_duplicates BIGINT NOT NULL DEFAULT 0,
    missing_items BIGINT NOT NULL DEFAULT 0,
    removed_items BIGINT NOT NULL DEFAULT 0,
    conflict_items BIGINT NOT NULL DEFAULT 0,
    failed_items BIGINT NOT NULL DEFAULT 0,
    result JSONB NOT NULL DEFAULT '{}'::jsonb,
    error TEXT,
    requested_by TEXT,
    cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_server_library_jobs_server_created
    ON server_library_jobs (server_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_server_library_jobs_status
    ON server_library_jobs (status, created_at DESC);

CREATE TABLE IF NOT EXISTS server_library_conflicts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    server_id UUID NOT NULL REFERENCES jellyfin_servers(id) ON DELETE CASCADE,
    job_id UUID REFERENCES server_library_jobs(id) ON DELETE CASCADE,
    source_path TEXT NOT NULL DEFAULT '',
    output_path TEXT NOT NULL DEFAULT '',
    conflict_type TEXT NOT NULL CHECK (conflict_type IN ('direct_library_duplicate','user_managed_strm','identity_collision','unmatched_existing_strm','agent_warning')),
    message TEXT NOT NULL DEFAULT '',
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_server_library_conflicts_server
    ON server_library_conflicts (server_id, resolved_at, created_at DESC);
