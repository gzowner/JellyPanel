# GalaxyTV v1.1.x Multi-Server Test Plan

Use test accounts and a non-production secondary Jellyfin server first.

## 1. Upgrade validation

```bash
cd /root/galaxytv-jellyfin-v1.3.0
sudo bash install.sh --mode upgrade
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
sudo /opt/galaxytv-jellyfin/scripts/manage.sh servers
```

Expected:

- Installed version `1.3.0`.
- Database schema `14`.
- One protected default server named `Local Jellyfin`.
- Existing users, packages, resellers, M3U, EPG, mirror, and backups remain present.

## 2. Register a secondary server

1. Create a Jellyfin API key on the secondary server.
2. Open GalaxyTV → **Servers**.
3. Add the secondary internal/API URL and public/client URL.
4. Save and run **Test all**.

Expected:

- Server status becomes `online`.
- Jellyfin server name and version appear.
- The API key is not displayed after saving.

## 3. Assign a test user

1. Open **Users**.
2. Select **Servers** beside a managed non-administrator test account.
3. Enter a test password.
4. Click **Assign** on the secondary server.

Expected:

- A same-name user is linked or created on the secondary server.
- The assignment becomes `synced`.
- Live TV, download, remote-access, transcoding, disabled, and session-limit policy match the primary account.

## 4. Policy and password propagation

Change the test user's package or permissions, then refresh the secondary Jellyfin user. Reset the password from GalaxyTV and sign in to both servers.

Expected:

- Assigned-server policy updates without changing administrator accounts.
- The new password works on both assigned servers.

## 5. Combined Stream Operations

Start playback for the same test user on the primary and secondary servers.

Expected:

- Both sessions appear with the correct server name.
- Combined connection usage reflects playback across both servers.
- Message and Stop commands reach the selected session's server.
- Suspend disables the user on all assigned servers and stops active playback.

Keep automatic over-limit stopping disabled during the first test.

## 6. Outage behavior

Stop or firewall the secondary Jellyfin server, then refresh GalaxyTV.

Expected:

- The primary server and panel continue working.
- The secondary server reports offline.
- Stream Operations identifies the server that failed to report.
- Restoring the server and running **Test** returns it to online.

## 7. Unassign and removal

Test both unassignment choices:

- Preserve the remote Jellyfin user.
- Delete the remote Jellyfin user.

Then remove the secondary server from GalaxyTV.

Expected:

- The local default server cannot be removed.
- Removing a secondary server does not delete its Jellyfin installation.

## 8. Rollback test

A pre-upgrade rollback snapshot should exist under:

```text
/opt/galaxytv-jellyfin/backups/upgrades/
```

Application rollback command:

```bash
sudo /opt/galaxytv-jellyfin/scripts/rollback-last-upgrade.sh
```

Migration 14 is additive and remains in PostgreSQL after application-file rollback. Reinstalling v1.3.0 reuses the existing tables safely.
