from __future__ import annotations

import gzip
import json
import uuid
from contextlib import asynccontextmanager
from os import environ
from typing import Any

import asyncpg
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import PlainTextResponse, RedirectResponse, Response

DATABASE_URL = environ["DATABASE_URL"]


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.db = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=6)
    app.state.http = httpx.AsyncClient(
        follow_redirects=True,
        timeout=httpx.Timeout(180.0, connect=30.0),
    )
    yield
    await app.state.http.aclose()
    await app.state.db.close()


app = FastAPI(title="GalaxyTV M3U Gateway", version="1.3.0", lifespan=lifespan)


def attr(name: str, value: Any) -> str:
    if value is None or str(value) == "":
        return ""
    safe = str(value).replace('"', "'").replace("\r", " ").replace("\n", " ")
    return f' {name}="{safe}"'


def clean_name(value: str) -> str:
    return value.replace("\r", " ").replace("\n", " ").strip()


def json_url_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            value = [value]
    if not isinstance(value, (list, tuple)):
        return []
    result: list[str] = []
    seen: set[str] = set()
    for item in value:
        url = str(item).strip()
        if not url or url in seen:
            continue
        if not url.lower().startswith(("http://", "https://")):
            continue
        seen.add(url)
        result.append(url)
    return result


def effective_epg_urls(manual: Any, detected: Any) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for url in [*json_url_list(manual), *json_url_list(detected)]:
        if url in seen:
            continue
        seen.add(url)
        result.append(url)
    return result


@app.get("/health")
async def health() -> dict[str, Any]:
    async with app.state.db.acquire() as connection:
        value = await connection.fetchval("SELECT 1")
    return {
        "status": "ok" if value == 1 else "degraded",
        "service": "GalaxyTV M3U Gateway",
        "version": "1.3.0",
    }


@app.get("/playlist/master.m3u", response_class=PlainTextResponse)
async def master_playlist() -> PlainTextResponse:
    async with app.state.db.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT ch.id::text, ch.name, COALESCE(NULLIF(ch.mapped_tvg_id, ''), ch.tvg_id) AS tvg_id, ch.tvg_name, ch.tvg_logo,
                   ch.channel_number, c.display_name
            FROM m3u_channels ch
            JOIN m3u_sources s ON s.id = ch.source_id
            JOIN m3u_categories c ON c.id = ch.category_id
            WHERE s.enabled = TRUE
              AND c.enabled = TRUE
              AND ch.enabled = TRUE
              AND ch.active = TRUE
            ORDER BY c.sort_order, c.display_name, ch.name
            """
        )

    lines = ["#EXTM3U"]
    for row in rows:
        metadata = "#EXTINF:-1"
        metadata += attr("tvg-id", row["tvg_id"])
        metadata += attr("tvg-name", row["tvg_name"] or row["name"])
        metadata += attr("tvg-logo", row["tvg_logo"])
        metadata += attr("tvg-chno", row["channel_number"])
        metadata += attr("group-title", row["display_name"])
        metadata += f",{clean_name(row['name'])}"
        lines.append(metadata)
        lines.append(f"http://m3u-gateway:8183/stream/{row['id']}")

    return PlainTextResponse(
        "\n".join(lines) + "\n",
        media_type="audio/x-mpegurl",
        headers={"Cache-Control": "no-store"},
    )


async def load_epg_source(source_id: uuid.UUID, feed_index: int) -> tuple[str, str]:
    async with app.state.db.acquire() as connection:
        source = await connection.fetchrow(
            """
            SELECT user_agent, epg_user_agent, epg_urls, detected_epg_urls,
                   enabled, epg_enabled
            FROM m3u_sources
            WHERE id = $1
            """,
            source_id,
        )
    if source is None or not source["enabled"] or not source["epg_enabled"]:
        raise HTTPException(status_code=404, detail="XMLTV source is unavailable.")
    urls = effective_epg_urls(source["epg_urls"], source["detected_epg_urls"])
    if feed_index < 0 or feed_index >= len(urls):
        raise HTTPException(status_code=404, detail="XMLTV feed is unavailable.")
    return urls[feed_index], source["epg_user_agent"] or source["user_agent"] or ""


async def fetch_epg(source_id: uuid.UUID, feed_index: int, *, compressed: bool) -> Response:
    url, user_agent = await load_epg_source(source_id, feed_index)
    headers: dict[str, str] = {}
    if user_agent:
        headers["User-Agent"] = user_agent
    try:
        response = await app.state.http.get(url, headers=headers)
        response.raise_for_status()
        data = response.content
        if not data:
            raise ValueError("The XMLTV provider returned an empty response.")
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"XMLTV download failed: {exc}") from exc

    is_gzip = data[:2] == b"\x1f\x8b"
    try:
        if compressed:
            if not is_gzip:
                data = gzip.compress(data, compresslevel=5)
            media_type = "application/gzip"
        else:
            if is_gzip:
                data = gzip.decompress(data)
            media_type = "application/xml"
    except (OSError, EOFError) as exc:
        raise HTTPException(status_code=502, detail=f"XMLTV decompression failed: {exc}") from exc

    return Response(
        content=data,
        media_type=media_type,
        headers={
            "Cache-Control": "no-store",
            "X-GalaxyTV-EPG-Source": str(source_id),
        },
    )


@app.get("/epg/{source_id}/{feed_index}.xml")
async def epg_xml(source_id: uuid.UUID, feed_index: int) -> Response:
    return await fetch_epg(source_id, feed_index, compressed=False)


@app.get("/epg/{source_id}/{feed_index}.xml.gz")
async def epg_xml_gz(source_id: uuid.UUID, feed_index: int) -> Response:
    return await fetch_epg(source_id, feed_index, compressed=True)


@app.get("/stream/{channel_id}")
async def stream(channel_id: uuid.UUID) -> RedirectResponse:
    async with app.state.db.acquire() as connection:
        url = await connection.fetchval(
            """
            SELECT ch.stream_url
            FROM m3u_channels ch
            JOIN m3u_sources s ON s.id = ch.source_id
            JOIN m3u_categories c ON c.id = ch.category_id
            WHERE ch.id = $1
              AND s.enabled = TRUE
              AND c.enabled = TRUE
              AND ch.enabled = TRUE
              AND ch.active = TRUE
            """,
            channel_id,
        )
    if not url:
        raise HTTPException(status_code=404, detail="Channel is unavailable.")
    return RedirectResponse(url=url, status_code=307)
