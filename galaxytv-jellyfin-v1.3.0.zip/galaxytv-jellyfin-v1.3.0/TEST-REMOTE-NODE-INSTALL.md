# GalaxyTV v1.3.0 Remote Library Node Test Plan

Use a non-production Jellyfin server first.

## 1. Upgrade the central panel

```bash
cd /root
sha256sum -c galaxytv-jellyfin-v1.3.0.zip.sha256
unzip -o galaxytv-jellyfin-v1.3.0.zip
cd galaxytv-jellyfin-v1.3.0
sudo bash install.sh --mode upgrade
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
```

Confirm:

- Installed version is `1.3.0`.
- Database schema is `17`.
- Existing servers, users, packages, M3U, EPG, and STRM records remain.

## 2. Docker remote install

Prepare a test Ubuntu/Debian Jellyfin server reachable by SSH.

1. Register it under **Servers** and verify its API key.
2. Open **Server Libraries → Install Node**.
3. Select **Docker Compose**.
4. Enter the SSH host, credentials, media scan path, and STRM path.
5. Use `http://host.docker.internal:8096` when Jellyfin is on port 8096.
6. Start deployment and watch the live log.

Verify remotely:

```bash
sudo docker ps --filter name=galaxytv-library-node
sudo docker logs --tail=100 galaxytv-library-node
sudo ls -la /opt/galaxytv-library-node
```

Verify centrally:

```bash
sudo /opt/galaxytv-jellyfin/scripts/manage.sh deployments
sudo /opt/galaxytv-jellyfin/scripts/manage.sh libraries
```

The server library should show `ready`, and the generated tokens should be configured without displaying them.

## 3. Docker update test

Run **Install Node** again for the same server using the same paths. Confirm:

- Existing `state/library-agent.sqlite3` remains.
- Existing STRM files remain.
- The container is rebuilt and healthy.
- The deployment history contains both jobs.

## 4. Native systemd install

Use a separate non-Docker test host or remove the Docker node first.

1. Select **Native Python + systemd**.
2. Use `http://127.0.0.1:8096` for local native Jellyfin.
3. Keep service user `root` for the first test.
4. Start deployment.

Verify remotely:

```bash
sudo systemctl status galaxytv-library-node.service --no-pager
sudo journalctl -u galaxytv-library-node.service -n 100 --no-pager
sudo cat /etc/systemd/system/galaxytv-library-node.service
```

Do not display `/etc/galaxytv-library-node.env`; it contains API and media tokens.

## 5. Authentication tests

Test separately:

- Root password authentication.
- Non-root passwordless sudo.
- Non-root user with sudo password.
- OpenSSH private key.
- Encrypted private key with passphrase.
- Host-key verification with a valid key.
- Host-key verification with an invalid key; deployment must fail before upload.

Confirm PostgreSQL does not contain SSH secrets:

```bash
cd /opt/galaxytv-jellyfin
sudo docker compose --env-file .env exec -T postgres \
  psql -U galaxytv -d galaxytv -c '\d library_node_deployments'
```

The table should contain host, username, deployment settings, status, and logs, but no password or private-key columns.

## 6. Media sync test

After successful deployment:

1. Click **Test**.
2. Run **Adopt Existing** when the STRM folder already contains content.
3. Run **Verify**.
4. Run **Sync** with one movie and one episode.
5. Mount the host STRM path into Jellyfin when Jellyfin uses Docker.
6. Add Movies and TV Shows libraries.
7. Verify playback.
8. Rerun Sync and confirm unchanged file timestamps remain unchanged.

## 7. Failure and recovery tests

- Wrong SSH password.
- Missing sudo permission.
- Occupied agent port.
- Missing media path.
- Docker installation disabled on a host without Docker.
- Central panel unable to reach the advertised agent URL.
- Restart the central API during a deployment; the job must be marked failed and credentials must not be retained.
- Rerun after correcting the problem.

## 8. Production readiness

Before production:

- Restrict port 8292.
- Use a private address or WireGuard.
- Enable SSH host-key verification.
- Use dedicated deployment credentials with limited sudo scope where practical.
- Keep automatic daily sync disabled until one manual sync completes successfully.
