# GalaxyTV Security Notes

GalaxyTV v1.3.0 defaults to local HTTP because the development and first stable tests use local systems.

Before exposing GalaxyTV or Jellyfin outside a trusted private network:

- Use HTTPS through a maintained reverse proxy.
- Restrict the GalaxyTV panel by firewall, VPN, or trusted source addresses.
- Keep the Control API and M3U gateway bound to localhost.
- Do not publish the Operations Agent or media gateway ports.
- Configure Jellyfin Known Proxies when a reverse proxy is introduced.
- Protect `.env`, the panel credential file, managed backups, and diagnostic archives.
- Use a unique panel password and rotate any copied API keys.
- Review diagnostics manually before sharing them.
- Keep automatic over-limit stopping disabled until client behavior has been observed.

The installer does not modify the host firewall because network requirements differ between local, VPN, and public deployments.

## Remote node deployment

GalaxyTV v1.3.0 accepts SSH passwords, private keys, passphrases, and optional sudo passwords only in the active remote-install request. These secrets are not inserted into PostgreSQL, audit details, or deployment logs. Restarting the Control API interrupts the deployment because the credentials are intentionally not recoverable.

Host-key verification is optional for local testing but should be enabled for production. Remote installation grants root or sudo-level access to the selected host, so only administrators can use it. Restrict the central panel itself with HTTPS, firewall rules, and strong authentication before allowing remote deployments.

The installed Library Node serves authenticated control and media endpoints. Restrict its port to the central JellyPanel and local Jellyfin server; do not expose plain HTTP directly to the internet.
