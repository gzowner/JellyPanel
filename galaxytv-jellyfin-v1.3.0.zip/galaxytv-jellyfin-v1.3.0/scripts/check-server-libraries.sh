#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${GALAXYTV_BASE_DIR:-/opt/galaxytv-jellyfin}"
COMPOSE="$BASE_DIR/scripts/compose.sh"
[[ -x "$COMPOSE" ]] || { echo "Missing $COMPOSE"; exit 1; }
echo "== Containers =="
"$COMPOSE" ps library-agent control-api control-worker jellyfin
echo
echo "== Library agent =="
"$COMPOSE" exec -T library-agent python - <<'PY'
import json, os, urllib.request
req=urllib.request.Request('http://127.0.0.1:8192/status',headers={'X-Library-Token':os.environ['LIBRARY_AGENT_TOKEN']})
with urllib.request.urlopen(req,timeout=15) as r: print(json.dumps(json.load(r),indent=2))
PY
echo
echo "== Central records =="
user="$(grep '^POSTGRES_USER=' "$BASE_DIR/.env"|cut -d= -f2-)"; db="$(grep '^POSTGRES_DB=' "$BASE_DIR/.env"|cut -d= -f2-)"
"$COMPOSE" exec -T postgres psql -U "${user:-galaxytv}" -d "${db:-galaxytv}" -c "SELECT s.name,l.enabled,l.last_status,l.last_status_message,l.last_success_at FROM server_library_settings l JOIN jellyfin_servers s ON s.id=l.server_id ORDER BY s.is_default DESC,s.name;"
