#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${GALAXYTV_BASE_DIR:-/opt/galaxytv-jellyfin}"
COMPOSE="$BASE_DIR/scripts/compose.sh"
[[ -x "$COMPOSE" ]] || { echo "Missing $COMPOSE"; exit 1; }
user="$(grep '^POSTGRES_USER=' "$BASE_DIR/.env"|cut -d= -f2-)"
db="$(grep '^POSTGRES_DB=' "$BASE_DIR/.env"|cut -d= -f2-)"

echo "== Control services =="
"$COMPOSE" ps control-api control-worker postgres

echo
echo "== Recent remote node deployments =="
"$COMPOSE" exec -T postgres psql -U "${user:-galaxytv}" -d "${db:-galaxytv}" -c "
SELECT s.name,d.deployment_type,d.status,d.ssh_host,d.agent_url,d.progress_percent,
       d.current_step,d.created_at,d.finished_at,LEFT(COALESCE(d.error,''),180) AS error
FROM library_node_deployments d
JOIN jellyfin_servers s ON s.id=d.server_id
ORDER BY d.created_at DESC
LIMIT 30;"

echo
echo "== Library settings after deployment =="
"$COMPOSE" exec -T postgres psql -U "${user:-galaxytv}" -d "${db:-galaxytv}" -c "
SELECT s.name,l.agent_url,l.source_path,l.output_path,l.last_status,l.last_checked_at
FROM server_library_settings l
JOIN jellyfin_servers s ON s.id=l.server_id
ORDER BY s.is_default DESC,s.name;"
