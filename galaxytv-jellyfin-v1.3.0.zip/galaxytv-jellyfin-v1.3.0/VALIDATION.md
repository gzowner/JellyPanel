# GalaxyTV v1.3.0 Validation

Completed build-time validation:

- Python compilation for every service and deployment payload.
- Pydantic validation for Docker and native remote-install requests.
- AsyncSSH 2.24.0 import and option validation.
- Bash syntax checks for all installers and diagnostics scripts.
- Docker Compose YAML parsing.
- Browser JavaScript syntax validation.
- Browser element ID/reference consistency validation.
- Database migration 17 review.
- Remote installer payload structure verification.
- Docker and native install-script static review.
- Mocked Docker deployment flow through compose generation, payload replacement, and health completion.
- Mocked native deployment flow through virtual-environment creation, systemd unit generation, and health completion.
- ZIP CRC, executable-mode, extraction, and internal SHA-256 validation.

Not available in the build environment:

- A real SSH target.
- A complete Docker Engine deployment on a remote host.
- A complete native systemd deployment on a remote host.
- End-to-end playback through the remotely installed node.

Use `TEST-REMOTE-NODE-INSTALL.md` before production deployment.
