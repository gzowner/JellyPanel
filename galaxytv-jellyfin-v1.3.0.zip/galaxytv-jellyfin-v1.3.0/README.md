# GalaxyTV Jellyfin v1.3.0 — Remote Library Node Deployment

GalaxyTV v1.3.0 is a cumulative upgrade from v1.2.0. It keeps all multi-server user management, M3U/XMLTV, EPG mapping, stream operations, backups, existing-user import, and per-server incremental STRM libraries. This release adds administrator-controlled installation and updating of the Library Node on remote Jellyfin hosts over SSH.

## What v1.3.0 adds

- **Install Node** directly from the **Server Libraries** page.
- Docker Compose deployment for hosts already using Docker.
- Optional automatic Docker Engine installation when Docker is missing.
- Native Python virtual-environment and systemd deployment for hosts that do not use Docker.
- Password or OpenSSH private-key authentication.
- Root, passwordless sudo, or sudo-password elevation.
- Optional strict SSH host-key verification.
- Generated per-node Agent and Media tokens.
- Automatic saving of the node URL, tokens, source path, output path, and ready status after successful installation.
- Remote install/update progress with a reviewable log.
- Existing node state, STRM output, and inventory are preserved when updating the agent.
- SSH passwords, private keys, passphrases, and sudo passwords are never written to PostgreSQL.
- Manual Docker and native installers remain included for offline or restricted environments.
- Database schema **17**.

## Upgrade from v1.2.0

Upload the ZIP and checksum to `/root`, then run:

```bash
cd /root
sha256sum -c galaxytv-jellyfin-v1.3.0.zip.sha256
unzip -o galaxytv-jellyfin-v1.3.0.zip
cd galaxytv-jellyfin-v1.3.0
sudo bash install.sh --mode upgrade
```

The upgrade preserves Jellyfin, PostgreSQL, Redis, users, servers, packages, resellers, credits, M3U/XMLTV sources, EPG mappings, backups, STRM files, and Library Agent inventory. It creates the normal pre-upgrade backups and rolls application files back automatically when validation fails.

After upgrading:

```bash
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
sudo /opt/galaxytv-jellyfin/scripts/manage.sh deployments
```

Force-refresh the browser with `Ctrl+F5`.

## Remote installation from JellyPanel

First register and test the remote Jellyfin server under:

```text
JellyPanel → Servers
```

The server must have a valid Jellyfin API key. Then open:

```text
JellyPanel → Server Libraries → Install Node
```

Enter:

- SSH address, port, and username.
- Password or OpenSSH private key.
- Sudo password only when the SSH user requires password-based sudo.
- Host media scan path, such as `/mnt/unionfs/Media`.
- Host STRM output path, such as `/opt/galaxytv-library-node/strm-library`.
- Agent port, normally `8292`.
- Agent URL reachable from the central JellyPanel server.
- Jellyfin URL reachable from the installed node.
- Docker Compose or Native Python/systemd installation type.

The installer uploads only the Library Agent payload and a temporary configuration. The temporary SSH credentials remain in the running API request only and are discarded when the job ends. The remote temporary installation directory is deleted after a successful deployment.

### Docker deployment

Use Docker mode when the remote server has Docker or can install it. Recommended Jellyfin URL from the node:

```text
http://host.docker.internal:8096
```

The installer creates:

```text
/opt/galaxytv-library-node/
├── .env
├── compose.yml
├── library-agent/
├── state/
└── strm-library/
```

The media scan path is mounted read-only at `/media/Media`. The host STRM path is mounted at `/strm-library`.

The remote Jellyfin container must mount that same host STRM directory, normally as:

```yaml
volumes:
  - /opt/galaxytv-library-node/strm-library:/strm-library:ro
```

Add the generated Jellyfin libraries after the first successful sync:

```text
Movies:   /strm-library/Movies
TV Shows: /strm-library/TV Shows
```

### Native Python/systemd deployment

Use Native mode when Docker is not desired. The installer creates a Python virtual environment and:

```text
/etc/systemd/system/galaxytv-library-node.service
/etc/galaxytv-library-node.env
/opt/galaxytv-library-node/library-agent
/opt/galaxytv-library-node/venv
/opt/galaxytv-library-node/state
```

The recommended Jellyfin URL from a native node is:

```text
http://127.0.0.1:8096
```

The default systemd service user is `root` to avoid media-mount permission failures. A restricted service account can be entered in the panel, but that account must have read access to the media scan path and write access to the STRM output path.

For native Jellyfin, add the actual host STRM path as the library path. For Jellyfin running in Docker, bind-mount the host STRM path into its container first.

## SSH and network requirements

- The central JellyPanel server must reach the remote SSH port.
- The remote host must be Ubuntu/Debian with `apt-get` for automatic installation.
- The remote host needs internet access while installing Python packages or Docker.
- The central panel and remote Jellyfin host must reach the Library Agent URL.
- Restrict agent port `8292` to the central panel and the local Jellyfin server using a firewall, private LAN, or WireGuard.
- Do not expose the plain HTTP Library Agent directly to the public internet.
- Enable host-key verification and supply the server's OpenSSH known-host key for production deployments.

## Existing library and update protection

Remote node installation does not run a media sync automatically. After deployment:

1. Test the agent.
2. Review source and output paths.
3. Run **Adopt Existing** when older STRM files already exist.
4. Run **Verify**.
5. Run a small **Sync**.
6. Add the resulting STRM paths to that Jellyfin server.
7. Keep the old direct-media library enabled until playback and metadata are confirmed.

Updating a node replaces only the Library Agent application and Python environment/container image. It preserves:

- SQLite inventory and missing-file dates.
- Existing STRM/NFO files.
- Node installation path.
- Host media.
- Previous agent application as a temporary rollback copy.

Unchanged STRM and NFO files are still left untouched by daily synchronization. Missing generated items retain the configured grace period, and an empty or unavailable mount cannot trigger mass deletion.

## Manual installation fallback

Docker:

```bash
cd galaxytv-jellyfin-v1.3.0
sudo bash library-node/install-node.sh --docker
sudo nano /opt/galaxytv-library-node/.env
sudo bash library-node/install-node.sh --docker
```

Native systemd:

```bash
cd galaxytv-jellyfin-v1.3.0
sudo bash library-node/install-node.sh --native
sudo nano /opt/galaxytv-library-node/.env
sudo bash library-node/install-node.sh --native
```

The first manual run creates `.env` and random tokens, then exits so the configuration can be reviewed.

## Management commands

```bash
sudo /opt/galaxytv-jellyfin/scripts/manage.sh health
sudo /opt/galaxytv-jellyfin/scripts/manage.sh servers
sudo /opt/galaxytv-jellyfin/scripts/manage.sh libraries
sudo /opt/galaxytv-jellyfin/scripts/manage.sh deployments
sudo /opt/galaxytv-jellyfin/scripts/manage.sh logs
```

## Current limitations

- Remote deployment uses SSH and requires administrator-approved root or sudo access.
- It does not change the remote firewall automatically.
- It does not alter the remote Jellyfin container volumes; mount the generated STRM path into Jellyfin yourself.
- Automatic remote installation currently supports apt-based Ubuntu/Debian hosts.
- A deployment interrupted by a central API restart is marked failed because SSH credentials are intentionally not retained. Rerun the deployment after the API is healthy.
- Validate one test server and a small media folder before enabling the daily schedule for a large library.

See [TEST-REMOTE-NODE-INSTALL.md](TEST-REMOTE-NODE-INSTALL.md) and [TEST-SERVER-LIBRARIES.md](TEST-SERVER-LIBRARIES.md).
