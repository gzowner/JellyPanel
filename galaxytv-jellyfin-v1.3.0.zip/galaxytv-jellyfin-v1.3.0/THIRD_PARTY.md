# Third-Party Components

GalaxyTV integrates with and deploys third-party software through container images and Python packages, including Jellyfin, PostgreSQL, Redis, Nginx, FastAPI, Docker SDK for Python, the Python cryptography package for encrypted server credentials, and their dependencies.

GalaxyTV is not an official Jellyfin project and is not endorsed by the Jellyfin project.

Each third-party component remains subject to its own license and terms. Review the component image and package metadata before redistributing a public GalaxyTV bundle or hosted service.

## AsyncSSH

The Control API uses AsyncSSH for administrator-approved remote Library Node deployment. AsyncSSH is distributed under EPL-2.0 OR GPL-2.0-or-later. See the upstream project for complete license terms.
