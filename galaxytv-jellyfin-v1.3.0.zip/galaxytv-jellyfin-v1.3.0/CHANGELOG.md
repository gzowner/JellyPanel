# Changelog

## 1.3.0 Remote Library Node Deployment

- Adds remote Library Node installation and updating from the Server Libraries page.
- Supports Docker Compose and native Python/systemd deployments.
- Supports SSH passwords, OpenSSH private keys, root, passwordless sudo, and sudo passwords.
- Adds optional SSH host-key verification.
- Generates and saves new Agent and Media tokens only after deployment succeeds.
- Preserves remote node inventory, STRM output, and existing generated libraries during updates.
- Stores deployment status and sanitized logs without storing SSH credentials.
- Adds manual native installation alongside the existing Docker installer.
- Adds `manage.sh deployments` diagnostics.
- Adds database schema 17.

## 1.2.0 Per-Server Library Sync

- Adds independent incremental STRM libraries for every registered Jellyfin server.
- Adds the local Library Agent and deployable remote Library Node.
- Adds daily schedules, existing STRM adoption, direct-library duplicate checks, conflict reporting, and seven-day missing-file grace protection.
- Leaves unchanged STRM/NFO files untouched and refreshes Jellyfin only after actual changes.
- Handles renamed source files and changed STRM output roots without leaving managed duplicates behind.
- Protects generated libraries from empty or unavailable mounts and never overwrites unmarked STRM files automatically.
- Includes the Library Agent SQLite inventory in managed backup and restore operations.
- Adds database schema 16.

## 1.1.1 Existing-User Import

- Adds previewed existing-user import for every registered Jellyfin server.
- Adopts local users without changing their passwords.
- Links same-name secondary-server accounts to primary users.
- Creates missing primary accounts only when approved.
- Generates one-time primary passwords when no temporary password is supplied.
- Supports package, reseller, expiration, notes, and permission-mode defaults during import.
- Protects administrator accounts and reports username conflicts.
- Records import history and audit details.
- Adds `manage.sh imports` diagnostics.
- Adds database schema 15.

## 1.1.0 Multi-Server

- Adds a central Jellyfin server registry with encrypted API keys and health checks.
- Automatically registers the existing local Jellyfin installation as the protected default server.
- Adds per-user server assignments, existing-account linking, remote-user creation, and synchronization status.
- Propagates policy, package, expiration, suspension, enablement, and password changes to assigned servers.
- Aggregates live sessions and package connection limits across enabled servers.
- Routes playback messages and stop commands to the correct Jellyfin server.
- Adds server-aware stream samples, alerts, operations status, and user synchronization warnings.
- Adds database schema 14.

## 1.0.1 Update-System Test

- Adds administrator-only Update History.
- Records installed release versions and database schema.
- Validates cumulative upgrade, backup, migration, health-check, and rollback behavior.

## 1.0.0 Stable

- Consolidates the complete tested JellyPanel feature set into one installer.
- Adds fresh, upgrade, repair, restore, diagnostics, and data-preserving uninstall modes.
- Adds release checksum verification, pre-upgrade backups, health validation, and automatic application rollback.
