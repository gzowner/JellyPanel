# GalaxyTV Library Node

The central JellyPanel can install this component remotely from **Server Libraries → Install Node**. This folder remains available for manual or offline deployment.

## Docker installation

```bash
cd galaxytv-jellyfin-v1.3.0
sudo bash library-node/install-node.sh --docker
sudo nano /opt/galaxytv-library-node/.env
sudo bash library-node/install-node.sh --docker
```

Docker mode mounts the configured host media path read-only and writes generated STRM/NFO files to `STRM_PATH`.

## Native Python/systemd installation

```bash
cd galaxytv-jellyfin-v1.3.0
sudo bash library-node/install-node.sh --native
sudo nano /opt/galaxytv-library-node/.env
sudo bash library-node/install-node.sh --native
```

Native mode installs a Python virtual environment and the systemd service:

```text
/etc/systemd/system/galaxytv-library-node.service
```

The default native service user is `root` to avoid media-mount permission problems. A restricted account may be used after granting it read access to `MEDIA_SCAN_PATH` and write access to `STRM_PATH`.

## Required configuration

```text
MEDIA_PATH                  Media mount root used by Docker mode
MEDIA_SCAN_PATH             Exact source folder used by native mode
STRM_PATH                   Host STRM output directory
JELLYFIN_URL                Jellyfin URL reachable from the node
JELLYFIN_API_KEY            API key from that Jellyfin server
LIBRARY_PLAYBACK_BASE_URL   URL clients/Jellyfin use to reach the node
LIBRARY_AGENT_TOKEN         Central control token
LIBRARY_MEDIA_TOKEN         Token embedded in generated playback URLs
```

Allow the central JellyPanel server to reach TCP port `8292`. Restrict that port to the central panel and local Jellyfin host through a firewall, private LAN, or WireGuard.

## Jellyfin STRM mount

For Docker Jellyfin, mount the host `STRM_PATH` into the container:

```yaml
volumes:
  - /opt/galaxytv-library-node/strm-library:/strm-library:ro
```

Then add:

```text
/strm-library/Movies
/strm-library/TV Shows
```

For native Jellyfin, add the actual host `STRM_PATH` directories directly.
