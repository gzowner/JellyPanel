#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_DIR="${LIBRARY_NODE_BASE_DIR:-/opt/galaxytv-library-node}"
ENV_FILE="$NODE_DIR/.env"
SERVICE_FILE="/etc/systemd/system/galaxytv-library-node.service"
SYSTEM_ENV="/etc/galaxytv-library-node.env"

[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
command -v apt-get >/dev/null 2>&1 || { echo "Ubuntu/Debian with apt is required." >&2; exit 1; }

mkdir -p "$NODE_DIR/state" "$NODE_DIR/strm-library"
if [[ ! -f "$ENV_FILE" ]]; then
  cp "$ROOT_DIR/library-node/.env.example" "$ENV_FILE"
  sed -i "s/^LIBRARY_AGENT_TOKEN=.*/LIBRARY_AGENT_TOKEN=$(openssl rand -hex 32)/" "$ENV_FILE"
  sed -i "s/^LIBRARY_MEDIA_TOKEN=.*/LIBRARY_MEDIA_TOKEN=$(openssl rand -hex 32)/" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  echo "Created $ENV_FILE"
  echo "Edit MEDIA_SCAN_PATH, STRM_PATH, JELLYFIN_URL, JELLYFIN_API_KEY, and LIBRARY_PLAYBACK_BASE_URL, then rerun:"
  echo "  sudo bash library-node/install-native.sh"
  exit 0
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

MEDIA_SCAN_PATH="${MEDIA_SCAN_PATH:-${MEDIA_PATH%/}/Media}"
STRM_PATH="${STRM_PATH:-$NODE_DIR/strm-library}"
LIBRARY_NODE_PORT="${LIBRARY_NODE_PORT:-8292}"
LIBRARY_NODE_BIND_IP="${LIBRARY_NODE_BIND_IP:-0.0.0.0}"
NATIVE_SERVICE_USER="${NATIVE_SERVICE_USER:-root}"

for required in LIBRARY_AGENT_TOKEN LIBRARY_MEDIA_TOKEN JELLYFIN_URL LIBRARY_PLAYBACK_BASE_URL; do
  [[ -n "${!required:-}" && "${!required}" != "CHANGE_ME" ]] || { echo "$required must be configured in $ENV_FILE" >&2; exit 1; }
done
[[ -d "$MEDIA_SCAN_PATH" ]] || { echo "Media scan path does not exist: $MEDIA_SCAN_PATH" >&2; exit 1; }
mkdir -p "$STRM_PATH"

apt-get update
apt-get install -y python3 python3-venv python3-pip ca-certificates curl

rm -rf "$NODE_DIR/library-agent.new"
cp -a "$ROOT_DIR/library-agent" "$NODE_DIR/library-agent.new"
rm -rf "$NODE_DIR/library-agent.previous"
[[ -d "$NODE_DIR/library-agent" ]] && mv "$NODE_DIR/library-agent" "$NODE_DIR/library-agent.previous"
mv "$NODE_DIR/library-agent.new" "$NODE_DIR/library-agent"

rm -rf "$NODE_DIR/venv.new"
python3 -m venv "$NODE_DIR/venv.new"
"$NODE_DIR/venv.new/bin/pip" install --no-cache-dir --upgrade pip
"$NODE_DIR/venv.new/bin/pip" install --no-cache-dir -r "$NODE_DIR/library-agent/requirements.txt"
rm -rf "$NODE_DIR/venv.previous"
[[ -d "$NODE_DIR/venv" ]] && mv "$NODE_DIR/venv" "$NODE_DIR/venv.previous"
mv "$NODE_DIR/venv.new" "$NODE_DIR/venv"

escape_env() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
cat > "$SYSTEM_ENV" <<EOF
LIBRARY_AGENT_TOKEN="$(escape_env "$LIBRARY_AGENT_TOKEN")"
LIBRARY_MEDIA_TOKEN="$(escape_env "$LIBRARY_MEDIA_TOKEN")"
LIBRARY_AGENT_STATE="$(escape_env "$NODE_DIR/state")"
LIBRARY_SOURCE_PATH="$(escape_env "$MEDIA_SCAN_PATH")"
LIBRARY_OUTPUT_PATH="$(escape_env "$STRM_PATH")"
LIBRARY_PLAYBACK_BASE_URL="$(escape_env "$LIBRARY_PLAYBACK_BASE_URL")"
JELLYFIN_URL="$(escape_env "$JELLYFIN_URL")"
JELLYFIN_API_KEY="$(escape_env "${JELLYFIN_API_KEY:-}")"
TZ="$(escape_env "${TZ:-America/Chicago}")"
EOF
chmod 600 "$SYSTEM_ENV"

if [[ "$NATIVE_SERVICE_USER" != "root" ]] && ! id "$NATIVE_SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --home "$NODE_DIR" --shell /usr/sbin/nologin "$NATIVE_SERVICE_USER"
fi
if [[ "$NATIVE_SERVICE_USER" != "root" ]]; then
  chown -R "$NATIVE_SERVICE_USER":"$NATIVE_SERVICE_USER" "$NODE_DIR/state" "$STRM_PATH"
fi

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=GalaxyTV JellyPanel Library Node
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$NATIVE_SERVICE_USER
WorkingDirectory=$NODE_DIR/library-agent
EnvironmentFile=$SYSTEM_ENV
ExecStart=$NODE_DIR/venv/bin/uvicorn app.main:app --host $LIBRARY_NODE_BIND_IP --port $LIBRARY_NODE_PORT
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=$NODE_DIR $STRM_PATH

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now galaxytv-library-node.service

for _ in $(seq 1 60); do
  if curl -fsS -H "X-Library-Token: $LIBRARY_AGENT_TOKEN" "http://127.0.0.1:$LIBRARY_NODE_PORT/status" >/dev/null; then
    echo "GalaxyTV Library Node is healthy on port $LIBRARY_NODE_PORT."
    echo "Agent URL: $LIBRARY_PLAYBACK_BASE_URL"
    exit 0
  fi
  sleep 2
done

systemctl status galaxytv-library-node.service --no-pager || true
journalctl -u galaxytv-library-node.service --no-pager -n 100 || true
exit 1
