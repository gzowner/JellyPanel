#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_DIR="${LIBRARY_NODE_BASE_DIR:-/opt/galaxytv-library-node}"
MODE="docker"
for arg in "$@"; do
  case "$arg" in
    --mode=native|--native) MODE="native" ;;
    --mode=docker|--docker) MODE="docker" ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done
if [[ "$MODE" == "native" ]]; then
  exec bash "$ROOT_DIR/library-node/install-native.sh"
fi
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }
command -v docker >/dev/null 2>&1 || { apt-get update; apt-get install -y ca-certificates curl; curl -fsSL https://get.docker.com | sh; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose plugin is required."; exit 1; }
mkdir -p "$NODE_DIR/state" "$NODE_DIR/strm-library"
cp "$ROOT_DIR/library-node/compose.yml" "$NODE_DIR/compose.yml"
rm -rf "$NODE_DIR/library-agent.incoming"
cp -a "$ROOT_DIR/library-agent" "$NODE_DIR/library-agent.incoming"
rm -rf "$NODE_DIR/library-agent.previous"
[[ -d "$NODE_DIR/library-agent" ]] && mv "$NODE_DIR/library-agent" "$NODE_DIR/library-agent.previous"
mv "$NODE_DIR/library-agent.incoming" "$NODE_DIR/library-agent"
if [[ ! -f "$NODE_DIR/.env" ]]; then
  cp "$ROOT_DIR/library-node/.env.example" "$NODE_DIR/.env"
  agent_token="$(openssl rand -hex 32)"
  media_token="$(openssl rand -hex 32)"
  sed -i "s/^LIBRARY_AGENT_TOKEN=.*/LIBRARY_AGENT_TOKEN=$agent_token/" "$NODE_DIR/.env"
  sed -i "s/^LIBRARY_MEDIA_TOKEN=.*/LIBRARY_MEDIA_TOKEN=$media_token/" "$NODE_DIR/.env"
  echo
  echo "Edit $NODE_DIR/.env before starting the node:"
  echo "  MEDIA_PATH"
  echo "  JELLYFIN_URL"
  echo "  JELLYFIN_API_KEY"
  echo "  LIBRARY_PLAYBACK_BASE_URL"
  echo
  echo "Agent token: $agent_token"
  echo "Media token: $media_token"
  echo "Save these two tokens in JellyPanel's Server Libraries page."
  exit 0
fi
if ! grep -q '^SOURCE_PATH=' "$NODE_DIR/.env"; then
  legacy_media="$(grep '^MEDIA_PATH=' "$NODE_DIR/.env" | tail -1 | cut -d= -f2-)"
  printf '
SOURCE_PATH=%s/Media
' "${legacy_media%/}" >> "$NODE_DIR/.env"
fi
set -a
# shellcheck disable=SC1090
source "$NODE_DIR/.env"
set +a
[[ -d "${SOURCE_PATH:-}" ]] || { echo "SOURCE_PATH does not exist: ${SOURCE_PATH:-not configured}" >&2; exit 1; }
mkdir -p "${STRM_PATH:-$NODE_DIR/strm-library}"
(cd "$NODE_DIR" && docker compose --env-file .env up -d --build --remove-orphans)
echo "GalaxyTV Library Node started."
