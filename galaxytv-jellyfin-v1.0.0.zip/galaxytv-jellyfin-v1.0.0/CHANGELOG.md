# GalaxyTV Changelog

## 1.0.0 Stable

- Consolidated all releases through v0.11.0 into one cumulative archive.
- Added guided fresh-install and automatic upgrade detection.
- Added explicit fresh, upgrade, repair, restore, diagnostics, and uninstall modes.
- Added Ubuntu 24.04, architecture, memory, disk, Docker, port, path, and mount preflight checks.
- Added configurable media path, inventory root, rclone settings, timezone, ports, credentials, and GPU access.
- Added release-file checksum verification.
- Added local application/PostgreSQL rollback snapshots before upgrades and repairs.
- Added managed pre-upgrade backup requests.
- Added automatic application rollback after failed deployment validation.
- Added complete service, endpoint, media-mount, and migration health checks.
- Added generic rollback-last-upgrade command.
- Added host-side diagnostics fallback.
- Added data-preserving container uninstall.
- Updated managed restore so PostgreSQL-only restore points can complete when a Jellyfin archive is unavailable.
- Removed development-version rollback scripts from the stable distribution.
